
import React, { useState, useCallback, useEffect } from 'react';
import Navigation from './components/Navigation';
import OverviewPage from './components/overview/OverviewPage';
import IntentPlannerPage from './components/intent-planner/IntentPlannerPage';
import AuditPage from './components/audit/AuditPage';
import CalendarPageReact from './components/calendar/CalendarPage';
import StrategyPage from './components/strategy/StrategyPage';
import Modal from './components/shared/Modal';
import GlobalSearchInput from './components/shared/GlobalSearchInput';
import SearchResultsPage from './components/search/SearchResultsPage';
import CompetitorAnalysisPage from './components/competitor-analysis/CompetitorAnalysisPage';
import TopicGeneratorPage from './components/topic-generator/TopicGeneratorPage';
import APIConnectionCheck from './components/shared/APIConnectionCheck'; // Import the new component
import { ActivePage, CalendarContent, SearchResult, AuditEntry, Strategy as StrategyType, ContentStatus } from './types';
import { INITIAL_CALENDAR_DATA, INITIAL_AUDIT_DATA, INITIAL_STRATEGY_DATA, AUDIENCE_SEGMENTS, THEMES, STANDARD_MONTH_ORDER, BRAND_PRIMARY, BRAND_SECONDARY } from './constants';
import { v4 as uuidv4 } from 'uuid';
import { logAppAction } from './services/loggingService'; // Added for logging blueprint

const CALENDAR_DATA_LS_KEY = 'bellwether_calendarData';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<ActivePage>('overview');
  const [modalItem, setModalItem] = useState<CalendarContent | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const [calendarData, setCalendarData] = useState<CalendarContent[]>(() => {
    const storedCalendarData = localStorage.getItem(CALENDAR_DATA_LS_KEY);
    return storedCalendarData ? JSON.parse(storedCalendarData) : INITIAL_CALENDAR_DATA;
  });

  const [strategyData] = useState<StrategyType[]>(INITIAL_STRATEGY_DATA);

  const [globalSearchInputTerm, setGlobalSearchInputTerm] = useState('');
  const [currentGlobalSearchTerm, setCurrentGlobalSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  
  const [initialAuditSearchTerm, setInitialAuditSearchTerm] = useState<string | undefined>(undefined);
  const [initialAuditRelevanceFilter, setInitialAuditRelevanceFilter] = useState<string | undefined>(undefined);
  const [expandedStrategyId, setExpandedStrategyId] = useState<string | null | undefined>(undefined);
  const [initialCalendarFilters, setInitialCalendarFilters] = useState<object | undefined>(undefined);
  const [initialSelectedAudience, setInitialSelectedAudience] = useState<string | undefined>(undefined);

  useEffect(() => {
    localStorage.setItem(CALENDAR_DATA_LS_KEY, JSON.stringify(calendarData));
  }, [calendarData]);

  const handleNavigate = (target: ActivePage, params?: Record<string, any>) => {
    logAppAction({
        actionType: 'Page Navigation',
        pageContext: activePage, // Previous page as context
        details: { navigatedTo: target, params: params || {} }
    });
    setActivePage(target);
    setInitialAuditSearchTerm(undefined);
    setInitialAuditRelevanceFilter(undefined);
    setExpandedStrategyId(undefined);
    setInitialCalendarFilters(undefined);
    setInitialSelectedAudience(undefined);

    if (params) {
      if (target === 'audit') {
        setInitialAuditSearchTerm(params.initialSearchTerm);
        setInitialAuditRelevanceFilter(params.initialRelevanceFilter);
      }
      if (target === 'strategy') {
        setExpandedStrategyId(params.expandedStrategyId);
      }
      if (target === 'calendar') {
        setInitialCalendarFilters(params.initialFilters);
      }
      if (target === 'intent-planner') {
        setInitialSelectedAudience(params.initialSelectedAudience);
      }
    }
    window.scrollTo(0, 0); 
  };

  const handleOpenModal = (item: CalendarContent, actionType?: string) => { 
    logAppAction({
        actionType: 'Open Modal',
        pageContext: activePage,
        itemId: item.id,
        details: { itemTitle: item.title, initialActionType: actionType || 'view' }
    });
    setModalItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    logAppAction({
        actionType: 'Close Modal',
        pageContext: activePage,
        itemId: modalItem?.id,
        details: { itemTitle: modalItem?.title }
    });
    setIsModalOpen(false);
    setModalItem(null);
  };
  
  const handleCalendarDataUpdate = useCallback((updatedData: CalendarContent[]) => {
    setCalendarData(updatedData);
  }, []);

  const handleAddNewContentItems = useCallback((newItems: CalendarContent[]) => {
    setCalendarData(prevData => [...prevData, ...newItems]);
    // Individual item logging is now handled in TopicGeneratorPage
    // Log batch action for context
    logAppAction({
        actionType: 'Batch Add New Content Items to Calendar', // Clarified name
        pageContext: activePage, 
        details: { count: newItems.length, itemTitles: newItems.map(item => item.title) }
    });
  }, [activePage]);


  const handleCreateContentIdea = useCallback((baseTitle: string, opportunityText: string) => {
    const currentMonthName = STANDARD_MONTH_ORDER[new Date().getMonth()];
    const defaultMonth = currentMonthName || "Unassigned";
    const defaultTheme = THEMES.length > 0 ? THEMES[0] : "General";
    const defaultAudience = AUDIENCE_SEGMENTS.length > 0 ? AUDIENCE_SEGMENTS[0] : "General Homeowners";

    const newIdea: CalendarContent = {
      id: uuidv4(), 
      title: `New Idea: ${baseTitle}`,
      brief: `Based on audit opportunity: "${opportunityText}"\n\nDevelop this into a full content piece focusing on Bellwether's premium Colorado expertise.`,
      status: "Ideation" as ContentStatus,
      month: defaultMonth, 
      theme: defaultTheme, 
      type: "Blog Post", 
      intent: "Awareness/Informational", 
      audience: defaultAudience, 
      keywords: "", 
      competitorRelevance: "To be defined based on new angle.", 
    };
    setCalendarData(prev => [...prev, newIdea]);
    
    // Log the creation of this specific idea to Google Sheets
    logAppAction({
        actionType: 'New Idea from Audit',
        pageContext: 'audit', // The page where the action originates
        itemId: newIdea.id,
        details: { 
            title: newIdea.title, 
            brief: newIdea.brief,
            month: newIdea.month,
            theme: newIdea.theme,
            type: newIdea.type,
            intent: newIdea.intent,
            audience: newIdea.audience,
            source: 'Content Audit',
            originalBaseTitle: baseTitle,
            triggeringOpportunity: opportunityText 
        }
    });
    
    handleOpenModal(newIdea); 
  }, [setCalendarData]);


  const performGlobalSearch = (term: string) => {
    setGlobalSearchInputTerm(term); 
    if (!term.trim()) {
      setSearchResults([]);
      setCurrentGlobalSearchTerm('');
      if (activePage === 'search-results') handleNavigate('overview');
      return;
    }

    logAppAction({
        actionType: 'Global Search Performed',
        pageContext: 'Global',
        details: { searchTerm: term }
    });

    const lowerTerm = term.toLowerCase();
    const results: SearchResult[] = [];

    calendarData.forEach(item => {
      if (item.title.toLowerCase().includes(lowerTerm) ||
          item.brief.toLowerCase().includes(lowerTerm) ||
          item.keywords.toLowerCase().includes(lowerTerm) ||
          item.audience.toLowerCase().includes(lowerTerm) ||
          item.theme.toLowerCase().includes(lowerTerm)) {
        results.push({
          id: item.id, type: 'calendar', title: item.title,
          description: item.brief.substring(0, 150) + (item.brief.length > 150 ? '...' : ''),
          data: item, searchTermContext: term,
        });
      }
    });

    INITIAL_AUDIT_DATA.forEach(item => {
      if (item.blogTitle.toLowerCase().includes(lowerTerm) ||
          item.videoTitle.toLowerCase().includes(lowerTerm) ||
          item.opportunity.toLowerCase().includes(lowerTerm)) {
        results.push({
          id: `audit-${item.blogTitle.replace(/\s+/g, '-')}`, type: 'audit', title: item.blogTitle,
          description: item.opportunity.substring(0, 150) + (item.opportunity.length > 150 ? '...' : ''),
          data: item, searchTermContext: term,
        });
      }
    });

    strategyData.forEach(item => { 
      if (item.title.toLowerCase().includes(lowerTerm) ||
          item.content.toLowerCase().includes(lowerTerm)) {
        results.push({
          id: item.id, type: 'strategy', title: item.title,
          description: item.content.substring(0, 150) + (item.content.length > 150 ? '...' : ''),
          data: item, searchTermContext: term,
        });
      }
    });
    
    setCurrentGlobalSearchTerm(term);
    setSearchResults(results);
    handleNavigate('search-results');
  };

  const handleSearchResultClick = (result: SearchResult) => {
    logAppAction({
        actionType: 'Search Result Clicked',
        pageContext: 'search-results',
        itemId: result.id,
        details: { resultType: result.type, resultTitle: result.title }
    });
    switch (result.type) {
      case 'calendar':
        handleOpenModal(result.data as CalendarContent);
        break;
      case 'audit':
        handleNavigate('audit', { initialSearchTerm: result.searchTermContext || currentGlobalSearchTerm });
        break;
      case 'strategy':
        handleNavigate('strategy', { expandedStrategyId: result.id });
        break;
    }
  };

  const renderPage = () => {
    switch (activePage) {
      case 'overview':
        return <OverviewPage calendarData={calendarData} strategyData={strategyData} onNavigate={handleNavigate} />;
      case 'intent-planner':
        return <IntentPlannerPage 
                  initialCalendarData={calendarData} 
                  onCalendarDataUpdate={handleCalendarDataUpdate}
                  initialSelectedAudience={initialSelectedAudience}
                  onOpenModal={handleOpenModal} 
                />;
      case 'audit':
        return <AuditPage 
                  initialSearchTerm={initialAuditSearchTerm} 
                  initialRelevanceFilter={initialAuditRelevanceFilter} 
                  onCreateContentIdea={handleCreateContentIdea}
                />;
      case 'calendar':
        return <CalendarPageReact 
                  calendarData={calendarData} 
                  onOpenModal={handleOpenModal}
                  initialFilters={initialCalendarFilters}
                  onCalendarDataUpdate={handleCalendarDataUpdate}
                />;
      case 'strategy':
        return <StrategyPage expandedStrategyId={expandedStrategyId} />;
      case 'search-results':
        return <SearchResultsPage results={searchResults} searchTerm={currentGlobalSearchTerm} onResultClick={handleSearchResultClick} />;
      case 'competitor-analysis':
        return <CompetitorAnalysisPage calendarData={calendarData} />; 
      case 'topic-generator':
        return <TopicGeneratorPage 
                  onAddContentItems={handleAddNewContentItems} 
                  existingCalendarData={calendarData}
                  strategyData={strategyData}
                />;
      default:
        return <OverviewPage calendarData={calendarData} strategyData={strategyData} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className={`py-5 px-4 md:px-8 shadow-lg bg-gradient-to-r from-[${BRAND_PRIMARY}] to-[${BRAND_SECONDARY}] text-white sticky top-0 z-30`}>
        <div className="container mx-auto max-w-screen-2xl">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-0.5">Bellwether Homes</h1>
          <p className="text-sm sm:text-md opacity-90">Content Strategy Command Center</p>
        </div>
      </header>
      
      <div className="container mx-auto p-3 sm:p-4 md:p-6 lg:p-8 max-w-screen-2xl flex-grow w-full">
        <Navigation activePage={activePage} onNavigate={handleNavigate} />
        <GlobalSearchInput onSearch={performGlobalSearch} initialTerm={globalSearchInputTerm} />
        <main className="mt-6 md:mt-8 bg-transparent"> 
          {renderPage()}
        </main>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal} 
        item={modalItem}
        allCalendarData={calendarData}
        allAuditData={INITIAL_AUDIT_DATA}
        onCalendarItemUpdate={(updatedItem) => {
          setCalendarData(prevData => prevData.map(d => d.id === updatedItem.id ? updatedItem : d));
          logAppAction({
            actionType: 'Calendar Item Update',
            pageContext: 'Modal',
            itemId: updatedItem.id,
            details: { updatedField: 'brief (potentially others via AI)' , itemTitle: updatedItem.title }
          });
        }}
      />
      <footer className="text-center py-5 px-4 text-xs text-slate-600 border-t border-slate-200 bg-slate-100">
        <div className="container mx-auto max-w-screen-2xl flex flex-col sm:flex-row justify-between items-center">
            <p className="mb-2 sm:mb-0">
            &copy; {new Date().getFullYear()} Bellwether Homes Content Strategy Dashboard. Data persists in browser storage.
            </p>
            <APIConnectionCheck /> 
        </div>
      </footer>
    </div>
  );
};

export default App;
