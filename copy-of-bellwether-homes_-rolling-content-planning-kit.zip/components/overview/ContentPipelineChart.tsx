
import React, { useEffect, useRef } from 'react';
import { Chart, BarController, BarElement, CategoryScale, LinearScale, Legend, Tooltip, Title } from 'chart.js';
import { CalendarContent, KANBAN_STATUSES, ContentStatus } from '../../types';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_BACKGROUND } from '../../constants';

Chart.register(BarController, BarElement, CategoryScale, LinearScale, Legend, Tooltip, Title);

interface ContentPipelineChartProps {
  calendarData: CalendarContent[];
}

const ContentPipelineChart: React.FC<ContentPipelineChartProps> = ({ calendarData }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      const statusCounts = KANBAN_STATUSES.map(status =>
        calendarData.filter(item => item.status === status).length
      );

      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        const backgroundColors = [
          'rgba(251, 191, 36, 0.75)', // Ideation - yellow
          'rgba(59, 130, 246, 0.75)', // Drafting - blue
          'rgba(249, 115, 22, 0.75)', // Review - orange
          'rgba(20, 184, 166, 0.75)', // Scheduled - teal
          'rgba(34, 197, 94, 0.75)',  // Published - green
        ];
        const hoverBackgroundColors = [
          'rgba(251, 191, 36, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(249, 115, 22, 1)',
          'rgba(20, 184, 166, 1)',
          'rgba(34, 197, 94, 1)',
        ];

        chartInstanceRef.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: KANBAN_STATUSES,
            datasets: [{
              label: 'Number of Content Pieces',
              data: statusCounts,
              backgroundColor: backgroundColors,
              borderColor: hoverBackgroundColors, // Use full opacity colors for border for consistency
              borderWidth: 1,
              borderRadius: 4,
              hoverBackgroundColor: hoverBackgroundColors,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1,
                    font: { family: 'Work Sans', size: 10 },
                    color: '#6B7280', // text-gray-500
                },
                grid: { color: '#E5E7EB' }
              },
              x: {
                ticks: {
                    font: { family: 'Work Sans', size: 11},
                    color: '#4B5563', // text-gray-600
                },
                grid: { display: false }
              }
            },
            plugins: {
              legend: { display: false },
              title: {
                display: true,
                text: 'Content Production Pipeline',
                font: { size: 16, family: 'Work Sans', weight: 600 },
                color: '#2D3748', // brand-text-primary
                padding: { top: 5, bottom: 25 }
              },
              tooltip: {
                bodyFont: { family: 'Work Sans' },
                titleFont: { family: 'Work Sans', weight: 'bold' },
              }
            }
          }
        });
      }
    }
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [calendarData]);

  return (
    <div className="chart-container relative w-full max-w-xl mx-auto h-72 sm:h-80 md:h-96">
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default ContentPipelineChart;
