
import React from 'react';
import { ActivePage } from '../../types';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_ORANGE_LIGHT } from '../../constants';
import { CalendarIcon, SearchIcon, UsersIcon, LightbulbIcon, SparklesIcon, EyeIcon, BeakerIcon } from '../shared/Icons';

interface QuickActionsSectionProps {
  onNavigate: (targetPage: ActivePage, params?: Record<string, any>) => void;
}

const ActionButton: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  buttonText: string;
}> = ({ icon, title, description, onClick, buttonText }) => (
  <div className="bg-white p-5 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out flex flex-col items-start h-full border border-slate-200 hover:border-[#DD5B42] focus-within:ring-2 focus-within:ring-[#DD5B42] focus-within:ring-offset-2 group">
    <div className="flex items-center mb-3">
      <div className={`p-2.5 rounded-full bg-[${BRAND_ORANGE_LIGHT}] text-[${BRAND_PRIMARY}] mr-3 shadow-sm`}>
        {icon}
      </div>
      <h4 className="text-md font-semibold text-slate-800 group-hover:text-[#DD5B42] transition-colors">{title}</h4>
    </div>
    <p className="text-xs text-slate-500 mb-4 flex-grow">{description}</p>
    <button
      onClick={onClick}
      className={`w-full mt-auto bg-[${BRAND_PRIMARY}] hover:bg-[${BRAND_SECONDARY}] text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`}
    >
      {buttonText}
    </button>
  </div>
);

const QuickActionsSection: React.FC<QuickActionsSectionProps> = ({ onNavigate }) => {
  return (
    <section id="quick-actions" className="bg-slate-100 p-6 md:p-8 rounded-xl shadow-inner border border-slate-200">
      <h2 className="text-xl md:text-2xl font-bold text-slate-700 mb-6 text-center">Quick Actions & Tool Jumpstarts</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
        <ActionButton
          icon={<SparklesIcon className="w-5 h-5" />}
          title="AI Topic Generator"
          description="Brainstorm new content ideas for upcoming periods using AI assistance."
          onClick={() => onNavigate('topic-generator')}
          buttonText="Generate New Topics"
        />
        <ActionButton
          icon={<EyeIcon className="w-5 h-5" />}
          title="Review Ideation Pipeline"
          description="Jump to the calendar, filtered to show all content currently in the 'Ideation' stage."
          onClick={() => onNavigate('calendar', { initialFilters: { status: 'Ideation' } })}
          buttonText="View Ideation Stage"
        />
        <ActionButton
          icon={<BeakerIcon className="w-5 h-5" />}
          title="Analyze Competitors"
          description="Access the competitor analysis tool to research and gain insights on other players."
          onClick={() => onNavigate('competitor-analysis')}
          buttonText="Go to Competitor Analysis"
        />
        <ActionButton
          icon={<CalendarIcon className="w-5 h-5" />}
          title="Monthly Content Snapshot"
          description="Jump directly to a specific month in the Content Calendar to review planned posts and videos."
          onClick={() => onNavigate('calendar', { initialFilters: { month: 'June' } })}
          buttonText="View June's Content"
        />
        <ActionButton
          icon={<SearchIcon className="w-5 h-5" />}
          title="Audit Opportunities"
          description="Quickly find content gaps by viewing items marked with 'None' relevance in the Content Audit."
          onClick={() => onNavigate('audit', { initialRelevanceFilter: 'None' })}
          buttonText="Find Content Gaps"
        />
        <ActionButton
          icon={<UsersIcon className="w-5 h-5" />}
          title="Target Audience Journey"
          description="Map out the content experience for a specific audience segment in the Intent Journey Planner."
          onClick={() => onNavigate('intent-planner', { initialSelectedAudience: 'Early-stage CO homeowners' })}
          buttonText="Plan for New Homeowners"
        />
      </div>
    </section>
  );
};

export default QuickActionsSection;