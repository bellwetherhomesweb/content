
import React, { useState } from 'react';
import PlanHighlights from './PlanHighlights';
import ContentMixChartComponent from './ContentMixChartComponent';
import QuickActionsSection from './QuickActionsSection';
import StrategicTimelineSummary, { generateBriefTextContent } from './StrategicTimelineSummary';
import { CalendarContent, ActivePage, Strategy as StrategyType, OverviewBriefData, MonthlySummary, KANBAN_STATUSES, GeminiTextResult } from '../../types';
import { generateGeminiText } from '../../services/geminiService';
import Loader from '../shared/Loader';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_TEXT_PRIMARY, STANDARD_MONTH_ORDER } from '../../constants';
import { DownloadIcon, SparklesIcon, ExternalLinkIcon, ListBulletIcon, LightbulbIconUsersIcon, PuzzlePieceIcon, DocumentMagnifyingGlassIcon, UsersIconSolid } from '../shared/Icons';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';
import IntentionsChartComponent from '../calendar/IntentionsChartComponent';
import ContentPipelineChart from './ContentPipelineChart';
import { logAppAction } from '../../services/loggingService'; 
import AIContentDisplay from '../shared/AIContentDisplay';

interface OverviewPageProps {
  calendarData: CalendarContent[];
  strategyData: StrategyType[];
  onNavigate: (targetPage: ActivePage, params?: Record<string, any>) => void;
}

const OverviewPage: React.FC<OverviewPageProps> = ({ calendarData, strategyData, onNavigate }) => {
  const [overviewBriefData, setOverviewBriefData] = useState<OverviewBriefData | null>(null);
  const [isBriefLoading, setIsBriefLoading] = useState(false);
  const [aiSummaryText, setAiSummaryText] = useState<string | null>(null);
  const [aiSummaryError, setAiSummaryError] = useState<string | null>(null);
  const [isAiSummarizing, setIsAiSummarizing] = useState(false);
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);

  const generateOverviewBriefData = (): OverviewBriefData => {
    const strategicPillars = strategyData.map(s => ({ title: s.title, content: s.content })); 
    
    const monthlySummariesMap: Record<string, Partial<MonthlySummary> & { themesSet: Set<string>, keyContentTitlesList: string[] }> = {};
    
    // Sort calendar data based on the standard month order before processing
    const sortedCalendarData = [...calendarData].sort((a,b) => {
        const indexA = STANDARD_MONTH_ORDER.indexOf(a.month);
        const indexB = STANDARD_MONTH_ORDER.indexOf(b.month);
        if (indexA === -1 && indexB === -1) return a.month.localeCompare(b.month); // Fallback for non-standard months
        if (indexA === -1) return 1;
        if (indexB === -1) return -1;
        return indexA - indexB;
    });

    sortedCalendarData.forEach(item => {
      if (!monthlySummariesMap[item.month]) {
        monthlySummariesMap[item.month] = { 
          month: item.month, 
          themesSet: new Set(), 
          blogCount: 0, 
          videoCount: 0, 
          keyContentTitlesList: [] 
        };
      }
      const summary = monthlySummariesMap[item.month];
      summary.themesSet!.add(item.theme);
      if (item.type === "Blog Post") summary.blogCount = (summary.blogCount || 0) + 1;
      if (item.type === "YouTube Video") summary.videoCount = (summary.videoCount || 0) + 1;
      if (summary.keyContentTitlesList!.length < 5) {
        summary.keyContentTitlesList!.push(item.title);
      }
    });

    const monthlySummaries: MonthlySummary[] = Object.values(monthlySummariesMap).map(s => ({
        month: s.month!,
        themes: Array.from(s.themesSet!),
        blogCount: s.blogCount!,
        videoCount: s.videoCount!,
        keyContentTitles: s.keyContentTitlesList!
    })).sort((a,b) => { // Ensure final sort uses STANDARD_MONTH_ORDER
        const indexA = STANDARD_MONTH_ORDER.indexOf(a.month);
        const indexB = STANDARD_MONTH_ORDER.indexOf(b.month);
        if (indexA === -1 && indexB === -1) return a.month.localeCompare(b.month);
        if (indexA === -1) return 1;
        if (indexB === -1) return -1;
        return indexA - indexB;
    });
    
    return { strategicPillars, monthlySummaries, aiSummary: aiSummaryText };
  };

  const handleGenerateAndDisplayBrief = () => {
    setIsBriefLoading(true);
    const data = generateOverviewBriefData();
    setOverviewBriefData(data);
    setIsBriefLoading(false);
    logAppAction({
        actionType: 'Generate Brief',
        pageContext: 'overview',
        details: { type: 'Comprehensive Plan Brief Displayed', hasAiSummary: !!data.aiSummary }
    });
  };

  const handleDownloadBriefPdf = () => {
    if (!overviewBriefData) return;
    const { jsPDF } = (window as any).jspdf;
    if (!jsPDF) {
        alert("jsPDF library is not loaded. Cannot download PDF.");
        return;
    }
    const doc = new jsPDF({unit: "pt", format: "a4"});
    let yPos = 40;
    const pageMargin = 40;
    const pageWidth = doc.internal.pageSize.getWidth() - 2 * pageMargin;

    doc.setFont('Work Sans', 'bold');
    doc.setFontSize(20);
    doc.setTextColor(BRAND_SECONDARY);
    doc.text("Comprehensive Strategy & Timeline Brief", doc.internal.pageSize.getWidth() / 2, yPos, { align: 'center' });
    yPos += 30;

    if (aiSummaryText) { 
        doc.setFont('Work Sans', 'bold');
        doc.setFontSize(16);
        doc.setTextColor(BRAND_PRIMARY);
        doc.text("AI Executive Summary", pageMargin, yPos);
        yPos += 20;
        doc.setFont('Work Sans', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(BRAND_TEXT_PRIMARY);
        const summaryLines = doc.splitTextToSize(aiSummaryText, pageWidth); 

        doc.text(summaryLines, pageMargin, yPos);
        yPos += summaryLines.length * 12 + 20;
    }

    doc.setFont('Work Sans', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(BRAND_PRIMARY);
    doc.text("Strategic Pillars", pageMargin, yPos);
    yPos += 22;

    doc.setFont('Work Sans', 'normal');
    doc.setFontSize(10);
    overviewBriefData.strategicPillars.forEach(pillar => {
      if (yPos > doc.internal.pageSize.getHeight() - 80) { doc.addPage(); yPos = 40; }
      doc.setFont('Work Sans', 'bold');
      doc.setFontSize(12);
      const titleLines = doc.splitTextToSize(pillar.title, pageWidth);
      doc.text(titleLines, pageMargin, yPos);
      yPos += titleLines.length * 14;
      doc.setFont('Work Sans', 'normal');
      doc.setFontSize(10);
      const contentLines = doc.splitTextToSize(pillar.content, pageWidth);
      doc.text(contentLines, pageMargin, yPos);
      yPos += contentLines.length * 12 + 10;
    });

    yPos += 10;
    if (yPos > doc.internal.pageSize.getHeight() - 100) { doc.addPage(); yPos = 40; }
    doc.setFont('Work Sans', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(BRAND_PRIMARY);
    doc.text("Month-by-Month Timeline Blueprint", pageMargin, yPos);
    yPos += 25;

    overviewBriefData.monthlySummaries.forEach(summary => {
      if (yPos > doc.internal.pageSize.getHeight() - 100) { doc.addPage(); yPos = 40; }
      doc.setFont('Work Sans', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(BRAND_SECONDARY);
      doc.text(summary.month, pageMargin, yPos);
      yPos += 20;

      doc.setFont('Work Sans', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(BRAND_TEXT_PRIMARY);
      let textLines = doc.splitTextToSize(`Themes: ${summary.themes.join(', ')}`, pageWidth - 10); 
      doc.text(textLines, pageMargin + 10, yPos);
      yPos += textLines.length * 12 + 5;
      
      textLines = doc.splitTextToSize(`Content: ${summary.blogCount} Blog Posts, ${summary.videoCount} Videos`, pageWidth - 10);
      doc.text(textLines, pageMargin + 10, yPos);
      yPos += textLines.length * 12 + 5;

      if(summary.keyContentTitles.length > 0) {
        doc.text(`Key Titles Examples:`, pageMargin + 10, yPos);
        yPos += 14;
        summary.keyContentTitles.forEach(title => {
             if (yPos > doc.internal.pageSize.getHeight() - 40) { doc.addPage(); yPos = 40; }
            const titleLines = doc.splitTextToSize(`• ${title}`, pageWidth - 20);
            doc.text(titleLines, pageMargin + 20, yPos);
            yPos += titleLines.length * 12 + 4;
        });
      }
      yPos += 10;
    });

    doc.save("Bellwether_Strategy_Timeline_Brief.pdf");
    logAppAction({
        actionType: 'Export Data',
        pageContext: 'overview',
        details: { exportType: 'PDF', content: 'Comprehensive Plan Brief' }
    });
  };
  
  const handleAISummarizeBrief = async () => {
    let currentBriefData = overviewBriefData;
    if (!currentBriefData) {
        currentBriefData = generateOverviewBriefData();
        setOverviewBriefData(currentBriefData);
    }
    
    if (!currentBriefData) { 
        alert("Could not generate brief data. Please check data sources.");
        setIsAiSummarizing(false);
        return;
    }

    setIsAiSummarizing(true);
    setAiSummaryText(null); 
    setAiSummaryError(null);

    const fullBriefText = generateBriefTextContent(currentBriefData);

    const prompt = `Task: Summarize the following comprehensive content strategy and timeline brief for Bellwether Homes into a concise, impactful executive summary (2-3 paragraphs).
    Focus on the main strategic directions, overall content output rhythm based on the provided monthly summaries, and how this plan positions Bellwether as a premium, expert Colorado remodeler.
    Brief to Summarize:\n\n${fullBriefText}`;
    
    const logDetailsBase: Record<string, any> = { 
        aiActionType: 'Summarize Comprehensive Brief', 
        promptLength: prompt.length,
        originalPrompt: prompt, // Log the full prompt
        originalBriefTextLength: fullBriefText.length
    };
    
    const result: GeminiTextResult = await generateGeminiText(prompt);
    
    if (result.error) {
        setAiSummaryError(result.error);
        logAppAction({ actionType: 'AI Action Result', pageContext: 'overview', details: { ...logDetailsBase, status: 'error', error: result.error }});
    } else if (result.text) {
        setAiSummaryText(result.text); 
        setOverviewBriefData(prev => prev ? {...prev, aiSummary: result.text} : { ...currentBriefData!, aiSummary: result.text });
        logAppAction({ actionType: 'AI Action Result', pageContext: 'overview', details: { ...logDetailsBase, status: 'success', generatedSummary: result.text }});
    } else {
        const emptyMsg = "AI returned an empty summary.";
        setAiSummaryError(emptyMsg);
        logAppAction({ actionType: 'AI Action Result', pageContext: 'overview', details: { ...logDetailsBase, status: 'empty_response', error: emptyMsg }});
    }
    setIsAiSummarizing(false);
  };

  const sectionTitleClasses = "text-2xl font-bold text-slate-800 mb-6 text-center";
  const cardClasses = "bg-white p-6 rounded-xl shadow-lg border border-slate-200";

  return (
    <div id="overview" className="space-y-10 md:space-y-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800">Welcome to Your Command Center!</h2>
            <p className="text-slate-600 mt-1">A dynamic overview of your Bellwether Homes content strategy.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0"/>
      </div>

      <QuickActionsSection onNavigate={onNavigate} />
      
      <section id="comprehensive-brief" className={`${cardClasses}`}>
        <h2 className={sectionTitleClasses}>Comprehensive Strategy & Timeline Brief</h2>
        <div className="flex flex-col sm:flex-row flex-wrap justify-center items-center gap-3 md:gap-4 mb-6">
            <button
                onClick={handleGenerateAndDisplayBrief}
                disabled={isBriefLoading}
                className={`bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 disabled:opacity-70 flex items-center gap-2 shadow-md hover:shadow-lg`}
            >
                {isBriefLoading ? <Loader /> : "Show Current Plan Brief"}
            </button>
            {(overviewBriefData || isAiSummarizing) && (
                 <>
                    <button
                        onClick={handleAISummarizeBrief}
                        disabled={isAiSummarizing}
                        className={`bg-sky-600 hover:bg-sky-700 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 disabled:opacity-70 flex items-center gap-2 shadow-md hover:shadow-lg`}
                    >
                        {isAiSummarizing ? <Loader /> : <><SparklesIcon className="w-4 h-4"/> AI Summarize Plan</>}
                    </button>
                 </>
            )}
            {overviewBriefData && (
                 <button
                    onClick={handleDownloadBriefPdf}
                    className={`bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 flex items-center gap-2 shadow-md hover:shadow-lg`}
                >
                    <DownloadIcon className="w-4 h-4"/> Download Brief (PDF)
                </button>
            )}
        </div>
        
        <AIContentDisplay
            isLoading={isAiSummarizing}
            aiGeneratedContent={aiSummaryText}
            error={aiSummaryError}
            title="AI Executive Summary"
            onCopyText={(textToCopy) => {
                 logAppAction({
                    actionType: 'AI Content Copied',
                    pageContext: 'overview',
                    details: { copiedActionType: 'Summarize Comprehensive Brief', copiedText: textToCopy }
                });
                navigator.clipboard.writeText(textToCopy);
            }}
        />

        {isBriefLoading && !overviewBriefData && <div className="flex justify-center my-4"><Loader /></div>}
        {overviewBriefData && !isBriefLoading && (
            <div className="bg-slate-50 p-5 rounded-lg shadow-inner mt-4 border border-slate-200">
                <StrategicTimelineSummary briefData={{...overviewBriefData, aiSummary: aiSummaryText}} />
            </div>
        )}
      </section>

      <div className={cardClasses}>
        <PlanHighlights calendarData={calendarData} />
      </div>

      <section id="content-visualizations">
        <h2 className={sectionTitleClasses}>Content Plan Visualizations</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
            <div className={cardClasses}><ContentPipelineChart calendarData={calendarData} /></div>
            <div className={cardClasses}><ContentMixChartComponent calendarData={calendarData} /></div>
        </div>
        <div className={`mt-6 md:mt-8 ${cardClasses}`}>
            <IntentionsChartComponent data={calendarData} />
        </div>
      </section>

      <section id="strategy-snapshot">
        <h2 className={sectionTitleClasses}>Strategic Blueprint Snapshot</h2>
        <div className={`${cardClasses} space-y-4`}>
            {strategyData.slice(0, 3).map(strategy => ( 
                <div key={strategy.id} className="pb-3 border-b border-orange-200 last:border-b-0">
                    <h4 className="font-semibold text-lg text-[#DD5B42]">{strategy.title}</h4>
                    <p className="text-sm text-slate-600 mt-1 line-clamp-2">{strategy.content}</p>
                </div>
            ))}
            <button 
                onClick={() => onNavigate('strategy')}
                className={`mt-4 bg-[${BRAND_SECONDARY}] hover:bg-opacity-90 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 flex items-center gap-2 mx-auto shadow-md hover:shadow-lg`}
            >
                View Full Strategic Blueprint <ExternalLinkIcon className="w-4 h-4" />
            </button>
        </div>
      </section>
      
      <section id="key-tools-links">
        <h2 className={sectionTitleClasses}>Explore Key Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[
                { title: "Content Audit", page: "audit" as ActivePage, icon: <DocumentMagnifyingGlassIcon className="w-6 h-6"/>, description: "Analyze existing content for gaps and opportunities." },
                { title: "Intent Planner", page: "intent-planner" as ActivePage, icon: <UsersIconSolid className="w-6 h-6"/>, description: "Map content to user intent stages." },
                { title: "AI Topic Generator", page: "topic-generator" as ActivePage, icon: <LightbulbIconUsersIcon className="w-6 h-6"/>, description: "Brainstorm new content ideas with AI." } 
            ].map(tool => (
                 <button 
                    key={tool.page}
                    onClick={() => onNavigate(tool.page)}
                    className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out text-left flex flex-col items-start border border-slate-200 hover:border-[#DD5B42] focus:outline-none focus:ring-2 focus:ring-[#DD5B42] focus:ring-offset-2 group"
                >
                    <div className={`p-3 rounded-full bg-[${BRAND_PRIMARY}] text-white mb-4 shadow-sm`}>{tool.icon}</div>
                    <h4 className="text-md font-semibold text-slate-800 mb-1.5">{tool.title}</h4>
                    <p className="text-xs text-slate-500 flex-grow mb-4">{tool.description}</p>
                    <span className={`mt-auto text-sm font-medium text-[${BRAND_SECONDARY}] group-hover:underline`}>Go to {tool.title.split(' ')[0]} &rarr;</span>
                </button>
            ))}
        </div>
      </section>
      
      <HelpPanel
        title="Using the Dashboard Overview"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Welcome to Your Content Strategy Command Center!</h4>
        <p>This Overview page provides a dynamic summary of your content plan and quick access to tools. <strong>Your work (like calendar content) is saved in your browser's local storage.</strong></p>
        <ul>
          <li><strong>Quick Actions:</strong> Jump directly to pre-filtered views or specific items in other tools. Now includes links to generate topics, review ideation, and analyze competitors.</li>
          <li><strong>Comprehensive Strategy & Timeline Brief:</strong>
            <ul>
                <li>Click "Show Current Plan Brief" to generate a detailed document based on your current calendar data and strategic pillars.</li>
                <li>Use "✨ AI Summarize Plan" to get an AI-generated executive summary of this live brief.</li>
                <li>"Download Brief (PDF)" to save this document.</li>
            </ul>
          </li>
          <li><strong>Live Plan Highlights:</strong> Key metrics reflecting your current content plan in real-time.</li>
          <li><strong>Content Visualizations:</strong>
            <ul>
                <li><strong>Pipeline Chart:</strong> Shows content distribution across production statuses.</li>
                <li><strong>Mix Chart:</strong> Visualizes blog vs. video balance.</li>
                <li><strong>Intent Chart:</strong> Breaks down content by user intent stage.</li>
            </ul>
          </li>
          <li><strong>Strategic Blueprint Snapshot:</strong> A quick look at your top strategies, with a link to the full blueprint.</li>
          <li><strong>Key Tools Quick Links:</strong> Direct buttons to access the Content Audit, Intent Planner, and AI Topic Generator.</li>
          <li><strong>Global Search (Top Bar):</strong> Search across your live calendar data, audit items, and strategies.</li>
        </ul>
        <p>This dashboard is an ongoing project management tool. Use the "AI Topic Generator" to plan content for upcoming periods and manage its lifecycle through the Calendar and other tools.</p>
      </HelpPanel>
    </div>
  );
};

export default OverviewPage;
