
import React from 'react';
import { OverviewBriefData, MonthlySummary, Strategy } from '../../types';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_TEXT_PRIMARY } from '../../constants';

interface StrategicTimelineSummaryProps {
  briefData: OverviewBriefData;
}

// Helper function to generate plain text content for AI summary or other uses
export const generateBriefTextContent = (briefData: OverviewBriefData): string => {
  let text = "Comprehensive Strategy & Timeline Brief\n\n";

  if (briefData.aiSummary) {
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = briefData.aiSummary.replace(/<br\s*\/?>/gi, '\n');
    text += `AI Executive Summary:\n${tempDiv.innerText}\n\n`;
  }
  
  text += "Strategic Pillars:\n";
  briefData.strategicPillars.forEach(pillar => {
    text += `- ${pillar.title}: ${pillar.content}\n`;
  });
  text += "\nMonth-by-Month Timeline Blueprint:\n";
  briefData.monthlySummaries.forEach(summary => {
    text += `\n${summary.month}:\n`;
    text += `  Themes: ${summary.themes.join(', ')}\n`;
    text += `  Content: ${summary.blogCount} Blog Posts, ${summary.videoCount} Videos\n`;
    if(summary.keyContentTitles.length > 0) {
        text += `  Key Titles:\n`;
        summary.keyContentTitles.forEach(title => {
            text += `    - ${title}\n`;
        });
    }
  });
  return text;
};


const StrategicTimelineSummary: React.FC<StrategicTimelineSummaryProps> = ({ briefData }) => {
  return (
    <div className="space-y-6">
      {briefData.aiSummary && (
         <section className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-md">
            <h3 className="text-xl font-semibold mb-2" style={{ color: BRAND_PRIMARY }}>AI Generated Executive Summary</h3>
            <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: briefData.aiSummary }} />
        </section>
      )}

      <section>
        <h3 className="text-xl font-semibold mb-3" style={{ color: BRAND_PRIMARY }}>Strategic Pillars</h3>
        <div className="space-y-3">
          {briefData.strategicPillars.map((pillar, index) => (
            <div key={index} className="pb-2">
              <h4 className="font-semibold text-md text-gray-800">{pillar.title}</h4>
              <p className="text-sm text-gray-600 ml-2">{pillar.content}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-xl font-semibold mb-4" style={{ color: BRAND_PRIMARY }}>Month-by-Month Timeline Blueprint</h3>
        <div className="space-y-4">
          {briefData.monthlySummaries.map((summary) => (
            <div key={summary.month} className="p-3 bg-gray-50 rounded-md border-l-4 border-orange-300">
              <h4 className="text-lg font-semibold" style={{ color: BRAND_SECONDARY }}>{summary.month}</h4>
              <div className="pl-2 mt-1 text-sm">
                <p><strong className="text-gray-700">Themes:</strong> {summary.themes.join(', ')}</p>
                <p><strong className="text-gray-700">Content Planned:</strong> {summary.blogCount} Blog Post(s), {summary.videoCount} Video(s)</p>
                {summary.keyContentTitles.length > 0 && (
                  <div>
                    <strong className="text-gray-700">Key Content Titles:</strong>
                    <ul className="list-disc list-inside ml-2">
                      {summary.keyContentTitles.map((title, i) => <li key={i} className="text-gray-600">{title}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default StrategicTimelineSummary;