
import React, { useEffect, useRef } from 'react';
import { Chart, DoughnutController, ArcElement, Legend, Tooltip, Title } from 'chart.js';
import { CalendarContent } from '../../types';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_BACKGROUND } from '../../constants';

Chart.register(DoughnutController, ArcElement, Legend, Tooltip, Title);

interface ContentMixChartProps {
  calendarData: CalendarContent[];
}

const ContentMixChartComponent: React.FC<ContentMixChartProps> = ({ calendarData }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      const blogCount = calendarData.filter(item => item.type === 'Blog Post').length;
      const videoCount = calendarData.filter(item => item.type === 'YouTube Video').length;

      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
      
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstanceRef.current = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: ['Blog Posts', 'YouTube Videos'],
            datasets: [{
              data: [blogCount, videoCount],
              backgroundColor: [BRAND_PRIMARY, BRAND_SECONDARY],
              borderColor: ['#FFFFFF', '#FFFFFF'], 
              borderWidth: 3, 
              hoverOffset: 8,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '65%', 
            plugins: {
              legend: { 
                position: 'bottom',
                labels: {
                    font: { family: 'Work Sans', size: 12 },
                    color: '#4A5568', 
                    padding: 20,
                },
                
              },
              title: {
                display: true,
                text: 'Planned Content Mix',
                font: { size: 16, family: 'Work Sans', weight: 600 }, 
                color: '#2D3748', 
                padding: { top: 5, bottom: 25 }
              },
              tooltip: {
                bodyFont: { family: 'Work Sans' },
                titleFont: { family: 'Work Sans', weight: 'bold' },
              }
            }
          }
        });
      }
    }
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [calendarData]);

  return (
    <div className="mt-0"> {/* Adjusted margin as parent card handles spacing */}
      <div className="chart-container relative w-full max-w-xs mx-auto h-64 sm:h-72 md:h-80">
        <canvas ref={chartRef}></canvas>
      </div>
    </div>
  );
};

export default ContentMixChartComponent;