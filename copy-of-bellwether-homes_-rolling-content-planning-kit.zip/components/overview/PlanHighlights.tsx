
import React from 'react';
import { BRAND_SECONDARY, BRAND_PRIMARY } from '../../constants';
import { CalendarContent } from '../../types';

interface HighlightCardProps {
  value: string | number;
  label: string;
  icon?: React.ReactNode;
}

const HighlightCard: React.FC<HighlightCardProps> = ({ value, label, icon }) => (
  <div className="bg-white p-5 rounded-xl shadow-lg text-center border border-slate-200 hover:shadow-xl transition-all duration-300 ease-in-out flex flex-col items-center justify-center">
    {icon && <div className={`mb-2 text-[${BRAND_PRIMARY}]`}>{icon}</div>}
    <h3 className="text-3xl md:text-4xl font-bold" style={{ color: BRAND_SECONDARY }}>{value}</h3>
    <p className="text-slate-600 font-medium mt-1.5 text-xs md:text-sm">{label}</p>
  </div>
);

interface PlanHighlightsProps {
  calendarData: CalendarContent[];
}

const PlanHighlights: React.FC<PlanHighlightsProps> = ({ calendarData }) => {
  const totalContent = calendarData.length;
  const inIdeation = calendarData.filter(item => item.status === 'Ideation').length;
  const inProgress = calendarData.filter(item => item.status === 'Drafting' || item.status === 'Review').length;
  const readyOrPublished = calendarData.filter(item => item.status === 'Scheduled' || item.status === 'Published').length;

  return (
    <section id="plan-highlights">
      <h2 className="text-xl md:text-2xl font-bold text-slate-700 mb-5 md:mb-6 text-center">Live Plan Highlights</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <HighlightCard value={totalContent} label="Total Content Items" />
        <HighlightCard value={inIdeation} label="In Ideation Stage" />
        <HighlightCard value={inProgress} label="Drafting / Review" />
        <HighlightCard value={readyOrPublished} label="Scheduled / Published" />
      </div>
    </section>
  );
};

export default PlanHighlights;