
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { AuditEntry, AuditPageProps } from '../../types';
import { INITIAL_AUDIT_DATA, ALL_BLOG_TITLES_FOR_AUDIT, ALL_VIDEO_TITLES_FOR_AUDIT, BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import { PlusIcon, SparklesIcon, CopyIcon } from '../shared/Icons'; 
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';

type AuditViewMode = 'table' | 'pairing' | 'topic' | 'gap';

const AuditPage: React.FC<AuditPageProps> = ({ 
    initialSearchTerm = '', 
    initialRelevanceFilter = 'all',
    onCreateContentIdea 
}) => {
  const [searchTerm, setSearchTerm] = useState(initialSearchTerm);
  const [relevanceFilter, setRelevanceFilter] = useState(initialRelevanceFilter);
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);
  const [currentViewMode, setCurrentViewMode] = useState<AuditViewMode>('table');
  const [copyStatus, setCopyStatus] = useState('');

  const [selectedBlog, setSelectedBlog] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  const [pairedOpportunity, setPairedOpportunity] = useState('');
  const [pairedRelevance, setPairedRelevance] = useState<AuditEntry['relevance']>('None');
  const [topicSearch, setTopicSearch] = useState('');

  useEffect(() => {
    setSearchTerm(initialSearchTerm);
  }, [initialSearchTerm]);

  useEffect(() => {
    setRelevanceFilter(initialRelevanceFilter || 'all');
  }, [initialRelevanceFilter]);

  const filteredAuditData = useMemo(() => {
    return INITIAL_AUDIT_DATA.filter(item => {
      const lowerSearchTerm = searchTerm.toLowerCase();
      const matchesSearch = 
        item.blogTitle.toLowerCase().includes(lowerSearchTerm) ||
        item.videoTitle.toLowerCase().includes(lowerSearchTerm) ||
        item.opportunity.toLowerCase().includes(lowerSearchTerm);
      const matchesRelevance = relevanceFilter === 'all' || item.relevance === relevanceFilter;
      return matchesSearch && matchesRelevance;
    });
  }, [searchTerm, relevanceFilter]);

  const getRelevanceClass = (relevance: string) => {
    switch (relevance) {
      case 'High': return 'bg-green-100 text-green-700 border-green-300';
      case 'Medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'Low': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'None': return 'bg-red-100 text-red-700 border-red-300';
      default: return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };
  
  const showCopyStatus = (message: string) => {
    setCopyStatus(message);
    setTimeout(() => setCopyStatus(''), 2000);
  };

  const exportToCsv = () => {
    const headers = ["Blog Post Title", "Matched YouTube Video", "Relevance", "Opportunity"];
    const rows = filteredAuditData.map(item => [item.blogTitle, item.videoTitle, item.relevance, item.opportunity]);
    
    const processRow = (row: string[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null ? '' : row[j].toString();
            let result = innerValue.replace(/"/g, '""');
            if (result.search(/("|,|\n)/g) >= 0)
                result = '"' + result + '"';
            if (j > 0)
                finalVal += ',';
            finalVal += result;
        }
        return finalVal + '\n';
    };

    let csvFile = processRow(headers);
    for (let i = 0; i < rows.length; i++) {
        csvFile += processRow(rows[i]);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", 'bellwether_content_audit.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  };

  const copyTableAsText = () => {
    const headers = ["Blog Post Title", "Matched YouTube Video", "Relevance", "Opportunity"];
    let tsvText = headers.join('\t') + '\n';
    filteredAuditData.forEach(item => {
        const row = [
            item.blogTitle,
            item.videoTitle || "N/A",
            item.relevance,
            item.opportunity.replace(/\n/g, ' ') // Replace newlines in opportunity for single line TSV
        ];
        tsvText += row.join('\t') + '\n';
    });
    navigator.clipboard.writeText(tsvText.trim())
      .then(() => showCopyStatus('Table data copied (TSV)!'))
      .catch(err => {
        console.error('Failed to copy table data: ', err);
        showCopyStatus('Failed to copy');
      });
  };
  
  const getPotentialMatches = useCallback((title: string, listToSearch: string[]): string[] => {
    if (!title) return [];
    const titleWords = title.toLowerCase().split(/\s+/).filter(w => w.length > 3 && !['james', 'hardie', 'colorado', 'denver', 'siding', 'windows', 'doors', 'bellwether', 'what', 'are', 'the', 'pros', 'cons', 'and', 'for', 'your', 'how', 'with'].includes(w));
    return listToSearch.filter(item => {
      const itemLower = item.toLowerCase();
      return titleWords.some(word => itemLower.includes(word));
    }).slice(0, 10);
  }, []);

  useEffect(() => {
    if (selectedBlog) {
      const existingAuditEntry = INITIAL_AUDIT_DATA.find(entry => entry.blogTitle === selectedBlog);
      if (existingAuditEntry) {
        setSelectedVideo(existingAuditEntry.videoTitle);
        setPairedOpportunity(existingAuditEntry.opportunity);
        setPairedRelevance(existingAuditEntry.relevance);
      } else {
        const matches = getPotentialMatches(selectedBlog, ALL_VIDEO_TITLES_FOR_AUDIT);
        setSelectedVideo(matches.length > 0 ? matches[0] : null);
        setPairedOpportunity(matches.length > 0 ? `Potential match found. Assess opportunity for video '${matches[0]}' to support blog.` : 'No direct video match. Opportunity for new video or re-alignment.');
        setPairedRelevance(matches.length > 0 ? 'Medium' : 'None');
      }
    } else {
      setPairedOpportunity('');
      setPairedRelevance('None');
    }
  }, [selectedBlog, getPotentialMatches]);

  useEffect(() => {
    if (selectedVideo) {
      const existingAuditEntry = INITIAL_AUDIT_DATA.find(entry => entry.videoTitle === selectedVideo);
      if (existingAuditEntry && !selectedBlog) {
        setSelectedBlog(existingAuditEntry.blogTitle);
        setPairedOpportunity(existingAuditEntry.opportunity);
        setPairedRelevance(existingAuditEntry.relevance);
      } else if (!selectedBlog) {
         const matches = getPotentialMatches(selectedVideo, ALL_BLOG_TITLES_FOR_AUDIT);
         setPairedOpportunity(matches.length > 0 ? `Potential match. Assess if blog '${matches[0]}' is supported by this video.` : 'No direct blog match. Opportunity for new blog or re-alignment.');
         setPairedRelevance(matches.length > 0 ? 'Medium' : 'None');
      }
    }
  }, [selectedVideo, selectedBlog, getPotentialMatches]);

  const topicFilteredBlogs = useMemo(() => {
    if (!topicSearch) return ALL_BLOG_TITLES_FOR_AUDIT.slice(0,25);
    const lowerTopic = topicSearch.toLowerCase();
    return ALL_BLOG_TITLES_FOR_AUDIT.filter(title => title.toLowerCase().includes(lowerTopic));
  }, [topicSearch]);

  const topicFilteredVideos = useMemo(() => {
    if (!topicSearch) return ALL_VIDEO_TITLES_FOR_AUDIT.slice(0,25);
    const lowerTopic = topicSearch.toLowerCase();
    return ALL_VIDEO_TITLES_FOR_AUDIT.filter(title => title.toLowerCase().includes(lowerTopic));
  }, [topicSearch]);

  const contentGaps = useMemo(() => {
    const blogsWithoutDirectAuditVideo = ALL_BLOG_TITLES_FOR_AUDIT.filter(blog => 
        !INITIAL_AUDIT_DATA.some(entry => entry.blogTitle === blog && entry.videoTitle && entry.videoTitle !== "None Directly Matching")
    );
    const videosWithoutDirectAuditBlog = ALL_VIDEO_TITLES_FOR_AUDIT.filter(video => 
        !INITIAL_AUDIT_DATA.some(entry => entry.videoTitle === video && entry.blogTitle)
    );
    return { blogsWithoutDirectAuditVideo, videosWithoutDirectAuditBlog };
  }, []);

  const viewModeButtonClasses = "px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-colors duration-200 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#DD5B42]";
  const exportButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`;
  const copyButtonClasses = `bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-slate-500 flex items-center gap-1.5`;
  const createIdeaButtonClasses = `bg-sky-500 hover:bg-sky-600 text-white px-2.5 py-1 rounded-md text-xs font-semibold transition-colors duration-200 flex items-center gap-1 shadow-sm hover:shadow-md focus:outline-none focus:ring-1 focus:ring-sky-400`;
  const inputBaseClasses = "w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-800 text-sm shadow-sm";

  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
            <h2 className="text-xl md:text-2xl font-bold text-slate-800">Content Audit Dashboard</h2>
            <p className="text-sm text-slate-500 mt-1">Analyze content alignment and discover opportunities.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0" />
      </div>
      
      <div className="mb-6 flex flex-wrap gap-2">
        {(['table', 'pairing', 'topic', 'gap'] as AuditViewMode[]).map(mode => (
          <button 
            key={mode}
            onClick={() => setCurrentViewMode(mode)}
            className={`${viewModeButtonClasses} ${currentViewMode === mode ? `bg-[${BRAND_SECONDARY}] text-white` : `bg-slate-200 text-slate-700 hover:bg-slate-300`}`}
          >
            {mode.charAt(0).toUpperCase() + mode.slice(1)} View
          </button>
        ))}
      </div>

      {currentViewMode === 'table' && (
        <>
          <div className="mb-4 flex flex-col sm:flex-row gap-4 items-center p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
            <input 
              type="text" 
              id="auditSearch" 
              placeholder="Search titles or keywords in table..." 
              className={`${inputBaseClasses} sm:flex-grow`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search audit content"
            />
            <select 
              id="relevanceFilter" 
              className={`${inputBaseClasses} sm:w-auto`}
              value={relevanceFilter}
              onChange={(e) => setRelevanceFilter(e.target.value)}
              aria-label="Filter by relevance"
            >
              <option value="all">Filter by Relevance</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
              <option value="None">None (Clear Opportunity)</option>
            </select>
            <button onClick={exportToCsv} className={`${exportButtonClasses} w-full sm:w-auto`}>Export Table CSV</button>
            <button onClick={copyTableAsText} className={`${copyButtonClasses} w-full sm:w-auto`}>
                <CopyIcon className="w-3.5 h-3.5" /> Copy Table Text
            </button>
            {copyStatus && <span className="text-xs text-green-600 font-semibold">{copyStatus}</span>}
          </div>
          <div className="overflow-x-auto bg-white rounded-lg shadow-md border border-slate-200">
            <table className="w-full text-sm text-left text-slate-600">
              <thead className="text-xs text-slate-700 uppercase bg-slate-100 border-b border-slate-300">
                <tr>
                  <th scope="col" className="px-5 py-3">Blog Post Title</th>
                  <th scope="col" className="px-5 py-3">Matched YouTube Video</th>
                  <th scope="col" className="px-5 py-3 text-center">Relevance</th>
                  <th scope="col" className="px-5 py-3">Identified Opportunity / Notes</th>
                  <th scope="col" className="px-5 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredAuditData.map((item, index) => (
                  <tr key={index} className={`${index % 2 === 0 ? 'bg-white' : 'bg-slate-50'} border-b border-slate-100 hover:bg-orange-50 transition-colors duration-150`}>
                    <td className="px-5 py-3 font-medium text-slate-800">{item.blogTitle}</td>
                    <td className="px-5 py-3">{item.videoTitle || <span className="italic text-slate-400">No direct match</span>}</td>
                    <td className="px-5 py-3 text-center">
                      <span className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${getRelevanceClass(item.relevance)}`}>
                        {item.relevance}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-slate-700 text-xs">{item.opportunity}</td>
                    <td className="px-5 py-3 text-center">
                      <button 
                        onClick={() => onCreateContentIdea(item.blogTitle, item.opportunity)}
                        className={createIdeaButtonClasses}
                        title="Create a new content idea based on this audit item"
                      >
                        <PlusIcon className="w-3 h-3"/> Create Idea
                      </button>
                    </td>
                  </tr>
                ))}
                 {filteredAuditData.length === 0 && (
                    <tr>
                        <td colSpan={5} className="text-center py-10 text-slate-500 italic">No audit entries match your current filters.</td>
                    </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {currentViewMode === 'pairing' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
          <div className="md:col-span-1">
            <h4 className="font-semibold text-slate-700 mb-2 text-sm">Blog Posts ({ALL_BLOG_TITLES_FOR_AUDIT.length})</h4>
            <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
              {ALL_BLOG_TITLES_FOR_AUDIT.map(title => (
                <button key={title} onClick={() => setSelectedBlog(title)} className={`block w-full text-left p-1.5 text-xs rounded hover:bg-orange-100 transition-colors ${selectedBlog === title ? 'bg-orange-200 font-semibold text-[#DD5B42]' : 'text-slate-700'}`}>
                  {title}
                </button>
              ))}
            </div>
          </div>
          <div className="md:col-span-1">
            <h4 className="font-semibold text-slate-700 mb-2 text-sm">YouTube Videos ({ALL_VIDEO_TITLES_FOR_AUDIT.length})</h4>
            <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
              {ALL_VIDEO_TITLES_FOR_AUDIT.map(title => (
                <button key={title} onClick={() => setSelectedVideo(title)} className={`block w-full text-left p-1.5 text-xs rounded hover:bg-orange-100 transition-colors ${selectedVideo === title ? 'bg-orange-200 font-semibold text-[#DD5B42]' : 'text-slate-700'}`}>
                  {title}
                </button>
              ))}
            </div>
          </div>
          <div className="md:col-span-1 p-3 bg-orange-50 rounded-lg border border-orange-200 shadow-sm">
            <h4 className="font-semibold text-slate-700 mb-2 text-sm">Pairing Details & Opportunity</h4>
            {selectedBlog || selectedVideo ? (
              <>
                <p className="text-xs mb-1 text-slate-600"><strong>Selected Blog:</strong> {selectedBlog || 'None'}</p>
                <p className="text-xs mb-2 text-slate-600"><strong>Selected Video:</strong> {selectedVideo || 'None'}</p>
                <label htmlFor="pairedRelevance" className="block text-xs font-medium text-slate-700 mt-2">Relevance:</label>
                <select id="pairedRelevance" value={pairedRelevance} onChange={e => setPairedRelevance(e.target.value as AuditEntry['relevance'])} className={`${inputBaseClasses} !text-xs !p-1.5 mb-2`}>
                  <option value="High">High</option><option value="Medium">Medium</option><option value="Low">Low</option><option value="None">None</option>
                </select>
                <label htmlFor="pairedOpportunity" className="block text-xs font-medium text-slate-700">Opportunity/Notes:</label>
                <textarea value={pairedOpportunity} onChange={e => setPairedOpportunity(e.target.value)} rows={4} className={`${inputBaseClasses} !text-xs !p-1.5 mb-2`}/>
                <button 
                  onClick={() => onCreateContentIdea(selectedBlog || selectedVideo || "New Idea from Pairing", pairedOpportunity)}
                  className={`${createIdeaButtonClasses} w-full mt-1`}
                  disabled={(!selectedBlog && !selectedVideo) || !pairedOpportunity}
                >
                  <PlusIcon className="w-3.5 h-3.5"/> Create Idea from Pairing
                </button>
              </>
            ) : <p className="text-xs text-slate-500 italic mt-2">Select a blog or video to see details.</p>}
          </div>
        </div>
      )}

      {currentViewMode === 'topic' && (
         <div className="p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
            <input 
              type="text" 
              placeholder="Search by topic, keyword, or theme..." 
              value={topicSearch}
              onChange={(e) => setTopicSearch(e.target.value)}
              className={`${inputBaseClasses} mb-4`}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <h4 className="font-semibold text-slate-700 mb-2 text-sm">Blog Posts matching "{topicSearch || 'All'}"</h4>
                <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
                  {topicFilteredBlogs.map(title => <p key={title} className="text-xs p-1.5 border-b border-slate-100 last:border-b-0 text-slate-700">{title}</p>)}
                  {topicFilteredBlogs.length === 0 && <p className="text-xs text-slate-400 italic p-2">No blogs match.</p>}
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-slate-700 mb-2 text-sm">Videos matching "{topicSearch || 'All'}"</h4>
                <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
                  {topicFilteredVideos.map(title => <p key={title} className="text-xs p-1.5 border-b border-slate-100 last:border-b-0 text-slate-700">{title}</p>)}
                  {topicFilteredVideos.length === 0 && <p className="text-xs text-slate-400 italic p-2">No videos match.</p>}
                </div>
              </div>
            </div>
         </div>
      )}

      {currentViewMode === 'gap' && (
        <div className="p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
            <h3 className="text-md font-semibold text-slate-800 mb-2">Content Gap Overview</h3>
            <p className="text-xs text-slate-500 mb-3">Lists content without a direct match in the initial audit data. Review for opportunities.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                    <h4 className="font-semibold text-slate-700 mb-2 text-sm">Blog Posts Potentially Missing Videos ({contentGaps.blogsWithoutDirectAuditVideo.length})</h4>
                    <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
                        {contentGaps.blogsWithoutDirectAuditVideo.map(title => (
                            <div key={title} className="text-xs p-1.5 border-b border-slate-100 flex justify-between items-center text-slate-700 hover:bg-slate-50">
                                <span>{title}</span>
                                <button onClick={() => onCreateContentIdea(title, `Create video for blog: ${title}`)} className={`${createIdeaButtonClasses} !text-[10px] !px-1.5 !py-0.5`} title="Create new video idea">
                                    <PlusIcon className="w-3 h-3"/> Idea
                                </button>
                            </div>
                        ))}
                         {contentGaps.blogsWithoutDirectAuditVideo.length === 0 && <p className="text-xs text-slate-400 italic p-2">All blogs have an audit entry with a video.</p>}
                    </div>
                </div>
                <div>
                    <h4 className="font-semibold text-slate-700 mb-2 text-sm">Videos Potentially Missing Blog Posts ({contentGaps.videosWithoutDirectAuditBlog.length})</h4>
                    <div className="h-96 overflow-y-auto border p-2 rounded-md bg-white shadow-sm custom-scrollbar">
                        {contentGaps.videosWithoutDirectAuditBlog.map(title => (
                             <div key={title} className="text-xs p-1.5 border-b border-slate-100 flex justify-between items-center text-slate-700 hover:bg-slate-50">
                                <span>{title}</span>
                                <button onClick={() => onCreateContentIdea(title, `Create blog post for video: ${title}`)} className={`${createIdeaButtonClasses} !text-[10px] !px-1.5 !py-0.5`} title="Create new blog idea">
                                     <PlusIcon className="w-3 h-3"/> Idea
                                </button>
                            </div>
                        ))}
                        {contentGaps.videosWithoutDirectAuditBlog.length === 0 && <p className="text-xs text-slate-400 italic p-2">All videos have an audit entry with a blog.</p>}
                    </div>
                </div>
            </div>
        </div>
      )}

      <HelpPanel
        title="Using the Content Audit Dashboard"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Identify Gaps & Opportunities with Multiple Views</h4>
        <p>This tool helps you analyze existing blog posts and YouTube videos for alignment and uncover potential new content ideas using various views.</p>
        <ul>
            <li><strong>View Modes:</strong> Switch between:
                <ul>
                    <li><strong>Table View:</strong> The original audit table with search, filter, and CSV export. Use "Create Idea" to send opportunities to the Content Calendar. Use "Copy Table Text" to copy the visible table data as Tab-Separated Values.</li>
                    <li><strong>Pairing View:</strong> Interactively select blogs and videos to find potential matches. Assess relevance and opportunity, then create content ideas.</li>
                    <li><strong>Topic View:</strong> Search for a topic/keyword to see all related blog posts and videos side-by-side. Helps identify topical coverage and imbalances.</li>
                    <li><strong>Gap View:</strong> Lists blog posts and videos that don't have a direct counterpart in the `INITIAL_AUDIT_DATA`, highlighting potential gaps for new content creation.</li>
                </ul>
            </li>
            <li><strong>Create Content Idea:</strong> In most views, you can click "Create Idea" or a similar button. This will:
            <ul>
              <li>Generate a new content item in the "Ideation" stage on the Content Calendar.</li>
              <li>Pre-fill its title and brief based on the audit item/opportunity.</li>
              <li>Open the AI-powered modal for this new idea for immediate refinement.</li>
            </ul>
          </li>
        </ul>
      </HelpPanel>
    </div>
  );
};

export default AuditPage;