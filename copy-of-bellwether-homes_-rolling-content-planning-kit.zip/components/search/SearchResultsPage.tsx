
import React from 'react';
import { SearchResult, SearchResultItemType } from '../../types';
import SearchResultItemComponent from './SearchResultItem';
import { BRAND_SECONDARY, BRAND_PRIMARY } from '../../constants';

interface SearchResultsPageProps {
  results: SearchResult[];
  searchTerm: string;
  onResultClick: (result: SearchResult) => void;
}

const SearchResultsPage: React.FC<SearchResultsPageProps> = ({ results, searchTerm, onResultClick }) => {
  if (!searchTerm) {
    return (
      <div className="text-center py-10 bg-white p-6 rounded-xl shadow-xl border border-slate-200">
        <p className="text-slate-600 text-lg">Please enter a term in the search bar above to find content.</p>
      </div>
    );
  }

  const groupedResults = results.reduce((acc, result) => {
    (acc[result.type] = acc[result.type] || []).push(result);
    return acc;
  }, {} as Record<SearchResultItemType, SearchResult[]>);

  const resultOrder: SearchResultItemType[] = ['calendar', 'audit', 'strategy'];

  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-2">
        Search Results for: <span className="text-[#DD5B42]">{searchTerm}</span>
      </h2>
      <p className="mb-6 text-sm text-slate-500">Found {results.length} item(s).</p>

      {results.length === 0 && (
        <p className="text-slate-500 text-center py-8 italic">No results found matching your query.</p>
      )}

      {resultOrder.map(type => {
        const items = groupedResults[type];
        if (items && items.length > 0) {
          const typeLabelMapping: Record<SearchResultItemType, string> = {
            calendar: 'Calendar Content',
            audit: 'Content Audit Entries',
            strategy: 'Strategic Blueprints',
          };
          const typeColorMapping: Record<SearchResultItemType, string> = {
            calendar: BRAND_PRIMARY,
            audit: '#F59E0B', // amber-500
            strategy: '#10B981', // emerald-500
          };
          return (
            <section key={type} className="mb-8">
              <h3 className="text-lg md:text-xl font-semibold mb-4 pb-2 border-b-2"
                  style={{ color: typeColorMapping[type], borderColor: typeColorMapping[type] + '40' }}>
                {typeLabelMapping[type]} <span className="text-xs text-slate-500">({items.length})</span>
              </h3>
              <div className="space-y-3">
                {items.map(result => (
                  <SearchResultItemComponent key={`${result.type}-${result.id}`} result={result} onResultClick={onResultClick} />
                ))}
              </div>
            </section>
          );
        }
        return null;
      })}
    </div>
  );
};

export default SearchResultsPage;