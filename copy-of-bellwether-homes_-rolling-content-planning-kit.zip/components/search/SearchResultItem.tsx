
import React from 'react';
import { SearchResult } from '../../types';
import { BRAND_PRIMARY } from '../../constants';

interface SearchResultItemProps {
  result: SearchResult;
  onResultClick: (result: SearchResult) => void;
}

const SearchResultItemComponent: React.FC<SearchResultItemProps> = ({ result, onResultClick }) => {
  const typeLabelMapping: Record<SearchResult['type'], string> = {
    calendar: 'Calendar Content',
    audit: 'Content Audit',
    strategy: 'Strategic Blueprint',
  };
  const typeColorMapping: Record<SearchResult['type'], string> = {
    calendar: 'bg-sky-100 text-sky-700',
    audit: 'bg-amber-100 text-amber-700',
    strategy: 'bg-emerald-100 text-emerald-700',
  };

  return (
    <button
      onClick={() => onResultClick(result)}
      className="w-full text-left p-4 mb-2 bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 ease-in-out border border-slate-200 hover:border-[#DD5B42] focus:outline-none focus:ring-2 focus:ring-[#DD5B42] focus:ring-offset-1 group"
      aria-label={`View details for search result: ${result.title}`}
    >
      <div className="flex justify-between items-start mb-1.5">
        <h4 className="font-semibold text-slate-800 text-md group-hover:text-[#DD5B42] transition-colors">{result.title}</h4>
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${typeColorMapping[result.type]}`}>
          {typeLabelMapping[result.type]}
        </span>
      </div>
      <p className="text-sm text-slate-600 line-clamp-2">{result.description}</p>
    </button>
  );
};

export default SearchResultItemComponent;