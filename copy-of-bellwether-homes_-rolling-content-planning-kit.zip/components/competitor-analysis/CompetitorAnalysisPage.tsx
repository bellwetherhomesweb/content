
import React, { useState, useCallback } from 'react';
import {
  Competitor,
  CompetitorContentMapEntry,
  CalendarContent,
  AIAnalysisState,
  CompetitorAnalysisContext,
  GroundingChunk
} from '../../types';
import { COMPETITORS, COMPETITOR_CONTENT_MAP_DATA, BRAND_PRIMARY } from '../../constants';
import CompetitorMapTable from './CompetitorMapTable';
import AIAnalysisToolbelt from './AIAnalysisToolbelt';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';
import { generateGeminiText } from '../../services/geminiService';
import { CopyIcon } from '../shared/Icons';
import { logAppAction } from '../../services/loggingService';

interface CompetitorAnalysisPageProps {
  calendarData: CalendarContent[];
}

const CompetitorAnalysisPage: React.FC<CompetitorAnalysisPageProps> = ({ calendarData }) => {
  const [aiAnalysisState, setAiAnalysisState] = useState<AIAnalysisState>({
    isLoading: false,
    resultText: null, // Ensure it's null initially
    error: undefined,
    groundingChunks: [],
  });
  const [currentAnalysisContext, setCurrentAnalysisContext] = useState<CompetitorAnalysisContext | null>(null);
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);
  const [copyStatus, setCopyStatus] = useState('');

  const handleStartAIAnalysis = useCallback((context: CompetitorAnalysisContext) => {
    setCurrentAnalysisContext(context);
    setAiAnalysisState({ isLoading: false, resultText: null, error: undefined, groundingChunks: [] });
    const toolbeltElement = document.getElementById('ai-toolbelt-section');
    if (toolbeltElement) {
      toolbeltElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  const handleClearAIContext = useCallback(() => {
    setCurrentAnalysisContext(null);
    setAiAnalysisState({ isLoading: false, resultText: null, error: undefined, groundingChunks: [] });
  }, []);

  const handlePerformAIAnalysis = useCallback(async (
    promptType: 'differentiate' | 'strengths' | 'opportunities' | 'custom_search', 
    customBellwetherItemId?: string, 
    competitorContent?: string
  ) => {
    if (!currentAnalysisContext) return;

    setAiAnalysisState({ isLoading: true, resultText: null, error: undefined, groundingChunks: [] });

    let prompt = `You are a senior content marketing strategist for Bellwether Homes, a premium Colorado exterior remodeler.
    Your task is to analyze competitor content.
    Competitor: ${currentAnalysisContext.competitor.name}
    Content Type: ${currentAnalysisContext.contentType}
    ${currentAnalysisContext.subCategoryName ? `Sub-Category: ${currentAnalysisContext.subCategoryName}` : ''}
    `;
    
    if (competitorContent) {
        prompt += `\nCompetitor Content/URL for Analysis: "${competitorContent}"\n`;
    } else {
        prompt += `\n(No specific competitor content URL/snippet provided. Rely on general knowledge and web search if needed for ${currentAnalysisContext.competitor.name}'s content in this area.)\n`;
    }
    
    let useSearch = true; 

    switch (promptType) {
      case 'strengths':
        prompt += `\nTask: Based on the provided competitor content/URL (or public information - perform Google Search), identify key strengths and successful content strategies of ${currentAnalysisContext.competitor.name} for this content type/category in Colorado. What makes their content effective? Provide a concise analysis.`;
        break;
      case 'opportunities':
        prompt += `\nBellwether Homes aims to be the leading expert.
        Task: Based on the competitor content/URL (or public information about ${currentAnalysisContext.competitor.name}'s content via Google Search), identify content gaps or opportunities for Bellwether Homes. Where can Bellwether provide superior value, depth, or a unique Colorado-centric angle?`;
        break;
      case 'differentiate':
        const bellwetherItem = calendarData.find(item => item.id === customBellwetherItemId);
        if (!bellwetherItem) {
          setAiAnalysisState({ isLoading: false, resultText: null, error: "Selected Bellwether item not found.", groundingChunks: [] });
          return;
        }
        prompt += `\nBellwether Content Piece for Comparison:
        Title: "${bellwetherItem.title}" | Type: ${bellwetherItem.type} | Brief: "${bellwetherItem.brief}"

        Task: Analyze how Bellwether's content can effectively differentiate from ${currentAnalysisContext.competitor.name}'s offerings (using the competitor content/URL or Google Search for context). Suggest 3-5 specific, actionable ways Bellwether can highlight its unique value, Colorado expertise, or premium quality.`;
        break;
      case 'custom_search': 
         setAiAnalysisState({ isLoading: false, resultText: 'Web search for URLs is handled directly in the toolbelt. Paste a URL or text for analysis.', error: undefined, groundingChunks: [] });
        return;
    }

    prompt += "\nFocus on actionable insights. Be specific and tailor advice to the Colorado market.";
    
    const result = await generateGeminiText(prompt, useSearch, "You are a marketing expert specializing in home improvement content.");
    
    setAiAnalysisState({
        isLoading: false, 
        resultText: result.text, 
        error: result.error,
        groundingChunks: result.groundingChunks?.filter(chunk => chunk.web && chunk.web.uri && chunk.web.title)
    });

  }, [currentAnalysisContext, calendarData]);

  const showCopyStatus = (message: string) => {
    setCopyStatus(message);
    setTimeout(() => setCopyStatus(''), 2000);
  };

  const handleCopyMapAsText = () => {
    let text = "Content Type / Sub-Category\t";
    text += COMPETITORS.map(c => c.name).join('\t') + "\tBellwether Homes (Planned)\tOpportunity/Gap\n";

    COMPETITOR_CONTENT_MAP_DATA.forEach(entry => {
        text += `${entry.contentType}\t${'\t'.repeat(COMPETITORS.length + 2)}\n`; // Main content type row
        if (entry.subCategories) {
            entry.subCategories.forEach(sub => {
                text += `${sub.name}\t`;
                COMPETITORS.forEach(comp => {
                    const assessment = sub.competitorAssessments[comp.id];
                    text += assessment ? `${assessment.strength} (${assessment.notes.replace(/\n/g, ' ')})` : "-";
                    text += "\t";
                });
                text += `${sub.bellwetherAssessment.strength} (${sub.bellwetherAssessment.notes.replace(/\n/g, ' ')})\t`;
                text += `${sub.opportunityGap.replace(/\n/g, ' ')}\n`;
            });
        } else { // Top-level content type without sub-categories
            text += `${entry.contentType} (General)\t`;
            COMPETITORS.forEach(comp => {
                const assessment = entry.competitorAssessments ? entry.competitorAssessments[comp.id] : undefined;
                text += assessment ? `${assessment.strength} (${assessment.notes.replace(/\n/g, ' ')})` : "-";
                text += "\t";
            });
            if (entry.bellwetherAssessment) {
                 text += `${entry.bellwetherAssessment.strength} (${entry.bellwetherAssessment.notes.replace(/\n/g, ' ')})\t`;
            } else {
                text += "-\t";
            }
            text += `${entry.opportunityGap ? entry.opportunityGap.replace(/\n/g, ' ') : '-'}\n`;
        }
    });

    navigator.clipboard.writeText(text.trim())
      .then(() => showCopyStatus('Map data copied (TSV)!'))
      .catch(err => {
        console.error('Failed to copy map data: ', err);
        showCopyStatus('Failed to copy');
      });
    logAppAction({ actionType: 'Export Data', pageContext: 'competitor-analysis', details: { exportType: 'Copy Map TSV' } });
  };


  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Competitor Content Landscape</h2>
          <p className="text-sm text-slate-500 mt-1">Map and analyze competitor content to identify strategic opportunities.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0"/>
      </div>
      <p className="mb-3 text-sm text-slate-600 p-4 bg-slate-50 rounded-lg border border-slate-200 shadow-inner">
        Use the table to understand competitor content efforts. Click "✨ Analyze with AI" to populate the AI Toolbelt below for deeper insights using specific competitor URLs or text snippets.
      </p>
      <div className="mb-6 flex items-center gap-3">
        <button 
            onClick={handleCopyMapAsText} 
            className={`bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-slate-500 flex items-center gap-1.5`}
        >
          <CopyIcon className="w-4 h-4" /> Copy Map as Text
        </button>
        {copyStatus && <span className="text-xs font-semibold text-green-600">{copyStatus}</span>}
      </div>


      <div className="bg-slate-50 p-0 sm:p-4 rounded-lg shadow-inner border border-slate-200">
        <CompetitorMapTable
            competitors={COMPETITORS}
            mapData={COMPETITOR_CONTENT_MAP_DATA}
            onStartAIAnalysis={handleStartAIAnalysis}
        />
      </div>


      <div id="ai-toolbelt-section" className="mt-8 md:mt-10">
        {currentAnalysisContext && (
          <AIAnalysisToolbelt
            analysisState={aiAnalysisState}
            context={currentAnalysisContext}
            onPerformAnalysis={handlePerformAIAnalysis}
            onClearContext={handleClearAIContext}
            bellwetherContentItems={calendarData}
          />
        )}
      </div>
      <HelpPanel
        title="Using the Competitor Analysis Tool"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Analyze and Outsmart the Competition</h4>
        <p>This tool helps you understand what your competitors are doing and identify opportunities for Bellwether Homes to shine.</p>
        <ul>
          <li><strong>Competitor Map Table:</strong> Click "✨ Analyze with AI" in a cell to set context for the AI Toolbelt.</li>
          <li><strong>Copy Map:</strong> Use the "Copy Map as Text" button to copy the table data as tab-separated values.</li>
          <li><strong>AI Analysis Toolbelt:</strong> Appears when context is set.
            <ul>
                <li><strong>Custom Web Search:</strong> Enter a query and click "🔍 Search Web". AI lists top URLs. Click a URL to populate the "Competitor Content" field.</li>
                <li><strong>Competitor Content (URL or Snippet):</strong> Paste a competitor's URL or text here for AI analysis.</li>
                <li><strong>Bellwether Content (for Differentiation):</strong> Optionally, select Bellwether's content for comparative analysis.</li>
                <li><strong>AI Actions:</strong> Analyze competitor strengths, find Bellwether opportunities, or suggest differentiation strategies. The AI will output textual analysis.</li>
            </ul>
          </li>
        </ul>
        <p>Direct client-side website crawling of multiple pages is not feasible. This tool helps find specific competitor URLs for targeted analysis by Gemini.</p>
      </HelpPanel>
    </div>
  );
};

export default CompetitorAnalysisPage;