
import React from 'react';
import { Competitor, CompetitorContentMapEntry, CompetitorContentAssessment, CompetitorAnalysisContext } from '../../types';
import { BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import { SparklesIcon } from '../shared/Icons';

interface CompetitorMapTableProps {
  competitors: Competitor[];
  mapData: CompetitorContentMapEntry[];
  onStartAIAnalysis: (context: CompetitorAnalysisContext) => void;
}

const StrengthBadge: React.FC<{ strength: CompetitorContentAssessment['strength'] }> = ({ strength }) => {
  let bgColor = 'bg-slate-200';
  let textColor = 'text-slate-700';
  let borderColor = 'border-slate-300';
  switch (strength) {
    case 'High': bgColor = 'bg-green-100'; textColor = 'text-green-800'; borderColor = 'border-green-300'; break;
    case 'Medium': bgColor = 'bg-yellow-100'; textColor = 'text-yellow-800'; borderColor = 'border-yellow-300'; break;
    case 'Low': bgColor = 'bg-red-100'; textColor = 'text-red-800'; borderColor = 'border-red-300'; break;
    case 'None': bgColor = 'bg-slate-100'; textColor = 'text-slate-500'; borderColor = 'border-slate-200'; break;
  }
  return <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${bgColor} ${textColor} border ${borderColor} shadow-xs`}>{strength}</span>;
};


const CompetitorMapTable: React.FC<CompetitorMapTableProps> = ({ competitors, mapData, onStartAIAnalysis }) => {
  const aiButtonClasses = "mt-2 text-xs bg-sky-500 hover:bg-sky-600 text-white px-2.5 py-1.5 rounded-md transition-colors text-center block w-full shadow-sm hover:shadow-md flex items-center justify-center gap-1 focus:outline-none focus:ring-1 focus:ring-sky-400";
  
  return (
    <div className="overflow-x-auto rounded-lg shadow-md border border-slate-200">
      <table className="w-full min-w-[1200px] text-sm text-left text-slate-700 border-collapse">
        <thead className="text-xs text-white uppercase" style={{ backgroundColor: BRAND_SECONDARY }}>
          <tr>
            <th scope="col" className="px-5 py-3.5 border-r border-slate-500">Content Type / Sub-Category</th>
            {competitors.map(comp => (
              <th key={comp.id} scope="col" className="px-5 py-3.5 border-r border-slate-500 min-w-[220px]">{comp.name}</th>
            ))}
            <th scope="col" className="px-5 py-3.5 border-r border-slate-500 min-w-[220px]" style={{backgroundColor: BRAND_PRIMARY}}>Bellwether Homes (Planned)</th>
            <th scope="col" className="px-5 py-3.5 min-w-[220px]">Opportunity/Gap</th>
          </tr>
        </thead>
        <tbody className="bg-white">
          {mapData.map((entry, index) => (
            <React.Fragment key={index}>
              <tr className="bg-orange-50 font-semibold text-slate-700 border-b-2 border-orange-200">
                <td colSpan={competitors.length + 3} className="px-5 py-3 ">{entry.contentType}</td>
              </tr>
              {entry.subCategories ? entry.subCategories.map((sub, subIndex) => (
                <tr key={`${index}-${subIndex}`} className="hover:bg-slate-50 border-b border-slate-100 last:border-b-0">
                  <td className="px-5 py-3 border-r border-slate-200 pl-8 align-top font-medium text-slate-800">{sub.name}</td>
                  {competitors.map(comp => {
                    const assessment = sub.competitorAssessments[comp.id];
                    return (
                      <td key={comp.id} className="px-5 py-3 border-r border-slate-200 align-top">
                        {assessment ? (
                          <>
                            <StrengthBadge strength={assessment.strength} />
                            <p className="text-xs text-slate-600 mt-1.5">{assessment.notes}</p>
                            <button 
                              onClick={() => onStartAIAnalysis({ competitor: comp, contentType: entry.contentType, subCategoryName: sub.name })}
                              className={aiButtonClasses}
                            >
                              <SparklesIcon className="w-3 h-3"/> Analyze
                            </button>
                          </>
                        ) : <span className="text-slate-400">-</span>}
                      </td>
                    );
                  })}
                  <td className="px-5 py-3 border-r border-slate-200 align-top bg-green-50">
                     <StrengthBadge strength={sub.bellwetherAssessment.strength} />
                     <p className="text-xs text-slate-600 mt-1.5">{sub.bellwetherAssessment.notes}</p>
                  </td>
                  <td className="px-5 py-3 align-top text-xs text-slate-600">{sub.opportunityGap}</td>
                </tr>
              )) : (
                <tr className="hover:bg-slate-50 border-b border-slate-100 last:border-b-0">
                  <td className="px-5 py-3 border-r border-slate-200 font-medium align-top text-slate-800">{entry.contentType} (General)</td>
                   {competitors.map(comp => {
                    const assessment = entry.competitorAssessments ? entry.competitorAssessments[comp.id] : undefined;
                    return (
                      <td key={comp.id} className="px-5 py-3 border-r border-slate-200 align-top">
                        {assessment ? (
                          <>
                            <StrengthBadge strength={assessment.strength} />
                            <p className="text-xs text-slate-600 mt-1.5">{assessment.notes}</p>
                            <button 
                              onClick={() => onStartAIAnalysis({ competitor: comp, contentType: entry.contentType })}
                              className={aiButtonClasses}
                            >
                             <SparklesIcon className="w-3 h-3"/> Analyze
                            </button>
                          </>
                        ) : <span className="text-slate-400">-</span>}
                      </td>
                    );
                  })}
                  <td className="px-5 py-3 border-r border-slate-200 align-top bg-green-50">
                    {entry.bellwetherAssessment && (
                        <>
                        <StrengthBadge strength={entry.bellwetherAssessment.strength} />
                        <p className="text-xs text-slate-600 mt-1.5">{entry.bellwetherAssessment.notes}</p>
                        </>
                    )}
                  </td>
                  <td className="px-5 py-3 align-top text-xs text-slate-600">{entry.opportunityGap}</td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CompetitorMapTable;