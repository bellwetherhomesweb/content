
import React, { useState, useEffect } from 'react';
import { AIAnalysisState, CompetitorAnalysisContext, CalendarContent, GroundingChunk, GeminiTextResult } from '../../types';
import Loader from '../shared/Loader';
import { ExternalLinkIcon, SparklesIcon } from '../shared/Icons';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_TEXT_PRIMARY, BRAND_ORANGE_LIGHT } from '../../constants';
import { generateGeminiText } from '../../services/geminiService';
import AIContentDisplay from '../shared/AIContentDisplay';
import { logAppAction } from '../../services/loggingService';

interface LiveSearchResult {
  title: string;
  url: string;
}

interface AIAnalysisToolbeltProps {
  analysisState: AIAnalysisState; 
  context: CompetitorAnalysisContext | null;
  onPerformAnalysis: (promptType: 'differentiate' | 'strengths' | 'opportunities' | 'custom_search', customBellwetherItemId?: string, customSearchQuery?: string) => void;
  onClearContext: () => void;
  bellwetherContentItems: CalendarContent[];
}

// AIAnalysisState is now passed via props, ToolbeltInternalState handles its own UI updates before parent is informed
interface ToolbeltInternalState {
    isLoading: boolean;
    resultText: string | null;
    error?: string;
    groundingChunks?: GroundingChunk[];
    // image prop removed
}


const AIAnalysisToolbelt: React.FC<AIAnalysisToolbeltProps> = ({
  context,
  onPerformAnalysis: parentOnPerformAnalysis, 
  onClearContext,
  bellwetherContentItems,
}) => {
  const [selectedBellwetherItemId, setSelectedBellwetherItemId] = useState<string | null>(null);
  const [customSearchQuery, setCustomSearchQuery] = useState('');
  const [liveSearchResults, setLiveSearchResults] = useState<LiveSearchResult[]>([]);
  const [isSearchingWeb, setIsSearchingWeb] = useState(false);
  const [competitorContentSnippet, setCompetitorContentSnippet] = useState('');

  const [internalState, setInternalState] = useState<ToolbeltInternalState>({
      isLoading: false,
      resultText: null,
      error: undefined,
      groundingChunks: [],
      // image: null, // Removed
  });


  useEffect(() => {
    setSelectedBellwetherItemId(null);
    setCustomSearchQuery('');
    setLiveSearchResults([]);
    setCompetitorContentSnippet('');
    setInternalState({ isLoading: false, resultText: null, error: undefined, groundingChunks: [] });
  }, [context]);

  if (!context) {
    return null;
  }

  const selectedBellwetherItem = bellwetherContentItems.find(item => item.id === selectedBellwetherItemId);

  const handleWebSearch = async () => {
    if (!customSearchQuery.trim()) {
      alert("Please enter a search query.");
      return;
    }
    setIsSearchingWeb(true);
    setLiveSearchResults([]);
    setInternalState(prev => ({ ...prev, isLoading: true, error: undefined, resultText: null, groundingChunks: [] }));
    
    const prompt = `User is researching competitors for '${context.contentType}' in the Colorado exterior remodeling market.
    Competitor being analyzed: ${context.competitor.name}
    Their specific search query is: '${customSearchQuery}'.
    Task: Perform a web search based on this query. Identify and list the top 5-7 most relevant web pages. For each page, provide its title and URL.
    Return the output ONLY as a valid JSON array of objects, where each object has a 'title' (string) and 'url' (string) key.
    Example: [{"title": "Example Siding CO", "url": "https://example.com/siding"}]`;
    
    const logDetails: Record<string, any> = {
        toolbeltContext: context,
        searchQuery: customSearchQuery,
        aiActionType: 'webSearch',
        promptLength: prompt.length,
        originalPrompt: prompt
    };

    const result: GeminiTextResult = await generateGeminiText(prompt, true, "Output ONLY valid JSON array as described.", false, true);
    
    setIsSearchingWeb(false);
    setInternalState(prev => ({ ...prev, isLoading: false }));

    if (result.error) {
        alert("Error performing web search: " + result.error);
        setInternalState(prev => ({...prev, error: result.error}));
        logDetails.error = result.error;
        logDetails.status = 'error';
    } else if (result.text) {
      try {
        let jsonStr = result.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }
        const parsedResults = JSON.parse(jsonStr);
        if (Array.isArray(parsedResults) && parsedResults.every(item => typeof item.title === 'string' && typeof item.url === 'string')) {
          setLiveSearchResults(parsedResults.slice(0, 7));
          logDetails.searchResults = parsedResults.slice(0,7);
          logDetails.status = 'success';
          logDetails.groundingChunks = result.groundingChunks;
        } else {
          setLiveSearchResults([]);
          const parseErrorMsg = "AI did not return results in the expected format for web search (array of {title, url}).";
          alert(parseErrorMsg);
          setInternalState(prev => ({...prev, error: parseErrorMsg}));
          logDetails.error = parseErrorMsg;
          logDetails.rawResponse = result.text;
          logDetails.status = 'parse_error';
        }
      } catch (e) {
        setLiveSearchResults([]);
        const parseErrorMsg = "Failed to parse AI search results. Ensure AI is strictly returning JSON. Raw: " + result.text.substring(0,100);
        alert(parseErrorMsg);
        setInternalState(prev => ({...prev, error: parseErrorMsg}));
        logDetails.error = `Parse error: ${(e as Error).message}. Raw: ${result.text}`;
        logDetails.status = 'parse_exception';
        console.error("Error parsing live search results:", e, result.text);
      }
    } else {
         const emptyError = "AI returned an empty response for web search.";
         alert(emptyError);
         setInternalState(prev => ({...prev, error: emptyError}));
         logDetails.error = emptyError;
         logDetails.status = 'empty_response';
    }
    logAppAction({ actionType: 'AI Action Result', pageContext: 'competitor-analysis', itemId: context.competitor.id, details: logDetails });
  };
  
  const handleLiveResultClick = (url: string) => {
    setCompetitorContentSnippet(url);
  };

  const handlePerformAnalysis = async (promptType: 'differentiate' | 'strengths' | 'opportunities') => {
    setInternalState({ isLoading: true, resultText: null, error: undefined, groundingChunks: [] });

    let prompt = `You are a senior content marketing strategist for Bellwether Homes, a premium Colorado exterior remodeler.
    Your task is to analyze competitor content.
    Competitor: ${context.competitor.name}
    Content Type: ${context.contentType}
    ${context.subCategoryName ? `Sub-Category: ${context.subCategoryName}` : ''}
    `;
    
    if (competitorContentSnippet) {
        prompt += `\nCompetitor Content/URL for Analysis: "${competitorContentSnippet}"\n`;
    } else {
        prompt += `\n(No specific competitor content URL/snippet provided by user. Rely on general knowledge and web search if needed for ${context.competitor.name}'s content in this area.)\n`;
    }
    
    let useSearch = true; 
    const logDetails: Record<string, any> = {
        toolbeltContext: context,
        aiActionType: promptType,
        competitorContentSnippet: competitorContentSnippet,
        promptLength: 0, 
        originalPrompt: '' 
    };

    switch (promptType) {
      case 'strengths':
        prompt += `\nTask: Based on the provided competitor content/URL (or public information - perform Google Search), identify key strengths and successful content strategies of ${context.competitor.name} for this content type/category in Colorado. What makes their content effective? Provide a concise analysis.`;
        break;
      case 'opportunities':
        prompt += `\nBellwether Homes aims to be the leading expert.
        Task: Based on the competitor content/URL (or public information about ${context.competitor.name}'s content via Google Search), identify content gaps or opportunities for Bellwether Homes. Where can Bellwether provide superior value, depth, or a unique Colorado-centric angle?`;
        break;
      case 'differentiate':
        const bellwetherItem = bellwetherContentItems.find(item => item.id === selectedBellwetherItemId);
        if (!bellwetherItem) {
          const errorMsg = "Selected Bellwether item not found.";
          setInternalState({ isLoading: false, resultText: null, error: errorMsg, groundingChunks: [] });
          logDetails.error = errorMsg;
          logDetails.status = 'config_error';
          logAppAction({ actionType: 'AI Action Result', pageContext: 'competitor-analysis', itemId: context.competitor.id, details: logDetails });
          return;
        }
        prompt += `\nBellwether Content Piece for Comparison:
        Title: "${bellwetherItem.title}" | Type: ${bellwetherItem.type} | Brief: "${bellwetherItem.brief}"

        Task: Analyze how Bellwether's content can effectively differentiate from ${context.competitor.name}'s offerings (using the competitor content/URL or Google Search for context). Suggest 3-5 specific, actionable ways Bellwether can highlight its unique value, Colorado expertise, or premium quality.`;
        logDetails.bellwetherItemId = bellwetherItem.id;
        logDetails.bellwetherItemTitle = bellwetherItem.title;
        break;
    }

    prompt += "\nFocus on actionable insights. Be specific and tailor advice to the Colorado market.";
    logDetails.promptLength = prompt.length;
    logDetails.originalPrompt = prompt;
    
    const result: GeminiTextResult = await generateGeminiText(prompt, useSearch, "You are a marketing expert specializing in home improvement content.");
    
    if (result.error) {
         setInternalState({
            isLoading: false, resultText: null, error: result.error, groundingChunks: result.groundingChunks
        });
        logDetails.error = result.error;
        logDetails.status = 'error';
    } else {
        setInternalState({
            isLoading: false, resultText: result.text, error: undefined,
            groundingChunks: result.groundingChunks?.filter(chunk => chunk.web && chunk.web.uri && chunk.web.title)
        });
        logDetails.generatedText = result.text;
        logDetails.groundingChunks = result.groundingChunks;
        logDetails.status = 'success';
    }
    logAppAction({ actionType: 'AI Action Result', pageContext: 'competitor-analysis', itemId: context.competitor.id, details: logDetails });
  };


  const actionButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 disabled:opacity-60 flex items-center justify-center gap-1.5 w-full sm:w-auto shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`;
  const inputBaseClasses = "w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-800 text-sm shadow-sm";
  const labelBaseClasses = "block text-sm font-medium text-slate-700 mb-1.5";


  return (
    <div className={`mt-8 p-5 md:p-6 rounded-xl shadow-xl border-t-4 border-[${BRAND_PRIMARY}] bg-slate-50`}>
      <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-200">
        <h3 className="text-lg md:text-xl font-semibold text-slate-800">
          AI Analysis: <span className="text-[#DD5B42]">{context.competitor.name}</span> - {context.contentType} {context.subCategoryName ? `(${context.subCategoryName})` : ''}
        </h3>
        <button
          onClick={onClearContext}
          className="text-slate-400 hover:text-slate-700 text-2xl font-light p-1 -mr-1 rounded-full hover:bg-slate-200 transition-colors"
          aria-label="Close AI analysis toolbelt"
        >
          &times;
        </button>
      </div>
      
      <div className="mb-4 p-4 bg-white rounded-lg shadow-md border border-slate-200">
        <label htmlFor="customSearchQuery" className={labelBaseClasses}>
          1. Custom Web Search for "{context.competitor.name}" Content:
        </label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            id="customSearchQuery"
            value={customSearchQuery}
            onChange={(e) => setCustomSearchQuery(e.target.value)}
            placeholder="e.g., siding installation process, window reviews"
            className={`${inputBaseClasses} flex-grow`}
          />
          <button onClick={handleWebSearch} disabled={isSearchingWeb || !customSearchQuery.trim()} className={`${actionButtonClasses} flex-shrink-0 mt-2 sm:mt-0`}>
            {(isSearchingWeb || internalState.isLoading && customSearchQuery) ? <Loader /> : "🔍 Search Web"}
          </button>
        </div>
        {liveSearchResults.length > 0 && (
          <div className="mt-3">
            <h5 className="text-xs font-semibold text-slate-600 mb-1">Live Search Findings (click to use URL):</h5>
            <ul className="list-disc list-inside space-y-1 max-h-32 overflow-y-auto bg-slate-50 p-2 rounded-md border border-slate-200 custom-scrollbar">
              {liveSearchResults.map((result, index) => (
                <li key={index} className="text-xs">
                  <button onClick={() => handleLiveResultClick(result.url)} className="text-sky-600 hover:text-sky-800 hover:underline text-left">
                    {result.title} <ExternalLinkIcon className="inline w-2.5 h-2.5" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="mb-4 p-4 bg-white rounded-lg shadow-md border border-slate-200">
        <label htmlFor="competitorContentSnippet" className={labelBaseClasses}>
          2. Competitor Content (URL or Snippet):
        </label>
        <textarea
            id="competitorContentSnippet"
            value={competitorContentSnippet}
            onChange={(e) => setCompetitorContentSnippet(e.target.value)}
            rows={3}
            placeholder="Paste competitor URL (from search above) or text snippet here..."
            className={inputBaseClasses}
        />
        <p className="text-xs text-slate-500 mt-1">For AI analysis, provide URL or paste specific text.</p>
      </div>


      <div className="mb-5 p-4 bg-white rounded-lg shadow-md border border-slate-200">
        <label htmlFor="bellwetherItemSelect" className={labelBaseClasses}>
          3. Bellwether Content for Differentiation (Optional):
        </label>
        <select
          id="bellwetherItemSelect"
          value={selectedBellwetherItemId || ''}
          onChange={(e) => setSelectedBellwetherItemId(e.target.value || null)}
          className={inputBaseClasses}
        >
          <option value="">None (General Analysis)</option>
          {bellwetherContentItems.map(item => (
            <option key={item.id} value={item.id}>{item.title} ({item.type})</option>
          ))}
        </select>
        {selectedBellwetherItem && (
             <p className="text-xs text-slate-500 mt-1.5 bg-slate-50 p-2 rounded-md border border-slate-200">
                Selected Brief: "{selectedBellwetherItem.brief.substring(0,120)}..."
            </p>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
        <button
          onClick={() => handlePerformAnalysis('strengths')}
          className={actionButtonClasses}
          disabled={internalState.isLoading}
        >
          <SparklesIcon className="w-4 h-4"/> Strengths
        </button>
        <button
          onClick={() => handlePerformAnalysis('opportunities')}
          className={actionButtonClasses}
          disabled={internalState.isLoading}
        >
          <SparklesIcon className="w-4 h-4"/> Opportunities
        </button>
        <button
          onClick={() => handlePerformAnalysis('differentiate')}
          className={actionButtonClasses}
          disabled={internalState.isLoading || !selectedBellwetherItemId}
          title={!selectedBellwetherItemId ? "Select a Bellwether item above" : "Analyze differentiation"}
        >
          <SparklesIcon className="w-4 h-4"/> Differentiate
        </button>
      </div>
      
      <AIContentDisplay
        isLoading={internalState.isLoading && !isSearchingWeb}
        aiGeneratedContent={internalState.resultText}
        // aiGeneratedImage={null} // Prop removed
        error={internalState.error}
        groundingChunks={internalState.groundingChunks}
        title="AI Analysis Results"
        onCopyText={(textToCopy) => {
            logAppAction({
                actionType: 'AI Content Copied',
                pageContext: 'competitor-analysis',
                itemId: context.competitor.id,
                details: { 
                  toolbeltContext: context, 
                  copiedText: textToCopy
                }
            });
            navigator.clipboard.writeText(textToCopy);
        }}
      />
    </div>
  );
};

export default AIAnalysisToolbelt;