
import React, { useState, useEffect, useCallback } from 'react';
import { CalendarContent, JourneyItem, Intent, IntentPlannerPageProps as BaseIntentPlannerPageProps } from '../../types';
import { AUDIENCE_SEGMENTS, INTENT_STAGES, BRAND_PRIMARY, BRAND_SECONDARY, BRAND_TEXT_PRIMARY } from '../../constants';
import JourneyCard from './JourneyCard';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';

declare const jsPDF: any; 

interface IntentPlannerPageProps extends BaseIntentPlannerPageProps {
  initialCalendarData: CalendarContent[]; 
  onCalendarDataUpdate: (updatedData: CalendarContent[]) => void; 
  onOpenModal: (item: CalendarContent, actionType?: string) => void; 
}

const IntentPlannerPage: React.FC<IntentPlannerPageProps> = ({ 
  initialCalendarData, 
  onCalendarDataUpdate, 
  initialSelectedAudience,
  onOpenModal 
}) => {
  const [selectedAudience, setSelectedAudience] = useState<string>(initialSelectedAudience || AUDIENCE_SEGMENTS[0] || '');
  const [journeyItems, setJourneyItems] = useState<JourneyItem[]>([]);
  const [draggedItemId, setDraggedItemId] = useState<string | null>(null);
  const [copyStatus, setCopyStatus] = useState<string>('');
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);

  useEffect(() => {
    if (initialSelectedAudience && AUDIENCE_SEGMENTS.includes(initialSelectedAudience)) {
      setSelectedAudience(initialSelectedAudience);
    } else if (!initialSelectedAudience && AUDIENCE_SEGMENTS.length > 0) {
      setSelectedAudience(AUDIENCE_SEGMENTS[0]);
    }
  }, [initialSelectedAudience]);

  useEffect(() => {
    const itemsForAudience = initialCalendarData
      .filter(item => item.audience === selectedAudience)
      .map(item => ({ ...item })); 
    setJourneyItems(itemsForAudience);
  }, [selectedAudience, initialCalendarData]);

  const handleAudienceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedAudience(e.target.value);
  };

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, itemId: string) => {
    setDraggedItemId(itemId);
    e.dataTransfer.setData('text/plain', itemId);
    setTimeout(() => {
        const draggedElement = document.getElementById(itemId);
        if (draggedElement) {
            draggedElement.classList.add('opacity-50', 'shadow-2xl', 'scale-105');
        }
    }, 0);
  };
  
  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    if (draggedItemId) {
        const draggedElement = document.getElementById(draggedItemId);
        if (draggedElement) {
            draggedElement.classList.remove('opacity-50', 'shadow-2xl', 'scale-105');
        }
    }
    setDraggedItemId(null);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.add('bg-orange-100', 'border-[#DD5B42]');
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.currentTarget.classList.remove('bg-orange-100', 'border-[#DD5B42]');
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, targetIntent: Intent) => {
    e.preventDefault();
    e.currentTarget.classList.remove('bg-orange-100', 'border-[#DD5B42]');
    const itemId = e.dataTransfer.getData('text/plain');

    if (itemId) {
      setJourneyItems(prevItems =>
        prevItems.map(item =>
          item.id === itemId ? { ...item, intent: targetIntent } : item
        )
      );
      const updatedGlobalData = initialCalendarData.map(item =>
        item.id === itemId ? { ...item, intent: targetIntent } : item
      );
      onCalendarDataUpdate(updatedGlobalData);
    }
    setDraggedItemId(null);
  };
  
  const handleContentChange = useCallback((itemId: string, field: 'title' | 'competitorRelevance', value: string) => {
    setJourneyItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId ? { ...item, [field]: value } : item
      )
    );
    const updatedGlobalData = initialCalendarData.map(item =>
      item.id === itemId ? { ...item, [field]: value } : item
    );
    onCalendarDataUpdate(updatedGlobalData);
  }, [initialCalendarData, onCalendarDataUpdate]);

  const exportButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`;

  const handleCopyPlan = () => {
    let textToCopy = `Content Journey Plan for Audience: ${selectedAudience}\n`;
    INTENT_STAGES.forEach(intent => {
      const intentName = intent.split('/')[0];
      textToCopy += `\n## ${intentName.toUpperCase()} STAGE ##\n\n`;
      journeyItems
        .filter(item => item.intent === intent)
        .forEach(card => {
          textToCopy += `* Topic: ${card.title}\n`;
          textToCopy += `    Type: ${card.type}\n`;
          textToCopy += `    Month: ${card.month}\n`;
          textToCopy += `    Theme: ${card.theme}\n`;
          textToCopy += `    Keywords: ${card.keywords}\n`;
          textToCopy += `    Brief: ${card.brief}\n`;
          textToCopy += `    Competitor Note: ${card.competitorRelevance}\n\n`;
        });
    });

    navigator.clipboard.writeText(textToCopy.trim())
      .then(() => {
        setCopyStatus('Plan Copied!');
        setTimeout(() => setCopyStatus(''), 2000);
      })
      .catch(err => console.error('Failed to copy plan: ', err));
  };

  const handleDownloadPdf = () => {
    const doc = new jsPDF({unit: "pt", format: "a4"});
    let yPos = 40;
    const pageMargin = 40;
    const contentWidth = doc.internal.pageSize.getWidth() - 2 * pageMargin;
    
    doc.setFont('Work Sans', 'bold'); // Changed from Inter
    doc.setFontSize(18);
    doc.setTextColor(BRAND_SECONDARY); 
    doc.text("Content Journey Plan", doc.internal.pageSize.getWidth() / 2, yPos, { align: 'center' });
    yPos += 20;
    doc.setFontSize(12);
    doc.setTextColor(BRAND_TEXT_PRIMARY); 
    doc.text(`Audience: ${selectedAudience}`, doc.internal.pageSize.getWidth() / 2, yPos, { align: 'center' });
    yPos += 25;

    INTENT_STAGES.forEach(intent => {
      if (yPos > doc.internal.pageSize.getHeight() - 80) { doc.addPage(); yPos = 40; } 
      const intentName = intent.split('/')[0];
      doc.setFont('Work Sans', 'bold'); // Changed from Inter
      doc.setFontSize(14);
      doc.setTextColor(BRAND_PRIMARY); 
      doc.text(intentName.toUpperCase() + " STAGE", pageMargin, yPos);
      yPos += 20;

      const itemsInIntent = journeyItems.filter(item => item.intent === intent);
      itemsInIntent.forEach(card => {
        if (yPos > doc.internal.pageSize.getHeight() - 100) { 
            doc.addPage();
            yPos = 40;
            doc.setFont('Work Sans', 'bold'); // Changed from Inter
            doc.setFontSize(14);
            doc.setTextColor(BRAND_PRIMARY); 
            doc.text(intentName.toUpperCase() + " STAGE (Continued)", pageMargin, yPos);
            yPos += 20;
        }
        doc.setFont('Work Sans', 'bold'); // Changed from Inter
        doc.setFontSize(10);
        doc.setTextColor(BRAND_TEXT_PRIMARY);
        let splitTitle = doc.splitTextToSize(`Topic: ${card.title} (${card.type})`, contentWidth - 10);
        doc.text(splitTitle, pageMargin + 10, yPos);
        yPos += (splitTitle.length * 12) + 4;
        
        doc.setFont('Work Sans', 'normal'); // Changed from Inter
        doc.setFontSize(9);
        let splitBrief = doc.splitTextToSize(`Brief: ${card.brief}`, contentWidth - 20);
        doc.text(splitBrief, pageMargin + 20, yPos);
        yPos += (splitBrief.length * 11) + 4;

        let splitCompetitor = doc.splitTextToSize(`Competitor Note: ${card.competitorRelevance}`, contentWidth - 20);
        doc.text(splitCompetitor, pageMargin + 20, yPos);
        yPos += (splitCompetitor.length * 11) + 12;
      });
      yPos += 10; 
    });
    
    doc.save(`Journey_Plan_${selectedAudience.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`);
  };

  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Intent Journey Planner</h2>
          <p className="text-sm text-slate-500 mt-1">Map content to user intent stages for specific audiences.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0" />
      </div>
      
      <div className="mb-6 p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
        <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-grow w-full md:w-auto">
              <label htmlFor="audienceFilter" className="font-medium text-slate-700 block mb-1.5 text-xs">Select Target Audience:</label>
              <select 
                id="audienceFilter" 
                value={selectedAudience} 
                onChange={handleAudienceChange}
                className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-800 text-sm shadow-sm"
                aria-label="Select target audience segment"
              >
                {AUDIENCE_SEGMENTS.map(audience => (
                  <option key={audience} value={audience}>{audience}</option>
                ))}
                {AUDIENCE_SEGMENTS.length === 0 && <option value="">No audiences available</option>}
              </select>
            </div>
            <div className="flex gap-2 mt-2 md:mt-0 md:ml-auto self-start md:self-end">
              {copyStatus && <div className="text-sm font-semibold text-green-600 transition-opacity duration-300 self-center mr-2">{copyStatus}</div>}
              <button onClick={handleCopyPlan} className={exportButtonClasses}>Copy Plan</button>
              <button onClick={handleDownloadPdf} className={exportButtonClasses}>Download PDF</button>
            </div>
        </div>
      </div>


      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 md:gap-6" onDragEnd={handleDragEnd}>
        {INTENT_STAGES.map(intent => {
          const intentName = intent.split('/')[0];
          const intentColorClasses = intent === "Awareness/Informational" ? "bg-blue-500 border-blue-500" :
                                  intent === "Consideration/Comparison" ? `bg-[${BRAND_PRIMARY}] border-[${BRAND_PRIMARY}]` :
                                  "bg-green-500 border-green-500";
          return (
            <div
              key={intent}
              data-intent={intent}
              onDrop={(e) => handleDrop(e, intent)}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`journey-column bg-slate-100 p-4 sm:p-5 rounded-xl shadow-lg border-t-4 ${draggedItemId ? 'border-dashed border-[#DD5B42]' : ''} ${intentColorClasses} transition-all duration-200 min-h-[400px] flex flex-col`}
              aria-label={`${intentName} stage column`}
            >
              <h3 className={`text-lg font-bold mb-4 text-center pb-2 text-white p-2 rounded-md shadow-sm`}>{intentName}</h3>
              <div className="space-y-3 md:space-y-4 flex-grow overflow-y-auto pr-1 custom-scrollbar">
                {journeyItems
                  .filter(item => item.intent === intent)
                  .map(item => (
                    <JourneyCard 
                        key={item.id} 
                        item={item} 
                        onDragStart={handleDragStart}
                        onContentChange={handleContentChange}
                        onOpenModal={onOpenModal}
                    />
                  ))}
                 {journeyItems.filter(item => item.intent === intent).length === 0 && (
                    <p className="text-xs text-slate-400 italic text-center pt-10">Drag content cards here.</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <HelpPanel
        title="Using the Intent Journey Planner"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Map Your Customer's Content Experience</h4>
        <p>This tool helps you align content pieces with specific stages of the buyer's journey for different audience segments.</p>
        <ul>
          <li><strong>Select Audience:</strong> Use the dropdown to choose a target audience. The board will populate with content planned for them.</li>
          <li><strong>Intent Stages:</strong> Columns represent Awareness, Consideration, and Decision stages.</li>
          <li><strong>Drag & Drop:</strong> Move content cards between columns to re-assign their intent stage. This updates the master content plan.</li>
          <li><strong>Edit Content:</strong> Click directly on a card's title or competitor relevance text to edit it. Changes are saved automatically.</li>
          <li><strong>Refine with AI:</strong> Click "✨ Refine Brief with AI" on a card to open the AI assistant (in the modal), pre-set to refine that item's brief specifically for its current audience and intent stage.</li>
          <li><strong>Export:</strong> Use "Copy Plan" to get a text version or "Download PDF" for a formatted document of the current audience's journey map.</li>
        </ul>
      </HelpPanel>
    </div>
  );
};

export default IntentPlannerPage;