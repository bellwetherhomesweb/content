
import React from 'react';
import { JourneyItem, CalendarContent } from '../../types';
import { BRAND_PRIMARY } from '../../constants';
import { SparklesIcon } from '../shared/Icons';

interface JourneyCardProps {
  item: JourneyItem;
  onDragStart: (e: React.DragEvent<HTMLDivElement>, itemId: string) => void;
  onContentChange: (itemId: string, field: 'title' | 'competitorRelevance', value: string) => void;
  onOpenModal: (item: CalendarContent, actionType?: string) => void;
}

const JourneyCard: React.FC<JourneyCardProps> = ({ item, onDragStart, onContentChange, onOpenModal }) => {
  const handleBlur = (field: 'title' | 'competitorRelevance', e: React.FocusEvent<HTMLHeadingElement | HTMLSpanElement>) => {
    onContentChange(item.id, field, e.currentTarget.innerText);
  };

  const typeClasses = item.type === 'YouTube Video' 
    ? "text-red-700 bg-red-100" 
    : "text-blue-700 bg-blue-100";

  return (
    <div
      id={item.id}
      draggable
      onDragStart={(e) => onDragStart(e, item.id)}
      className="journey-card bg-white p-3.5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 ease-in-out cursor-grab active:cursor-grabbing border border-slate-200 hover:border-slate-300 flex flex-col"
    >
      <div className="flex-grow mb-2">
        <h5
          className="journey-title font-semibold text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#DD5B42] focus:bg-slate-50 p-1 -m-1 rounded transition-colors cursor-text"
          contentEditable
          suppressContentEditableWarning
          onBlur={(e) => handleBlur('title', e)}
          dangerouslySetInnerHTML={{ __html: item.title }}
        ></h5>
        <p className={`text-xs font-medium mt-1.5 inline-block px-2 py-0.5 rounded-full ${typeClasses}`}>{item.type}</p>
        <div className="mt-2.5 pl-2 border-l-2 border-orange-200">
          <p className="text-xs text-slate-600">
            <strong className="font-medium text-slate-700">Competitor Note:</strong>{' '}
            <span
              className="journey-competitor focus:outline-none focus:ring-1 focus:ring-[#DD5B42] focus:bg-slate-50 p-1 -m-0.5 rounded transition-colors cursor-text"
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleBlur('competitorRelevance', e)}
              dangerouslySetInnerHTML={{ __html: item.competitorRelevance }}
            ></span>
          </p>
        </div>
      </div>
      <button 
        onClick={() => onOpenModal(item, 'refineBriefForAudience')} 
        className={`bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-3 py-1.5 rounded-md text-xs font-semibold transition-colors duration-200 mt-auto text-center block w-full shadow-sm hover:shadow-md flex items-center justify-center gap-1`}
        title="Refine this brief with AI for the current audience and intent stage"
      >
        <SparklesIcon className="w-3.5 h-3.5" /> Refine with AI
      </button>
    </div>
  );
};

export default JourneyCard;