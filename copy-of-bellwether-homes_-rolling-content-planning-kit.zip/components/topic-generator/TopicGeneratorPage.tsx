
import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { CalendarContent, Strategy, TopicGenerationParams, GeneratedTopicIdea, ContentStatus, Intent, ContentType, GeminiTextResult } from '../../types';
import { generateGeminiText } from '../../services/geminiService';
import Loader from '../shared/Loader';
import { BRAND_PRIMARY, BRAND_SECONDARY, STANDARD_MONTH_ORDER, THEMES as CONSTANT_THEMES, AUDIENCE_SEGMENTS as CONSTANT_AUDIENCES, INTENT_STAGES, CONTENT_TYPES_OPTIONS } from '../../constants';
import { SparklesIcon, PlusIcon, CopyIcon } from '../shared/Icons';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';
import AIContentDisplay from '../shared/AIContentDisplay';
import { logAppAction } from '../../services/loggingService';


interface TopicGeneratorPageProps {
  onAddContentItems: (newItems: CalendarContent[]) => void;
  existingCalendarData: CalendarContent[];
  strategyData: Strategy[];
}

const TopicGeneratorPage: React.FC<TopicGeneratorPageProps> = ({ onAddContentItems, existingCalendarData, strategyData }) => {
  const [params, setParams] = useState<TopicGenerationParams>({
    targetTimeframe: 'Next 3 months',
    keyThemes: '',
    numBlogPosts: 3,
    numVideos: 2,
    considerExisting: true,
  });
  const [generatedIdeas, setGeneratedIdeas] = useState<GeneratedTopicIdea[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);
  const [rawAIResponseForDisplay, setRawAIResponseForDisplay] = useState<string | null>(null);
  const [copyStatus, setCopyStatus] = useState('');


  const handleParamChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      setParams(prev => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else if (type === 'number') {
      setParams(prev => ({ ...prev, [name]: parseInt(value, 10) || 0 }));
    } else {
      setParams(prev => ({ ...prev, [name]: value }));
    }
  };
  
  const parseAIResponse = (responseText: string | null): GeneratedTopicIdea[] => {
    if (!responseText) {
      setAiError("AI response was empty.");
      return [];
    }
    try {
        let jsonStr = responseText.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }
        
        const parsedData = JSON.parse(jsonStr);
        if (Array.isArray(parsedData)) {
            return parsedData.map(idea => ({
                tempId: uuidv4(),
                title: idea.title || 'Untitled AI Idea',
                brief: idea.brief || 'AI generated brief to be detailed.',
                type: idea.type && CONTENT_TYPES_OPTIONS.includes(idea.type) ? idea.type as ContentType : CONTENT_TYPES_OPTIONS[0] as ContentType,
                intent: idea.intent && INTENT_STAGES.includes(idea.intent as Intent) ? idea.intent as Intent : INTENT_STAGES[0],
                audience: idea.audience || (CONSTANT_AUDIENCES.length > 0 ? CONSTANT_AUDIENCES[0] : 'General Homeowners'),
                keywords: idea.keywords || '',
                theme: idea.theme || (CONSTANT_THEMES.length > 0 ? CONSTANT_THEMES[0] : 'General'),
                month: idea.month && STANDARD_MONTH_ORDER.includes(idea.month) ? idea.month : STANDARD_MONTH_ORDER[new Date().getMonth()], 
                status: 'Ideation' as ContentStatus,
                competitorRelevance: 'To be defined based on new angle from AI.',
                isSelected: true,
            })).filter(idea => idea.title && idea.brief && idea.type); 
        }
        setAiError("AI response was not in the expected array format.");
        return [];
    } catch (e) {
        console.error("Failed to parse AI response:", e, "\nRaw response:\n", responseText);
        setAiError(`Failed to parse AI's response. It might not be valid JSON. Ensure the AI is prompted to return only JSON. Raw Output (first 500 chars):\n${responseText.substring(0,500)}...`);
        return [];
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setAiError(null);
    setGeneratedIdeas([]);
    setRawAIResponseForDisplay(null);
    setCopyStatus('');

    let existingContentSummary = '';
    if (params.considerExisting && existingCalendarData.length > 0) {
      existingContentSummary = "Existing Content Titles/Themes (for context, avoid direct duplication unless intentional follow-up):\n";
      existingCalendarData.slice(0, 30).forEach(item => {
        existingContentSummary += `- "${item.title}" (Theme: ${item.theme}, Type: ${item.type}, Month: ${item.month})\n`;
      });
    }
    
    const strategySummary = strategyData.map(s => `- ${s.title}: ${s.content.substring(0,100)}...`).join('\n');
    const currentMonthName = STANDARD_MONTH_ORDER[new Date().getMonth()];

    const prompt = `
      You are an expert content strategist for Bellwether Homes, a premium Colorado exterior remodeler known for quality, expertise in CO climate, and advanced solutions.
      Your task is to generate ${params.numBlogPosts} blog post ideas and ${params.numVideos} YouTube video ideas.

      Target Timeframe: ${params.targetTimeframe}. The current month is ${currentMonthName}.
      Key Themes/Pillars to Focus On: ${params.keyThemes || 'General exterior remodeling excellence, Colorado climate solutions, premium products like James Hardie & Pella.'}
      Current Strategic Pillars (for high-level alignment):
      ${strategySummary}

      ${existingContentSummary}

      For each idea, provide:
      - title: A compelling, SEO-friendly title.
      - brief: A 2-3 sentence brief explaining the core message, angle, and value to a Colorado homeowner. Emphasize Bellwether's unique expertise.
      - type: "YouTube Video" or "Blog Post".
      - intent: Suggested user intent stage ("Awareness/Informational", "Consideration/Comparison", or "Decision/Transactional").
      - audience: A specific target audience segment (e.g., "Homeowners researching siding materials in Denver", "Mountain homeowners concerned about window durability", "Clients ready for a premium exterior remodel").
      - keywords: 3-5 relevant primary keywords.
      - theme: A relevant content theme (e.g., "Mastering Siding Solutions", "Advanced Window Technology").
      - month: Suggested month name (e.g., "January", "February", etc.) appropriate for the target timeframe. For "Next X months", suggest plausible upcoming months. For specific quarters (e.g., "Q4"), suggest months within that quarter.

      Output ONLY a single JSON array of these content idea objects. Ensure the JSON is well-formed.
      Example item structure: {"title": "...", "brief": "...", "type": "Blog Post", "intent": "Awareness/Informational", ..., "month": "July"}
    `;
    
    const logDetailsBase: Record<string, any> = {
        generationParams: params,
        promptLength: prompt.length,
        aiActionType: 'generateTopics'
    };

    const result: GeminiTextResult = await generateGeminiText(prompt, false, "Output should be a JSON array of content idea objects.", false, true);
    
    if (result.error) {
      setAiError(result.error);
      logAppAction({ actionType: 'AI Action Result', pageContext: 'topic-generator', details: { ...logDetailsBase, status: 'error', error: result.error }});
    } else if (result.text) {
      setRawAIResponseForDisplay(result.text); 
      const ideas = parseAIResponse(result.text);
      if (ideas.length > 0) {
        setGeneratedIdeas(ideas);
        logAppAction({ actionType: 'AI Action Result', pageContext: 'topic-generator', details: { ...logDetailsBase, status: 'success', rawResponse: result.text, parsedIdeasCount: ideas.length }});
      } else if (!aiError) { 
        const noIdeasMsg = "AI generated a response, but no valid topic ideas could be parsed.";
        setAiError(noIdeasMsg);
        logAppAction({ actionType: 'AI Action Result', pageContext: 'topic-generator', details: { ...logDetailsBase, status: 'parse_error', error: noIdeasMsg, rawResponse: result.text }});
      } else { 
         logAppAction({ actionType: 'AI Action Result', pageContext: 'topic-generator', details: { ...logDetailsBase, status: 'parse_error', error: aiError, rawResponse: result.text }});
      }
    } else {
      const emptyMsg = "AI returned an empty response.";
      setAiError(emptyMsg);
      logAppAction({ actionType: 'AI Action Result', pageContext: 'topic-generator', details: { ...logDetailsBase, status: 'empty_response', error: emptyMsg }});
    }
    setIsLoading(false);
  };

  const toggleIdeaSelection = (tempId: string) => {
    setGeneratedIdeas(prev => 
      prev.map(idea => idea.tempId === tempId ? { ...idea, isSelected: !idea.isSelected } : idea)
    );
  };

  const handleAddSelectedToCalendar = () => {
    const itemsToAdd: CalendarContent[] = [];
    const successfullyAddedTitles: string[] = [];

    generatedIdeas.forEach(idea => {
      if (idea.isSelected) {
        const { tempId, isSelected, id: ideaId, ...restOfIdeaFields } = idea; 
        const newItem: CalendarContent = {
          ...restOfIdeaFields, 
          id: uuidv4(), 
        };
        itemsToAdd.push(newItem);
        successfullyAddedTitles.push(newItem.title);
        
        logAppAction({
          actionType: 'New Idea from AI Topic Generator',
          pageContext: 'topic-generator',
          itemId: newItem.id,
          details: { 
            title: newItem.title, 
            brief: newItem.brief, 
            type: newItem.type, 
            intent: newItem.intent,
            audience: newItem.audience,
            month: newItem.month,
            theme: newItem.theme,
            keywords: newItem.keywords,
            generationParamsUsed: params 
          }
        });
      }
    });
    
    if (itemsToAdd.length > 0) {
      onAddContentItems(itemsToAdd);
      logAppAction({
          actionType: 'Add Generated Topics Batch to Calendar', 
          pageContext: 'topic-generator',
          details: {
              count: itemsToAdd.length,
              addedItemTitles: successfullyAddedTitles,
              generationParams: params 
          }
      });
      setGeneratedIdeas(generatedIdeas.filter(idea => !idea.isSelected)); 
      alert(`${itemsToAdd.length} topic(s) added to calendar in 'Ideation' status! Each has been logged.`);
    } else {
      alert("No topics selected to add.");
    }
  };

  const handleCopyGeneratedIdeas = () => {
    if (rawAIResponseForDisplay) {
        navigator.clipboard.writeText(rawAIResponseForDisplay)
            .then(() => {
                setCopyStatus('Raw JSON Copied!');
                setTimeout(() => setCopyStatus(''), 2000);
            })
            .catch(err => {
                console.error('Failed to copy raw JSON: ', err);
                setCopyStatus('Failed to copy');
            });
        logAppAction({ actionType: 'Export Data', pageContext: 'topic-generator', details: { exportType: 'Copy Generated Ideas JSON', content: rawAIResponseForDisplay } });
    } else if (generatedIdeas.length > 0) {
        // Fallback if rawAIResponseForDisplay is somehow null but ideas exist (shouldn't happen with current logic)
        const ideasToCopy = JSON.stringify(generatedIdeas, null, 2);
        navigator.clipboard.writeText(ideasToCopy)
            .then(() => {
                setCopyStatus('Parsed Ideas Copied (JSON)!');
                setTimeout(() => setCopyStatus(''), 2000);
            })
            .catch(err => {
                console.error('Failed to copy parsed ideas: ', err);
                setCopyStatus('Failed to copy');
            });
        logAppAction({ actionType: 'Export Data', pageContext: 'topic-generator', details: { exportType: 'Copy Generated Ideas JSON (Parsed)', content: ideasToCopy } });
    } else {
        alert("No ideas generated yet to copy.");
    }
  };
  
  const formGroupClasses = "mb-4";
  const labelClasses = "block text-sm font-medium text-slate-700 mb-1.5";
  const inputBaseClasses = "w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-800 text-sm shadow-sm";
  const primaryButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-6 py-2.5 rounded-lg text-base font-semibold transition-colors duration-200 disabled:opacity-70 flex items-center justify-center gap-2 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[${BRAND_PRIMARY}]`;

  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">AI Topic Generator</h2>
          <p className="text-sm text-slate-500 mt-1">Brainstorm new content topics with AI assistance.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0"/>
      </div>
      
      <form onSubmit={handleSubmit} className="p-5 md:p-6 bg-slate-50 rounded-lg shadow-inner border border-slate-200 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
          <div className={formGroupClasses}>
            <label htmlFor="targetTimeframe" className={labelClasses}>Target Timeframe:</label>
            <input type="text" name="targetTimeframe" id="targetTimeframe" value={params.targetTimeframe} onChange={handleParamChange} className={inputBaseClasses} placeholder="e.g., Next 3 months, Q1 2025"/>
          </div>
          <div className={formGroupClasses}>
            <label htmlFor="keyThemes" className={labelClasses}>Key Themes/Pillars (optional):</label>
            <textarea name="keyThemes" id="keyThemes" value={params.keyThemes} onChange={handleParamChange} className={`${inputBaseClasses} min-h-[50px]`} rows={2} placeholder="e.g., James Hardie expertise, Colorado climate solutions"></textarea>
          </div>
          <div className={formGroupClasses}>
            <label htmlFor="numBlogPosts" className={labelClasses}>Number of Blog Posts:</label>
            <input type="number" name="numBlogPosts" id="numBlogPosts" value={params.numBlogPosts} onChange={handleParamChange} className={inputBaseClasses} min="0" />
          </div>
          <div className={formGroupClasses}>
            <label htmlFor="numVideos" className={labelClasses}>Number of YouTube Videos:</label>
            <input type="number" name="numVideos" id="numVideos" value={params.numVideos} onChange={handleParamChange} className={inputBaseClasses} min="0" />
          </div>
          <div className={`${formGroupClasses} md:col-span-2 flex items-center mt-2`}>
            <input type="checkbox" name="considerExisting" id="considerExisting" checked={params.considerExisting} onChange={handleParamChange} className="h-4 w-4 text-[#DD5B42] border-slate-300 rounded focus:ring-[#DD5B42] mr-2 shadow-sm" />
            <label htmlFor="considerExisting" className="text-sm text-slate-700">Consider Existing Content (to avoid duplication)</label>
          </div>
        </div>
        <div className="mt-6 text-center">
          <button type="submit" className={primaryButtonClasses} disabled={isLoading}>
            {isLoading ? <Loader /> : <SparklesIcon className="w-5 h-5" />}
            Generate Topic Ideas
          </button>
        </div>
      </form>

      {isLoading && (
        <div className="flex justify-center my-6"><Loader /></div>
      )}
      
      {aiError && !isLoading && (
        <div className="my-6 p-4 bg-red-50 text-red-700 border border-red-200 rounded-lg shadow-sm">
          <p><strong>Error Generating Topics:</strong> {aiError}</p>
          {rawAIResponseForDisplay && (
            <details className="mt-2 text-xs">
              <summary className="cursor-pointer hover:underline">Show Raw AI Response Snippet</summary>
              <pre className="mt-1 p-2 bg-red-100 border border-red-200 rounded text-red-600 whitespace-pre-wrap break-all">
                {rawAIResponseForDisplay.substring(0, 1000)}...
              </pre>
            </details>
          )}
        </div>
      )}

      {generatedIdeas.length > 0 && !isLoading && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-3 pb-3 border-b border-slate-200 gap-3">
            <h3 className="text-lg font-semibold text-slate-800">Generated Ideas ({generatedIdeas.filter(idea => idea.isSelected).length} selected)</h3>
            <div className="flex gap-2 flex-wrap">
                <button 
                  onClick={handleCopyGeneratedIdeas}
                  className={`bg-slate-600 hover:bg-slate-700 text-white px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors duration-200 flex items-center gap-1.5 shadow-sm hover:shadow-md focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-slate-500`}
                  disabled={!rawAIResponseForDisplay && generatedIdeas.length === 0}
                >
                  <CopyIcon className="w-3.5 h-3.5"/> Copy Generated JSON
                </button>
                <button 
                  onClick={handleAddSelectedToCalendar}
                  className={`bg-[${BRAND_SECONDARY}] hover:bg-opacity-90 text-white px-5 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 flex items-center gap-2 shadow-md hover:shadow-lg focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-[${BRAND_SECONDARY}]`}
                  disabled={generatedIdeas.filter(idea => idea.isSelected).length === 0}
                >
                  <PlusIcon className="w-4 h-4" /> Add Selected to Calendar
                </button>
            </div>
             {copyStatus && <span className="text-xs font-semibold text-green-600 w-full sm:w-auto text-center sm:text-left">{copyStatus}</span>}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {generatedIdeas.map(idea => (
              <div key={idea.tempId} className={`p-4 rounded-lg shadow-md border transition-all duration-200 ${idea.isSelected ? `bg-orange-50 border-orange-300 ring-2 ring-orange-400` : 'bg-white border-slate-200 hover:border-slate-300'}`}>
                <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-md text-slate-800">{idea.title}</h4>
                    <input 
                        type="checkbox" 
                        checked={!!idea.isSelected} 
                        onChange={() => toggleIdeaSelection(idea.tempId)}
                        className="h-5 w-5 text-[#DD5B42] border-slate-400 rounded focus:ring-[#DD5B42] cursor-pointer shadow-sm"
                        aria-label={`Select topic: ${idea.title}`}
                    />
                </div>
                <p className={`text-xs font-medium mb-1 inline-block px-2 py-0.5 rounded-full ${idea.type === 'YouTube Video' ? 'text-red-700 bg-red-100' : 'text-blue-700 bg-blue-100'}`}>{idea.type}</p>
                <p className="text-xs text-slate-600 mb-1"><strong className="text-slate-700">Brief:</strong> {idea.brief}</p>
                <p className="text-xs text-slate-600 mb-1"><strong className="text-slate-700">Intent:</strong> {idea.intent}</p>
                <p className="text-xs text-slate-600 mb-1"><strong className="text-slate-700">Audience:</strong> {idea.audience}</p>
                <p className="text-xs text-slate-600 mb-1"><strong className="text-slate-700">Keywords:</strong> {idea.keywords}</p>
                <p className="text-xs text-slate-600 mb-1"><strong className="text-slate-700">Theme:</strong> {idea.theme}</p>
                 <p className="text-xs text-slate-600"><strong className="text-slate-700">Month:</strong> {idea.month}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      <HelpPanel
        title="Using the AI Topic Generator"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Brainstorm Fresh Content Ideas with AI</h4>
        <p>This tool leverages the Gemini API to suggest new blog posts and video topics tailored to Bellwether Homes' strategic goals.</p>
        <ul>
          <li><strong>Input Parameters:</strong>
            <ul>
              <li><strong>Target Timeframe:</strong> Specify the period you're planning for (e.g., "Next Quarter," "August 2024").</li>
              <li><strong>Key Themes/Pillars:</strong> Optionally provide specific themes or strategic pillars to guide the AI. If left blank, it uses general Bellwether knowledge.</li>
              <li><strong>Number of Posts/Videos:</strong> Set how many ideas of each type you want.</li>
              <li><strong>Consider Existing Content:</strong> If checked, the AI will be given a summary of your current calendar to help avoid direct duplication.</li>
            </ul>
          </li>
          <li><strong>Generate Ideas:</strong> Click "Generate Topic Ideas." The AI will process your request (this may take a moment).</li>
          <li><strong>Review & Select:</strong> Generated ideas appear below. Each includes a title, brief, type, intent, audience, keywords, theme, and suggested month. By default, all are selected. Uncheck any you don't want.</li>
          <li><strong>Copy Ideas:</strong> Click "Copy Generated JSON" to copy the raw JSON output from the AI (as provided in the `responseText`) to your clipboard. This is useful for debugging or using the data elsewhere.</li>
          <li><strong>Add to Calendar:</strong> Click "Add Selected to Calendar." Chosen topics will be added to your Content Calendar in the "Ideation" stage, ready for further development and refinement in the modal. Each added idea is logged to Google Sheets.</li>
          <li><strong>Error Handling:</strong> If the AI encounters an issue or the response isn't parsable, an error message will be displayed. You might need to adjust your inputs or try again.</li>
        </ul>
        <p>This tool helps you populate your calendar with AI-suggested content ideas, which you can then refine and manage through their lifecycle.</p>
      </HelpPanel>
    </div>
  );
};
export default TopicGeneratorPage;