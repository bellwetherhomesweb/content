
import React from 'react';
import { ActivePage } from '../types';
import { BRAND_SECONDARY, BRAND_ORANGE_LIGHT, BRAND_PRIMARY } from '../constants';

interface NavButtonProps {
  target: ActivePage;
  label: string;
  isActive: boolean;
  onClick: (target: ActivePage) => void;
}

const NavButton: React.FC<NavButtonProps> = ({ target, label, isActive, onClick }) => {
  const activeClasses = `bg-[${BRAND_SECONDARY}] text-white shadow-md border-[${BRAND_SECONDARY}]`;
  const inactiveClasses = `bg-white text-slate-700 hover:bg-orange-50 hover:text-[${BRAND_PRIMARY}] shadow-sm border-slate-200 hover:border-orange-300`;
  
  return (
    <button
      onClick={() => onClick(target)}
      className={`nav-button px-3.5 py-2 md:px-4 md:py-2.5 text-xs md:text-sm font-semibold rounded-lg transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[${BRAND_PRIMARY}] border ${isActive ? activeClasses : inactiveClasses}`}
    >
      {label}
    </button>
  );
};

interface NavigationProps {
  activePage: ActivePage;
  onNavigate: (target: ActivePage, params?: Record<string, any>) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activePage, onNavigate }) => {
  const navItems: { target: ActivePage; label: string }[] = [
    { target: 'overview', label: 'Overview' },
    { target: 'topic-generator', label: '✨ AI Topic Generator' },
    { target: 'intent-planner', label: 'Intent Planner' },
    { target: 'audit', label: 'Content Audit' },
    { target: 'calendar', label: 'Calendar' },
    { target: 'strategy', label: 'Strategy Blueprint' },
    { target: 'competitor-analysis', label: 'Competitor Analysis' },
  ];

  return (
    <nav className="flex flex-wrap gap-2 md:gap-3 mb-6 md:mb-8 border-b-2 border-orange-300 pb-4 md:pb-5 justify-center">
      {navItems.map(item => (
        <NavButton
          key={item.target}
          target={item.target}
          label={item.label}
          isActive={activePage === item.target}
          onClick={() => onNavigate(item.target)}
        />
      ))}
    </nav>
  );
};

export default Navigation;