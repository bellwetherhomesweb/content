
import React from 'react';
import Loader from './Loader';
import { GroundingChunk } from '../../types';
import { ExternalLinkIcon, CopyIcon } from './Icons';
import { BRAND_PRIMARY } from '../../constants';

interface AIContentDisplayProps {
  isLoading: boolean;
  aiGeneratedContent: string | null;
  // aiGeneratedImage: string | null; // Prop removed
  error?: string | null;
  groundingChunks?: GroundingChunk[];
  onCopyText?: (textToCopy: string) => void;
  title?: string;
}

const AIContentDisplay: React.FC<AIContentDisplayProps> = ({
  isLoading,
  aiGeneratedContent,
  // aiGeneratedImage, // Prop removed
  error,
  groundingChunks,
  onCopyText,
  title = "AI Generated Output"
}) => {

  const formatAIResponseText = (text: string | null): string => {
    if (!text) return '';
    let formatted = text.replace(/\\*\\*(.*?)\\*\\*/g, '<strong class="font-semibold text-slate-800">$1</strong>');
    formatted = formatted.replace(/(\n\* |\n- )/g, '<br>• ');
    formatted = formatted.replace(/\n([1-9]\.)/g, '<br>$1');
    formatted = formatted.replace(/\n/g, '<br>');
    return formatted;
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-24 sm:h-32 my-3 p-3 bg-slate-100 rounded-lg border border-slate-200">
        <Loader />
        <p className="ml-3 text-slate-500">AI is thinking...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="my-3 p-3 bg-red-50 text-red-700 border border-red-200 rounded-lg shadow-sm">
        <p><strong>Error:</strong> {error}</p>
      </div>
    );
  }
  
  const hasContent = aiGeneratedContent || (groundingChunks && groundingChunks.length > 0);

  return (
    <div className="mt-3">
      {/* Image display logic removed */}
      
      {aiGeneratedContent && (
        <div className="relative mt-3 p-3 sm:p-4 bg-slate-100 rounded-lg prose prose-sm max-w-none prose-strong:text-slate-800 text-xs sm:text-sm border border-slate-200 shadow-inner">
          <div dangerouslySetInnerHTML={{ __html: formatAIResponseText(aiGeneratedContent) }} />
          {onCopyText && aiGeneratedContent && (
            <button
              onClick={() => onCopyText(aiGeneratedContent)}
              className="absolute top-1 right-1 sm:top-2 sm:right-2 text-slate-500 hover:text-[#DD5B42] p-1.5 rounded-full hover:bg-slate-200 transition-colors"
              title="Copy AI content to clipboard"
              aria-label="Copy AI generated content"
            >
              <CopyIcon className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {groundingChunks && groundingChunks.length > 0 && (
        <div className="mt-3 p-3 bg-slate-100 border border-slate-200 rounded-lg">
          <h5 className="font-semibold text-slate-800 mb-2 text-sm">Sources from Google Search:</h5>
          <ul className="list-disc list-inside space-y-1 text-xs">
            {groundingChunks.map((chunk, index) => (
              chunk.web && chunk.web.uri && (
                <li key={index}>
                  <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-[#DD5B42] hover:underline">
                    {chunk.web.title || chunk.web.uri}
                    <ExternalLinkIcon />
                  </a>
                </li>
              )
            ))}
          </ul>
        </div>
      )}
      
      {!hasContent && !isLoading && !error && (
         <div className="my-3 p-3 sm:p-4 bg-slate-100 rounded-lg min-h-[80px] sm:min-h-[100px] flex items-center justify-center border border-slate-200">
            <p className="text-slate-500 italic text-xs sm:text-sm">{title} will appear here...</p>
         </div>
      )}
    </div>
  );
};

export default AIContentDisplay;