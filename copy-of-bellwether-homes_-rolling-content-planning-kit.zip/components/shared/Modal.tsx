
import React, { useState, useEffect } from 'react';
import { CalendarContent, GroundingChunk, AuditEntry, GeminiTextResult } from '../../types';
import { generateGeminiText } from '../../services/geminiService';
import Loader from './Loader';
import { BRAND_PRIMARY, BRAND_SECONDARY, BRAND_TEXT_PRIMARY, BRAND_ORANGE_LIGHT } from '../../constants';
import { DownloadIcon, CopyIcon, ExternalLinkIcon, ImageIcon, SparklesIcon } from './Icons';
import { logAppAction } from '../../services/loggingService'; 
import AIContentDisplay from './AIContentDisplay'; 

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: CalendarContent | null;
  allCalendarData?: CalendarContent[]; 
  allAuditData?: AuditEntry[];      
  onCalendarItemUpdate?: (updatedItem: CalendarContent) => void;
  initialActionType?: string; 
}

const Modal: React.FC<ModalProps> = ({ 
    isOpen, 
    onClose, 
    item, 
    allCalendarData = [], 
    allAuditData = [],
    onCalendarItemUpdate,
    initialActionType 
}) => {
  const [aiGeneratedText, setAiGeneratedText] = useState<string | null>(null);
  // const [aiGeneratedImage, setAiGeneratedImage] = useState<string | null>(null); // Removed
  const [aiGroundingChunks, setAiGroundingChunks] = useState<GroundingChunk[]>([]);
  const [aiError, setAiError] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [copyStatus, setCopyStatus] = useState<string>('');
  const [editableBrief, setEditableBrief] = useState<string>(item?.brief || '');
  const [lastActionType, setLastActionType] = useState<string | null>(null); 

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'; 
      setAiGeneratedText(null);
      // setAiGeneratedImage(null); // Removed
      setAiGroundingChunks([]);
      setAiError(null);
      setCopyStatus('');
      setEditableBrief(item?.brief || '');
      setLastActionType(null); 
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
        document.body.style.overflow = 'auto'; 
    };
  }, [isOpen, item, initialActionType]);


  if (!isOpen || !item) {
    return null;
  }

  const handleBriefChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setEditableBrief(e.target.value);
  };

  const handleSaveBrief = () => {
    if (item && onCalendarItemUpdate) {
      onCalendarItemUpdate({ ...item, brief: editableBrief });
      showCopyStatus("Brief updated!");
       logAppAction({
          actionType: 'Calendar Item Update',
          pageContext: 'Modal',
          itemId: item.id,
          details: { updatedField: 'brief (manual save)', itemTitle: item.title, briefLength: editableBrief.length, source: 'manual', newBriefContent: editableBrief }
      });
    }
  };

  const showCopyStatus = (message: string, duration: number = 2000) => {
    setCopyStatus(message);
    setTimeout(() => setCopyStatus(''), duration);
  };

  const handleGeminiAction = async (actionType: string) => {
    setIsAiLoading(true);
    setAiGeneratedText(null);
    // setAiGeneratedImage(null); // Removed
    setAiGroundingChunks([]);
    setAiError(null);
    setLastActionType(actionType); 
    
    let prompt = '';
    let useSearch = false;
    let requestJsonOutput = false;
    const loggingDetails: Record<string, any> = { aiActionType: actionType, itemTitle: item.title };

    const basePromptContext = `Context: Bellwether Homes content piece.
    Title: "${item.title}"
    Type: ${item.type}
    Theme: ${item.theme}
    Target Audience: ${item.audience}
    Current Brief/Core Message: "${editableBrief}"
    Keywords: ${item.keywords}
    Competitor Note: "${item.competitorRelevance}"
    Intent Stage: ${item.intent}`;

    switch (actionType) {
      case 'expandBrief':
        prompt = `${basePromptContext}\n\nTask: Generate a detailed content outline. Provide a compelling introduction, 3-5 main talking points with 2-3 sub-points/questions each, and a concluding paragraph with a clear call-to-action. Ensure the outline is advanced, well-reasoned, and aligns with Bellwether's premium, expert positioning for the Colorado market.`;
        break;
      case 'generateSocials':
        prompt = `${basePromptContext}\n\nTask: Generate 3 distinct social media posts to promote this content. Bellwether Homes website is bellwetherhomes.com.
        1. **LinkedIn Post:** Professional, value-focused, targeting Colorado professionals/homeowners.
        2. **Facebook Post:** Engaging, community-oriented, ask a question relevant to Colorado homeowners.
        3. **Instagram Post:** Visually descriptive caption for a potential image related to Colorado homes/exteriors. Include relevant Colorado-centric hashtags.`;
        break;
      case 'brainstormKeywords':
        prompt = `${basePromptContext}\n\nTask: Brainstorm additional SEO keywords. Organize into:
        1. **Long-Tail Keywords:** (e.g., "cost of James Hardie siding replacement Denver suburbs")
        2. **LSI Keywords (Latent Semantic Indexing):** (e.g., "Colorado siding durability," "high-altitude window performance," "exterior home value increase Denver")
        3. **User Questions (for PAA section):** (e.g., "How does Colorado climate affect different siding materials?")`;
        break;
      case 'draftVideoScript':
        prompt = `${basePromptContext}\n\nTask: Draft a YouTube video script. Tone: expert yet approachable.
        Structure:
        1. **Hook (5-10s):** Grab attention, relate to Colorado homeowners.
        2. **Introduction:** Briefly state video's value proposition.
        3. **Main Points (3-4 sections):** Detail core message. Suggest specific visuals relevant to Colorado (e.g., 'B-roll of hail resistant siding on a Denver home,' 'Graphic showing U-factor for mountain climate windows').
        4. **Conclusion & CTA:** Summarize. Direct to Bellwether Homes for consultation on their Colorado property.`;
        break;
      case 'checkRecentNews':
        prompt = `Task: Identify any very recent (last 1-2 weeks) news, building code changes, or major weather events in Colorado relevant to exterior remodeling (siding, windows, doors) that Bellwether Homes should consider for the content piece: "${item.title}" (Brief: ${editableBrief}). Focus on actionable information for a premium Colorado remodeler.`;
        useSearch = true;
        break;
      case 'refineBriefForAudience': 
        prompt = `${basePromptContext}\n\nTask: Refine the content brief to be highly impactful for the specified target audience and their intent stage. Focus on clarity, directly addressing their needs/questions at this stage, and crafting a compelling angle unique to Bellwether's expertise in Colorado. Output *only* the revised brief text, ready to replace the current brief.`;
        break;
      case 'suggestInternalLinks': 
        const otherCalendarTitles = allCalendarData.filter(ci => ci.id !== item.id).map(ci => ci.title).join("; ");
        const auditBlogTitles = allAuditData.map(ai => ai.blogTitle).join("; ");
        prompt = `${basePromptContext}\n\nExisting Content Inventory (Titles):
        Other Planned Calendar Content: ${otherCalendarTitles || "None"}
        Existing Blog Posts (from Audit): ${auditBlogTitles || "None"}

        Task: Suggest 3-5 strategic internal linking opportunities. For each:
        1. Direction: Link *from* current piece *to* existing, or *vice-versa*.
        2. Specific Title: Identify the content to link to/from.
        3. Rationale: Explain SEO/user experience benefit for Bellwether's Colorado audience.
        Format as a numbered list.`;
        break;
      case 'visualizeConcept': // Modified prompt for textual visual description
        prompt = `Describe a visual concept or suggest elements for a diagram/chart for a content piece.
        Title: "${item.title}"
        Type: ${item.type}
        Core Message: "${editableBrief}"
        Audience: ${item.audience}
        Desired visual style: Professional, high-quality, relevant to Colorado homes/landscapes, appealing to a premium clientele.
        For a blog, this could be elements for an infographic, a simple chart, or a conceptual diagram.
        For a video, describe a key visual scene, a graph to include, or a diagram to illustrate a point.
        Provide a textual description of the visual and its purpose. If suggesting a chart or diagram, briefly outline its key data points or structure. Example: 'A bar chart showing energy savings with different window types. X-axis: Window Type (Vinyl, Fiberglass, Wood). Y-axis: Estimated Annual Savings ($). Data: Vinyl $150, Fiberglass $250, Wood $200.'`;
        requestJsonOutput = false; // Ensure this is false if expecting free text
        break;
    }
    
    loggingDetails.promptLength = prompt.length;
    loggingDetails.originalPrompt = prompt;

    const result: GeminiTextResult = await generateGeminiText(prompt, useSearch, undefined, false, requestJsonOutput);
    if (result.error) {
        setAiError(result.error);
        loggingDetails.error = result.error;
        loggingDetails.status = 'error';
    } else {
        setAiGeneratedText(result.text);
        loggingDetails.generatedText = result.text;
        loggingDetails.status = 'success';
        if (actionType === 'refineBriefForAudience' && onCalendarItemUpdate && result.text) {
            const refinedBriefText = result.text.trim(); 
            if (refinedBriefText) {
                setEditableBrief(refinedBriefText); 
                onCalendarItemUpdate({ ...item, brief: refinedBriefText }); 
                showCopyStatus("Brief refined by AI and saved!");
                 logAppAction({
                    actionType: 'Calendar Item Update',
                    pageContext: 'Modal',
                    itemId: item.id,
                    details: { 
                        updatedField: 'brief', 
                        itemTitle: item.title, 
                        briefLength: refinedBriefText.length, 
                        newBriefContent: refinedBriefText,
                        source: 'AI refineBriefForAudience',
                        originalPromptForRefinement: prompt 
                    }
                });
            }
        }
        if (result.groundingChunks) {
            setAiGroundingChunks(result.groundingChunks.filter(chunk => chunk.web && chunk.web.uri && chunk.web.title));
            loggingDetails.groundingChunks = result.groundingChunks;
        }
    }
    
    logAppAction({
        actionType: 'AI Action Result',
        pageContext: 'Modal',
        itemId: item.id,
        details: loggingDetails
    });
    setIsAiLoading(false);
  };

  const handleSimpleCopyToClipboard = (text: string, successMessage: string = 'Copied!') => {
    navigator.clipboard.writeText(text)
      .then(() => showCopyStatus(successMessage))
      .catch(err => {
        console.error('Failed to copy: ', err);
        showCopyStatus('Failed to copy');
      });
  };

  const handleCopyMarkdown = () => {
    let markdown = `# ${item.title}\n\n`;
    markdown += `**Type:** ${item.type}\n`;
    markdown += `**Theme:** ${item.theme}\n`;
    markdown += `**Audience:** ${item.audience}\n`;
    markdown += `**Intent:** ${item.intent}\n\n`;
    markdown += `## Brief\n${editableBrief}\n\n`;
    if (aiGeneratedText) { // Check if aiGeneratedText has content
      markdown += `## AI Generated Content (${lastActionType})\n${aiGeneratedText}\n`; 
    }
    handleSimpleCopyToClipboard(markdown, "Markdown Copied!");
    logAppAction({ actionType: 'Export Data', pageContext: 'Modal', itemId: item.id, details: { exportType: 'Copy Markdown', itemTitle: item.title, markdownContent: markdown }});
  };

  const handleDownloadTxt = () => {
    let text = `Title: ${item.title}\n`;
    text += `Type: ${item.type}\n`;
    text += `Theme: ${item.theme}\n`;
    text += `Audience: ${item.audience}\n`;
    text += `Intent: ${item.intent}\n\n`;
    text += `Brief:\n${editableBrief}\n\n`;
    if (aiGeneratedText) { 
      text += `AI Generated Content (${lastActionType}):\n${aiGeneratedText}\n`; 
    }
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${item.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_details.txt`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    logAppAction({ actionType: 'Export Data', pageContext: 'Modal', itemId: item.id, details: { exportType: 'TXT', itemTitle: item.title, textContentLength: text.length }});
  };
  
  const handleCopyFullDetails = () => {
    let details = `Title: ${item.title}\n`;
    details += `Month: ${item.month}\n`;
    details += `Theme: ${item.theme}\n`;
    details += `Type: ${item.type}\n`;
    details += `Status: ${item.status}\n`;
    details += `Intent: ${item.intent}\n`;
    details += `Audience: ${item.audience}\n`;
    details += `Keywords: ${item.keywords}\n\n`;
    details += `Brief:\n${editableBrief}\n\n`;
    details += `Competitor Relevance:\n${item.competitorRelevance}\n\n`;
    if (aiGeneratedText) { 
      details += `AI Generated Content (${lastActionType}):\n${aiGeneratedText}\n`; 
    }
    handleSimpleCopyToClipboard(details, "Full Details Copied!");
    logAppAction({ actionType: 'Export Data', pageContext: 'Modal', itemId: item.id, details: { exportType: 'Copy Full Details', itemTitle: item.title, fullDetailsContent: details }});
  };

  const handleDownloadPdf = () => {
    const { jsPDF } = (window as any).jspdf;
    if (!jsPDF || !item) return;

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    let yPos = 40; 
    const pageMargin = 40;
    const contentWidth = doc.internal.pageSize.getWidth() - 2 * pageMargin;

    doc.setFont('Work Sans', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(BRAND_SECONDARY);
    doc.text(item.title, doc.internal.pageSize.getWidth() / 2, yPos, { align: 'center', maxWidth: contentWidth });
    yPos += doc.getTextDimensions(item.title, {maxWidth: contentWidth}).h + 20;
    
    const addSection = (title: string, content: string | null, isHtml = false, isSmall = false) => {
        if (!content) return;
        if (yPos > doc.internal.pageSize.getHeight() - 80) { doc.addPage(); yPos = 40; }
        doc.setFont('Work Sans', 'bold');
        doc.setFontSize(isSmall ? 10 : 12);
        doc.setTextColor(BRAND_PRIMARY);
        doc.text(title, pageMargin, yPos);
        yPos += isSmall ? 15 : 18;
        
        doc.setFont('Work Sans', 'normal');
        doc.setFontSize(isSmall ? 9 : 10);
        doc.setTextColor(BRAND_TEXT_PRIMARY);
        
        let textToSplit = content;
        if (isHtml) {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = content.replace(/<br\s*\/?>/gi, '\n').replace(/• /g, '  • ');
            textToSplit = tempDiv.innerText;
        }
        const splitText = doc.splitTextToSize(textToSplit, contentWidth);
        doc.text(splitText, pageMargin, yPos);
        yPos += (splitText.length * (isSmall ? 11 : 12)) + (isSmall ? 10 : 14); 
    };
    
    addSection('Content Type:', item.type, false, true);
    addSection('Theme:', item.theme, false, true);
    addSection('Target Audience:', item.audience, false, true);
    addSection('Primary Keywords:', item.keywords, false, true);
    addSection('Brief & Angle:', editableBrief); 
    addSection('Competitor Relevance:', item.competitorRelevance);
        
    if (aiGeneratedText && aiGeneratedText.trim() !== '') {
        addSection(`AI-Generated Content (${lastActionType})`, aiGeneratedText, false); 
    }
    
    if (aiGroundingChunks.length > 0) {
        let sourcesText = "";
        aiGroundingChunks.forEach(chunk => {
            if (chunk.web && chunk.web.uri) { 
                sourcesText += `${chunk.web.title || 'N/A'}: ${chunk.web.uri}\n`;
            }
        });
        if (sourcesText) addSection("Sources from Google Search", sourcesText, false, true);
    }

    doc.save(`${item.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_brief.pdf`);
    logAppAction({ actionType: 'Export Data', pageContext: 'Modal', itemId: item.id, details: { exportType: 'PDF', itemTitle: item.title }});
  };


  const geminiButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-80 text-white px-3 py-2 md:px-4 rounded-lg text-xs md:text-sm font-semibold transition-colors duration-200 disabled:bg-opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 shadow-md hover:shadow-lg`;
  const exportButtonBaseClasses = `bg-slate-600 hover:bg-slate-700 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors duration-200 shadow hover:shadow-md`;
  const inputBaseClasses = "w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-900 text-sm";
  const labelBaseClasses = "font-semibold text-slate-800 block mb-1 text-sm";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-40 flex items-center justify-center p-2 sm:p-4 transition-opacity duration-300 ease-in-out" onClick={onClose}>
      <div 
        className="bg-slate-50 w-full sm:w-11/12 md:max-w-3xl lg:max-w-4xl mx-auto rounded-xl shadow-2xl p-5 sm:p-6 md:p-8 relative max-h-[95vh] sm:max-h-[90vh] overflow-y-auto flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-4 pb-4 border-b border-slate-300">
          <h3 className="text-xl sm:text-2xl font-bold text-slate-800">{item.title}</h3>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-slate-700 text-3xl sm:text-4xl font-light leading-none -mt-2 -mr-2 p-1 rounded-full hover:bg-slate-200 transition-colors"
            aria-label="Close modal"
          >
            &times;
          </button>
        </div>

        <div className="flex-grow overflow-y-auto pr-2 space-y-5">
            <div className="bg-white p-4 rounded-lg shadow border border-slate-200">
                <div className="flex flex-wrap gap-x-3 gap-y-2 mb-3 text-xs">
                  <span className={`bg-orange-100 text-[${BRAND_SECONDARY}] px-3 py-1 rounded-full font-semibold`}>{item.month}</span>
                  <span className={`bg-sky-100 text-sky-700 px-3 py-1 rounded-full font-semibold`}>{item.type}</span>
                  <span className={`bg-violet-100 text-violet-700 px-3 py-1 rounded-full font-semibold`}>{item.intent.split('/')[0]}</span>
                  <span className={`px-3 py-1 rounded-full font-semibold ${item.status === 'Published' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span>
                </div>

                <div className="space-y-3 text-slate-700 text-sm">
                  <div><strong className={labelBaseClasses}>Theme:</strong> {item.theme}</div>
                  <div><strong className={labelBaseClasses}>Target Audience:</strong> {item.audience}</div>
                  <div><strong className={labelBaseClasses}>Primary Keywords:</strong> <code className="text-xs bg-slate-200 text-slate-700 p-1 rounded">{item.keywords}</code></div>
                  <div className="space-y-1">
                    <label htmlFor="modalBrief" className={labelBaseClasses}>Content Brief & Angle:</label>
                    <textarea
                      id="modalBrief"
                      value={editableBrief}
                      onChange={handleBriefChange}
                      onBlur={handleSaveBrief} 
                      rows={5}
                      className={inputBaseClasses}
                      aria-label="Content brief and angle"
                    />
                    <button 
                        onClick={handleSaveBrief}
                        className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 px-2.5 py-1 rounded-md"
                        aria-label="Save content brief"
                    >Save Brief</button>
                  </div>
                  <div><strong className={labelBaseClasses}>Competitor Relevance:</strong> <p className="mt-1 text-sm">{item.competitorRelevance}</p></div>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                    <button onClick={handleDownloadPdf} className={`${exportButtonBaseClasses} !bg-[${BRAND_PRIMARY}] !hover:bg-opacity-80`} aria-label="Download content brief as PDF">
                        <DownloadIcon className="w-3.5 h-3.5"/> PDF
                    </button>
                    <button onClick={handleCopyMarkdown} className={exportButtonBaseClasses} aria-label="Copy brief as Markdown">Copy Markdown</button>
                    <button onClick={handleDownloadTxt} className={exportButtonBaseClasses} aria-label="Download brief as text file">Download .TXT</button>
                    <button onClick={handleCopyFullDetails} className={exportButtonBaseClasses} aria-label="Copy all details to clipboard">Copy Full Details</button>
                </div>
            </div>


            <div className="space-y-3 bg-white p-4 rounded-lg shadow border border-slate-200">
              <div className="flex justify-between items-center">
                <h4 className="text-md sm:text-lg font-bold text-slate-800 flex items-center gap-2"><SparklesIcon className="text-[#DD5B42] w-5 h-5"/>AI Content Assistant</h4>
                {copyStatus && <span className="text-xs sm:text-sm font-semibold text-green-600 transition-opacity duration-300">{copyStatus}</span>}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                <button onClick={() => handleGeminiAction('expandBrief')} className={geminiButtonClasses} disabled={isAiLoading}>✨ Expand Brief</button>
                <button onClick={() => handleGeminiAction('generateSocials')} className={geminiButtonClasses} disabled={isAiLoading}>✨ Gen Socials</button>
                <button onClick={() => handleGeminiAction('brainstormKeywords')} className={geminiButtonClasses} disabled={isAiLoading}>✨ Keywords</button>
                {item.type === 'YouTube Video' && (
                  <button onClick={() => handleGeminiAction('draftVideoScript')} className={geminiButtonClasses} disabled={isAiLoading}>✨ Video Script</button>
                )}
                <button onClick={() => handleGeminiAction('checkRecentNews')} className={geminiButtonClasses} disabled={isAiLoading}>🔍 Recent News</button>
                <button onClick={() => handleGeminiAction('refineBriefForAudience')} className={geminiButtonClasses} disabled={isAiLoading} title="Refine brief for current audience & intent">🎯 Refine Brief</button>
                <button onClick={() => handleGeminiAction('suggestInternalLinks')} className={geminiButtonClasses} disabled={isAiLoading} title="Suggest internal links to other content">🔗 Suggest Links</button>
                <button onClick={() => handleGeminiAction('visualizeConcept')} className={geminiButtonClasses} disabled={isAiLoading} title="Get AI suggestions for a visual concept (diagram, chart, etc.)">
                  <ImageIcon className="w-4 h-4"/> Visual Idea
                </button>
              </div>
              <AIContentDisplay
                isLoading={isAiLoading}
                aiGeneratedContent={aiGeneratedText}
                // aiGeneratedImage={null} // Prop removed
                error={aiError}
                groundingChunks={aiGroundingChunks}
                onCopyText={(textToCopy) => {
                    handleSimpleCopyToClipboard(textToCopy, "AI Content Copied!");
                     logAppAction({
                        actionType: 'AI Content Copied',
                        pageContext: 'Modal',
                        itemId: item.id,
                        details: { itemTitle: item.title, copiedActionType: lastActionType, copiedText: textToCopy }
                    });
                }}
              />
            </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;