
import React, { ReactNode } from 'react';
import { BRAND_PRIMARY, BRAND_ORANGE_LIGHT, BRAND_TEXT_PRIMARY, BRAND_SECONDARY } from '../../constants';

interface HelpPanelProps {
  title: string;
  children: ReactNode;
  isOpen: boolean;
  onClose: () => void;
}

const HelpPanel: React.FC<HelpPanelProps> = ({ title, children, isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 transition-opacity duration-300 ease-in-out"
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-panel-title"
    >
      <div 
        className={`bg-[${BRAND_ORANGE_LIGHT}] text-slate-700 p-6 sm:p-8 rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto border-t-4 border-[${BRAND_PRIMARY}] flex flex-col`}
        onClick={(e) => e.stopPropagation()} 
      >
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-orange-300">
          <h3 id="help-panel-title" className="text-xl sm:text-2xl font-bold" style={{ color: BRAND_PRIMARY }}>{title}</h3>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-slate-600 text-3xl sm:text-4xl font-light leading-none -mt-2 -mr-2 p-1 rounded-full hover:bg-orange-200 transition-colors"
            aria-label="Close help panel"
          >
            &times;
          </button>
        </div>
        <div className="prose prose-sm sm:prose-base max-w-none prose-headings:text-[#DD5B42] prose-headings:font-semibold prose-strong:text-slate-700 prose-a:text-[#A54432] hover:prose-a:text-[#DD5B42] prose-ul:list-disc prose-ul:ml-5 prose-li:mb-1 prose-p:leading-relaxed prose-p:text-slate-700">
          {children}
        </div>
      </div>
    </div>
  );
};

export default HelpPanel;