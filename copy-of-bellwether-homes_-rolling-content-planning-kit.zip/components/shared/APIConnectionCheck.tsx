
import React, { useState } from 'react';
import { generateGeminiText } from '../../services/geminiService';
import Loader from './Loader';
import { CheckCircleIcon, XCircleIcon, SignalIcon } from './Icons';
import { BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import { logAppAction } from '../../services/loggingService';
import { GeminiTextResult } from '../../types'; // Import GeminiTextResult

type APIStatus = 'idle' | 'loading' | 'success' | 'error';

const APIConnectionCheck: React.FC = () => {
  const [status, setStatus] = useState<APIStatus>('idle');
  const [message, setMessage] = useState<string>('Check API Status');

  const handleTestConnection = async () => {
    setStatus('loading');
    setMessage('Testing...');
    logAppAction({ actionType: 'API Connection Test', pageContext: 'Global', details: { status: 'initiated' }});

    try {
      // Use disableThinking for a faster, lower-cost check if desired, though a simple "Hello" is already minimal.
      const result: GeminiTextResult = await generateGeminiText("Hello", false, undefined, true); 
      if (result.error) {
        setStatus('error');
        setMessage('Gemini API: Failed');
        console.error("API Connection Check Failed:", result.error);
        logAppAction({ actionType: 'API Connection Test', pageContext: 'Global', details: { status: 'error', error: result.error }});
      } else if (result.text) { // Successfully got text without error
        setStatus('success');
        setMessage('Gemini API: Connected');
        logAppAction({ actionType: 'API Connection Test', pageContext: 'Global', details: { status: 'success', responseSnippet: result.text.substring(0,20) }});
      } else { // No error, but no text either (shouldn't happen for a simple "Hello" prompt)
        setStatus('error');
        setMessage('Gemini API: Empty Response');
        console.error("API Connection Check: Empty response without error.");
        logAppAction({ actionType: 'API Connection Test', pageContext: 'Global', details: { status: 'error', error: "Empty response" }});
      }
    } catch (e) { // Catch network errors or unexpected issues in generateGeminiText itself
      setStatus('error');
      setMessage('Gemini API: Error');
      console.error("API Connection Check Exception:", e);
      logAppAction({ actionType: 'API Connection Test', pageContext: 'Global', details: { status: 'exception', error: (e as Error).message }});
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'success': return 'text-green-600';
      case 'error': return 'text-red-600';
      default: return 'text-slate-600';
    }
  };

  const getButtonBgColor = () => {
    switch (status) {
      case 'success': return 'bg-green-100 hover:bg-green-200';
      case 'error': return 'bg-red-100 hover:bg-red-200';
      case 'loading': return 'bg-slate-100 cursor-not-allowed';
      default: return 'bg-slate-200 hover:bg-slate-300';
    }
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleTestConnection}
        disabled={status === 'loading'}
        className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors duration-200 flex items-center gap-1.5 shadow-sm ${getButtonBgColor()} ${getStatusColor()}`}
        title="Test connection to the Gemini API"
      >
        {status === 'loading' ? (
          <Loader />
        ) : status === 'success' ? (
          <CheckCircleIcon className="w-4 h-4" />
        ) : status === 'error' ? (
          <XCircleIcon className="w-4 h-4" />
        ) : (
          <SignalIcon className="w-4 h-4" />
        )}
        <span>{message}</span>
      </button>
    </div>
  );
};

export default APIConnectionCheck;