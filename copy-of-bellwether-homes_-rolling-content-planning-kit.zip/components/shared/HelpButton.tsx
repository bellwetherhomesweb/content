
import React from 'react';
import { HelpCircleIcon } from './Icons';
import { BRAND_PRIMARY } from '../../constants';

interface HelpButtonProps {
  onClick: () => void;
  isPanelOpen?: boolean;
  className?: string;
  label?: string;
}

const HelpButton: React.FC<HelpButtonProps> = ({ onClick, isPanelOpen, className, label = "Help" }) => {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-200
                  ${isPanelOpen ? `bg-[${BRAND_PRIMARY}] text-white` : `bg-gray-200 text-gray-700 hover:bg-gray-300`}
                  ${className || ''}`}
      aria-expanded={isPanelOpen}
      aria-label={isPanelOpen ? "Close help panel" : "Open help panel"}
    >
      <HelpCircleIcon className="w-4 h-4" />
      {label}
    </button>
  );
};

export default HelpButton;