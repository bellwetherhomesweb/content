
import React from 'react';

const Loader: React.FC = () => {
  return <div className="loader" aria-label="Loading..."></div>;
};

export default Loader;