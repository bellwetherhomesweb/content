
import React, { useState } from 'react';
import { BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import { SearchIcon } from './Icons'; 

const GlobalSearchInput: React.FC<{
  onSearch: (searchTerm: string) => void;
  initialTerm?: string;
}> = ({ onSearch, initialTerm = '' }) => {
  const [searchTerm, setSearchTerm] = useState(initialTerm);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm.trim());
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6 md:mb-8 p-1.5 bg-white rounded-xl shadow-lg flex gap-1.5 items-center border border-slate-200">
      <div className="relative flex-grow">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <SearchIcon className="w-5 h-5 text-slate-400" />
        </div>
        <input
          type="search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Global Search: Content, Audit, Strategy..."
          className="w-full py-3 px-4 pl-12 border-0 focus:ring-0 bg-transparent text-slate-800 placeholder-slate-500 text-sm rounded-lg"
          aria-label="Global search input"
        />
      </div>
      <button
        type="submit"
        className={`bg-[${BRAND_PRIMARY}] hover:bg-[${BRAND_SECONDARY}] text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[${BRAND_PRIMARY}]`}
        aria-label="Perform search"
      >
        Search
      </button>
    </form>
  );
};

export default GlobalSearchInput;