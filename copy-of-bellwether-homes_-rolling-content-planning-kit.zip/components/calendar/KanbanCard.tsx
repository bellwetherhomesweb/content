
import React from 'react';
import { CalendarContent } from '../../types';

interface KanbanCardProps {
  item: CalendarContent;
  onClick: () => void;
  onDragStart: () => void;
}

const KanbanCard: React.FC<KanbanCardProps> = ({ item, onClick, onDragStart }) => {
  const typeClasses = item.type === 'YouTube Video' 
    ? "text-red-700 bg-red-100" 
    : "text-blue-700 bg-blue-100";

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onClick={onClick}
      className="kanban-card bg-white p-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 ease-in-out cursor-grab active:cursor-grabbing border border-slate-200 hover:border-slate-300"
      aria-label={`Content item: ${item.title}, status ${item.status}. Click or drag to interact.`}
    >
      <h5 className="text-sm font-semibold text-slate-800 line-clamp-2 mb-1.5">{item.title}</h5>
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span className={`${typeClasses} px-2 py-0.5 rounded-full text-[10px] font-medium`}>
          {item.type.split(' ')[0]}
        </span>
        <span className="text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full text-[10px] font-medium">
          {item.intent.split('/')[0]}
        </span>
      </div>
       <p className="text-xs text-slate-500 mt-2 truncate">{item.audience}</p>
    </div>
  );
};

export default KanbanCard;