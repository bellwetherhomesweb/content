
import React from 'react';
import { CalendarContent } from '../../types';
import { BRAND_PRIMARY } from '../../constants';

interface ContentCardProps {
  item: CalendarContent;
  onClick: (item: CalendarContent) => void;
}

const ContentCard: React.FC<ContentCardProps> = ({ item, onClick }) => {
  const typeIcon = item.type === 'YouTube Video' 
    ? <span className="text-xs font-semibold uppercase tracking-wider text-red-600 bg-red-100 px-2.5 py-1 rounded-full">Video</span>
    : <span className="text-xs font-semibold uppercase tracking-wider text-blue-600 bg-blue-100 px-2.5 py-1 rounded-full">Blog</span>;

  return (
    <div
      onClick={() => onClick(item)}
      className="content-card cursor-pointer bg-white p-5 rounded-xl shadow-lg border border-slate-200 hover:border-[#DD5B42] hover:shadow-xl transition-all duration-300 ease-in-out group flex flex-col h-full"
      role="button"
      tabIndex={0}
      onKeyPress={(e) => (e.key === 'Enter' || e.key === ' ') && onClick(item)}
      aria-label={`View details for ${item.title}`}
    >
      <div className="flex justify-between items-start mb-3">
        {typeIcon}
        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${item.status === 'Published' || item.status === 'Scheduled' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
          {item.status}
        </span>
      </div>
      <h4 className="font-semibold text-md md:text-lg text-slate-800 group-hover:text-[#DD5B42] transition-colors duration-200 mb-1.5 line-clamp-2 flex-grow">{item.title}</h4>
      <p className="text-xs text-slate-500 mb-3">{item.month} - {item.theme}</p>
      <div className="mt-auto pt-3 border-t border-slate-100">
        <p className="text-xs text-purple-700 bg-purple-100 px-2.5 py-1 rounded-full inline-block font-medium">
          {item.intent.split('/')[0]}
        </p>
      </div>
    </div>
  );
};

export default ContentCard;