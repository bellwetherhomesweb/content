
import React from 'react';
import { CalendarContent, ContentStatus } from '../../types';
import KanbanCard from './KanbanCard';
import { BRAND_SECONDARY, BRAND_PRIMARY } from '../../constants';

interface KanbanColumnProps {
  status: ContentStatus;
  items: CalendarContent[];
  onOpenModal: (item: CalendarContent) => void;
  onDrop: (status: ContentStatus) => void;
  onDragStartCard: (itemId: string) => void;
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({ status, items, onOpenModal, onDrop, onDragStartCard }) => {
  const [isOver, setIsOver] = React.useState(false);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    setIsOver(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsOver(false);
    onDrop(status);
  };

  const statusHeaderColors: Record<ContentStatus, string> = {
    Ideation: 'text-yellow-800 bg-yellow-100 border-yellow-300',
    Drafting: 'text-blue-800 bg-blue-100 border-blue-300',
    Review: `text-[${BRAND_SECONDARY}] bg-orange-100 border-orange-300`,
    Scheduled: 'text-teal-800 bg-teal-100 border-teal-300',
    Published: 'text-green-800 bg-green-100 border-green-300',
  };


  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`kanban-column bg-slate-100 p-3 sm:p-4 rounded-xl shadow-lg w-72 sm:w-80 min-w-[280px] sm:min-w-[310px] flex-shrink-0 h-full flex flex-col transition-all duration-200 ease-in-out border-2 ${isOver ? `border-dashed border-[${BRAND_PRIMARY}] bg-orange-50 scale-105` : 'border-transparent'}`}
      aria-label={`${status} column, ${items.length} items`}
    >
      <h3 
        className={`text-sm sm:text-base font-semibold mb-3 p-2.5 rounded-md text-center shadow-sm border-b-2 ${statusHeaderColors[status]}`}
      >
        {status} <span className="text-xs opacity-75">({items.length})</span>
      </h3>
      <div className="space-y-3 min-h-[200px] overflow-y-auto flex-grow pr-1 pb-1 custom-scrollbar"> {/* Added custom-scrollbar class for targeted styling if needed */}
        {items.map(item => (
          <KanbanCard 
            key={item.id} 
            item={item} 
            onClick={() => onOpenModal(item)}
            onDragStart={() => onDragStartCard(item.id)}
          />
        ))}
        {items.length === 0 && <p className="text-xs text-slate-400 italic text-center pt-10">Drag items here</p>}
      </div>
    </div>
  );
};

export default KanbanColumn;