
import React from 'react';
import { CalendarContent, ContentStatus } from '../../types';
import KanbanColumn from './KanbanColumn';
import { logAppAction } from '../../services/loggingService'; 

interface KanbanViewProps {
  statuses: ContentStatus[];
  data: CalendarContent[];
  onOpenModal: (item: CalendarContent) => void;
  onStatusUpdate: (itemId: string, newStatus: ContentStatus) => void;
}

const KanbanView: React.FC<KanbanViewProps> = ({ statuses, data, onOpenModal, onStatusUpdate }) => {
  const [draggedItemId, setDraggedItemId] = React.useState<string | null>(null);

  const handleDragStart = (itemId: string) => {
    setDraggedItemId(itemId);
  };

  const handleDrop = (newStatus: ContentStatus) => {
    if (draggedItemId) {
      const originalItem = data.find(item => item.id === draggedItemId);
      if (originalItem && originalItem.status !== newStatus) {
        logAppAction({
          actionType: 'Status Update',
          pageContext: 'calendar', 
          itemId: draggedItemId,
          details: { 
            itemTitle: originalItem.title,
            oldStatus: originalItem.status, 
            newStatus: newStatus 
          }
        });
      }
      onStatusUpdate(draggedItemId, newStatus);
      setDraggedItemId(null);
    }
  };

  if (data.length === 0) {
    return <p className="text-slate-600 text-center py-10 mt-6 italic">No content matches the selected filters for the Kanban view.</p>;
  }
  
  return (
    <div className="mt-6 flex gap-4 md:gap-5 overflow-x-auto pb-4 -mx-4 px-4 md:-mx-6 md:px-6"> 
      {statuses.map(status => (
        <KanbanColumn
          key={status}
          status={status}
          items={data.filter(item => item.status === status)}
          onOpenModal={onOpenModal}
          onDrop={handleDrop}
          onDragStartCard={handleDragStart}
        />
      ))}
    </div>
  );
};

export default KanbanView;