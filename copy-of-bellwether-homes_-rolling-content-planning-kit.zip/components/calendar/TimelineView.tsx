
import React from 'react';
import { CalendarContent } from '../../types';
import { STANDARD_MONTH_ORDER, BRAND_SECONDARY, BRAND_PRIMARY } from '../../constants';
import TimelineItem from './TimelineItem';

interface TimelineViewProps {
  data: CalendarContent[];
  onOpenModal: (item: CalendarContent) => void;
}

const TimelineView: React.FC<TimelineViewProps> = ({ data, onOpenModal }) => {
  // Get unique months from the data and sort them according to STANDARD_MONTH_ORDER
  const uniqueMonthsInData = [...new Set(data.map(item => item.month))];
  const sortedUniqueMonths = uniqueMonthsInData.sort((a, b) => {
    const indexA = STANDARD_MONTH_ORDER.indexOf(a);
    const indexB = STANDARD_MONTH_ORDER.indexOf(b);
    // Handle months not in STANDARD_MONTH_ORDER by placing them at the end or sorting alphabetically
    if (indexA === -1 && indexB === -1) return a.localeCompare(b);
    if (indexA === -1) return 1;
    if (indexB === -1) return -1;
    return indexA - indexB;
  });

  const groupedByMonth: { [key: string]: CalendarContent[] } = sortedUniqueMonths.reduce((acc, month) => {
    acc[month] = data.filter(item => item.month === month).sort((a,b) => a.title.localeCompare(b.title)); // Sort items within month by title
    return acc;
  }, {} as { [key: string]: CalendarContent[] });


  if (data.length === 0) {
    return <p className="text-slate-600 text-center py-10 mt-6 italic">No content matches the selected filters for the timeline view.</p>;
  }

  return (
    <div className="mt-6 space-y-6">
      {sortedUniqueMonths.map(month => {
        const itemsInMonth = groupedByMonth[month];
        if (!itemsInMonth || itemsInMonth.length === 0) { 
          return null; 
        }
        return (
          <section key={month} aria-labelledby={`month-header-${month}`} className="p-4 bg-slate-50 rounded-lg shadow-md border border-slate-200">
            <h3 
              id={`month-header-${month}`}
              className="text-lg md:text-xl font-semibold mb-4 pb-3 border-b-2"
              style={{ color: BRAND_PRIMARY, borderColor: BRAND_PRIMARY + '30' }} // Softer border
            >
              {month}
            </h3>
            {itemsInMonth.length > 0 ? (
              <div className="space-y-3">
                {itemsInMonth.map(item => (
                  <TimelineItem key={item.id} item={item} onClick={onOpenModal} />
                ))}
              </div>
            ) : (
              // This case should not be hit if !itemsInMonth || itemsInMonth.length === 0 check above works
              <p className="text-slate-500 italic text-sm py-4">No content scheduled for {month} with current filters.</p>
            )}
          </section>
        );
      })}
    </div>
  );
};

export default TimelineView;
