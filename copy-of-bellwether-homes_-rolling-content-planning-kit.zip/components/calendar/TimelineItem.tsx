
import React from 'react';
import { CalendarContent } from '../../types';
import { BRAND_PRIMARY } from '../../constants';

interface TimelineItemProps {
  item: CalendarContent;
  onClick: (item: CalendarContent) => void;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ item, onClick }) => {
  const typeClasses = item.type === 'YouTube Video' 
    ? "text-red-600 bg-red-100"
    : "text-blue-600 bg-blue-100";
  
  const intentShort = item.intent.split('/')[0];

  return (
    <button
      onClick={() => onClick(item)}
      className="w-full text-left p-3.5 bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 ease-in-out flex items-center border border-slate-200 hover:border-[#DD5B42] focus:outline-none focus:ring-2 focus:ring-[#DD5B42] focus:ring-offset-2 group"
      aria-label={`View details for ${item.title}`}
    >
      <div className={`mr-3 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${typeClasses} font-bold text-xs shadow-sm`}>
        {item.type === 'YouTube Video' ? 'YT' : 'B'}
      </div>
      <div className="flex-grow min-w-0"> 
        <h5 className="font-semibold text-slate-800 text-sm md:text-base group-hover:text-[#DD5B42] transition-colors truncate">{item.title}</h5>
        <div className="flex items-center text-xs mt-1 text-slate-500 flex-wrap gap-x-1.5 gap-y-1">
          <span className={`${typeClasses} px-1.5 py-0.5 rounded-full text-[10px] font-medium`}>
            {item.type.split(' ')[0]}
          </span>
          <span className="text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded-full text-[10px] font-medium">
            {intentShort}
          </span>
           <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${item.status === 'Published' || item.status === 'Scheduled' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
            {item.status}
          </span>
        </div>
      </div>
      <span className="text-slate-400 group-hover:text-[#DD5B42] transition-colors duration-200 ml-2 text-xl" aria-hidden="true">
        &rarr;
      </span>
    </button>
  );
};

export default TimelineItem;