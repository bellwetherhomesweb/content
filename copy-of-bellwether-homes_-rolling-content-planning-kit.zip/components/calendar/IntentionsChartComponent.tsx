
import React, { useEffect, useRef } from 'react';
import { Chart, BarController, BarElement, CategoryScale, LinearScale, Legend, Tooltip, Title } from 'chart.js';
import { CalendarContent, Intent } from '../../types';
import { INTENT_STAGES, BRAND_SECONDARY, BRAND_PRIMARY } from '../../constants';

Chart.register(BarController, BarElement, CategoryScale, LinearScale, Legend, Tooltip, Title);

interface IntentionsChartProps {
  data: CalendarContent[];
}

const IntentionsChartComponent: React.FC<IntentionsChartProps> = ({ data }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      const counts = INTENT_STAGES.map(intent => 
        data.filter(item => item.intent === intent).length
      );

      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }

      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstanceRef.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: INTENT_STAGES.map(l => l.split('/')[0]),
            datasets: [{
              label: 'Number of Content Pieces',
              data: counts,
              backgroundColor: [
                'rgba(59, 130, 246, 0.75)',  // Blue - Awareness
                `rgba(${parseInt(BRAND_PRIMARY.slice(1,3),16)}, ${parseInt(BRAND_PRIMARY.slice(3,5),16)}, ${parseInt(BRAND_PRIMARY.slice(5,7),16)}, 0.75)`, // Orange - Consideration
                'rgba(22, 163, 74, 0.75)'   // Green - Decision
              ],
              borderColor: [
                'rgba(59, 130, 246, 1)',
                BRAND_PRIMARY,
                'rgba(22, 163, 74, 1)'
              ],
              borderWidth: 1,
              borderRadius: 4,
              hoverBackgroundColor: [
                'rgba(59, 130, 246, 1)',
                `rgba(${parseInt(BRAND_PRIMARY.slice(1,3),16)}, ${parseInt(BRAND_PRIMARY.slice(3,5),16)}, ${parseInt(BRAND_PRIMARY.slice(5,7),16)}, 1)`,
                'rgba(22, 163, 74, 1)'
              ]
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: { 
                beginAtZero: true, 
                ticks: { 
                    stepSize: 1, 
                    font: { family: 'Work Sans', size: 10 },
                    color: '#6B7280', // text-gray-500
                },
                grid: { color: '#E5E7EB' } 
              },
              x: {
                ticks: {
                    font: { family: 'Work Sans', size: 11},
                    color: '#4B5563', // text-gray-600
                },
                grid: { display: false }
              }
            },
            plugins: { 
                legend: { display: false },
                title: {
                    display: true,
                    text: 'Content Intent Breakdown',
                    font: { size: 16, family: 'Work Sans', weight: 600 }, 
                    color: '#2D3748', // brand-text-primary
                    padding: { top: 5, bottom: 25 }
                },
                tooltip: {
                  bodyFont: { family: 'Work Sans' },
                  titleFont: { family: 'Work Sans', weight: 'bold' },
                }
            }
          }
        });
      }
    }
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [data]);

  return (
    <div className="mt-6 md:mt-8"> {/* Removed bg-white and shadow as parent card will handle it */}
      <div className="chart-container relative w-full max-w-xl mx-auto h-72 sm:h-80 md:h-96"> {/* Increased height slightly */}
        <canvas ref={chartRef}></canvas>
      </div>
    </div>
  );
};

export default IntentionsChartComponent;