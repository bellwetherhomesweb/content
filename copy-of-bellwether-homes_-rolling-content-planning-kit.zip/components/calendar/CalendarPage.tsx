
import React, { useState, useMemo, useEffect } from 'react';
import { CalendarContent, CalendarPageProps as BaseCalendarPageProps, KANBAN_STATUSES, ContentStatus } from '../../types';
import ContentCard from './ContentCard';
import TimelineView from './TimelineView';
import KanbanView from './KanbanView';
import { STANDARD_MONTH_ORDER, THEMES, CONTENT_TYPES_OPTIONS, BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';
import { exportCalendarDataToSheet, logAppAction } from '../../services/loggingService';
import { DownloadIcon } from '../shared/Icons'; // Assuming DownloadIcon is available for PDF or other export.

interface CalendarPageReactProps extends BaseCalendarPageProps {}

type ViewMode = 'kanban' | 'grid' | 'timeline';

const CalendarPageReact: React.FC<CalendarPageReactProps> = ({ calendarData, onOpenModal, initialFilters, onCalendarDataUpdate }) => {
  const [monthFilter, setMonthFilter] = useState(initialFilters?.month || 'all');
  const [themeFilter, setThemeFilter] = useState(initialFilters?.theme || 'all');
  const [typeFilter, setTypeFilter] = useState(initialFilters?.type || 'all');
  const [viewMode, setViewMode] = useState<ViewMode>('timeline'); 
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);
  const [isExportingToSheet, setIsExportingToSheet] = useState(false);

  // Use STANDARD_MONTH_ORDER for filter dropdown, ensuring all months are always available for selection
  const availableMonthsForFilter = useMemo(() => ['all', ...STANDARD_MONTH_ORDER], []);
  const availableThemes = useMemo(() => ['all', ...new Set(calendarData.map(item => item.theme).sort())], [calendarData]);

  useEffect(() => {
    if (initialFilters) {
      setMonthFilter(initialFilters.month || 'all');
      setThemeFilter(initialFilters.theme || 'all');
      setTypeFilter(initialFilters.type || 'all');
      if ((initialFilters as any).status) { 
        setViewMode('kanban'); 
      }
    }
  }, [initialFilters]);

  const filteredCalendarData = useMemo(() => {
    return calendarData.filter(item => {
      const statusFilter = (initialFilters as any)?.status; 
      const matchesStatus = statusFilter ? item.status === statusFilter : true;

      return (monthFilter === 'all' || item.month === monthFilter) &&
             (themeFilter === 'all' || item.theme === themeFilter) &&
             (typeFilter === 'all' || item.type === typeFilter) &&
             matchesStatus;
    });
  }, [calendarData, monthFilter, themeFilter, typeFilter, initialFilters]);

  const exportToCsv = () => {
    logAppAction({ actionType: "Export Data", pageContext: "calendar", details: { exportType: "CSV", itemCount: filteredCalendarData.length, filters: { monthFilter, themeFilter, typeFilter } }});
    const headers = ["ID", "Month", "Theme", "Type", "Title", "Intent", "Audience", "Keywords", "Brief", "Competitor Relevance", "Status"];
    const rows = filteredCalendarData.map(item => [item.id, item.month, item.theme, item.type, item.title, item.intent, item.audience, item.keywords, item.brief, item.competitorRelevance, item.status]);
    
    const processRow = (row: string[]) => {
        let finalVal = '';
        for (let j = 0; j < row.length; j++) {
            let innerValue = row[j] === null ? '' : row[j].toString();
            let result = innerValue.replace(/"/g, '""'); 
            if (result.search(/("|,|\n)/g) >= 0) 
                result = '"' + result + '"';
            if (j > 0)
                finalVal += ',';
            finalVal += result;
        }
        return finalVal + '\n';
    };

    let csvFile = processRow(headers);
    for (let i = 0; i < rows.length; i++) {
        csvFile += processRow(rows[i]);
    }

    const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", 'bellwether_content_calendar.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  };

  const handleExportToSheet = async () => {
    setIsExportingToSheet(true);
    logAppAction({ actionType: "Export Data", pageContext: "calendar", details: { exportType: "Google Sheet", itemCount: calendarData.length }});
    await exportCalendarDataToSheet(calendarData); // Pass full, unfiltered data
    setIsExportingToSheet(false);
  };


  const exportButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`;
  const filterSelectClasses = "w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#DD5B42] focus:border-[#DD5B42] bg-white text-slate-800 text-sm shadow-sm";
  const filterLabelClasses = "font-medium text-slate-700 block mb-1.5 text-xs";
  const viewToggleButtonBaseClasses = "px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-colors duration-200 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#DD5B42]";
  const activeViewToggleButtonClasses = `bg-[${BRAND_SECONDARY}] text-white`;
  const inactiveViewToggleButtonClasses = `bg-slate-200 text-slate-700 hover:bg-slate-300`;

  const handleStatusUpdate = (itemId: string, newStatus: ContentStatus) => {
    const updatedData = calendarData.map(item => 
      item.id === itemId ? { ...item, status: newStatus } : item
    );
    onCalendarDataUpdate(updatedData);
  };


  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Content Calendar & Pipeline</h2>
          <p className="text-sm text-slate-500 mt-1">Manage your ongoing content production from ideation to publication.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0"/>
      </div>
      
      <div className="mb-6 p-4 bg-slate-50 rounded-lg shadow-inner border border-slate-200">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
          <div className="flex-grow min-w-[150px]">
            <label htmlFor="monthFilter" className={filterLabelClasses}>Month</label>
            <select id="monthFilter" aria-label="Filter by month" value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} className={filterSelectClasses}>
              {availableMonthsForFilter.map(month => <option key={month} value={month}>{month === 'all' ? 'All Months' : month}</option>)}
            </select>
          </div>
          <div className="flex-grow min-w-[150px]">
            <label htmlFor="themeFilter" className={filterLabelClasses}>Theme</label>
            <select id="themeFilter" aria-label="Filter by theme" value={themeFilter} onChange={(e) => setThemeFilter(e.target.value)} className={filterSelectClasses}>
              {availableThemes.map(theme => <option key={theme} value={theme}>{theme === 'all' ? 'All Themes' : theme}</option>)}
            </select>
          </div>
          <div className="flex-grow min-w-[150px]">
            <label htmlFor="typeFilter" className={filterLabelClasses}>Content Type</label>
            <select id="typeFilter" aria-label="Filter by content type" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className={filterSelectClasses}>
              <option value="all">All Types</option>
              {CONTENT_TYPES_OPTIONS.map(type => <option key={type} value={type}>{type.split(' ')[0]}</option>)} 
            </select>
          </div>
          <div className="flex-shrink-0">
            <button onClick={exportToCsv} className={`${exportButtonClasses} w-full sm:w-auto`}>Export Filtered CSV</button>
          </div>
          <div className="flex-shrink-0">
            <button 
                onClick={handleExportToSheet} 
                className={`bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-green-500 w-full sm:w-auto flex items-center justify-center gap-1.5`}
                disabled={isExportingToSheet}
                title="Exports the entire calendar to a Google Sheet tab."
            >
                {isExportingToSheet ? <DownloadIcon className="w-4 h-4 animate-pulse"/> : <DownloadIcon className="w-4 h-4"/>}
                {isExportingToSheet ? 'Exporting...' : 'Export All to Sheet'}
            </button>
          </div>
        </div>
      </div>


      <div className="flex justify-center gap-2 mb-6">
        {(['timeline', 'kanban', 'grid'] as ViewMode[]).map(mode => (
            <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`${viewToggleButtonBaseClasses} ${viewMode === mode ? activeViewToggleButtonClasses : inactiveViewToggleButtonClasses}`}
                aria-pressed={viewMode === mode}
            >
                {mode.charAt(0).toUpperCase() + mode.slice(1)} View
            </button>
        ))}
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6 mt-6">
          {filteredCalendarData.length > 0 ? (
              filteredCalendarData.map(item => (
              <ContentCard key={item.id} item={item} onClick={() => onOpenModal(item)} />
              ))
          ) : (
              <p className="text-slate-500 italic col-span-full text-center py-10">No content matches the selected filters for the grid view.</p>
          )}
        </div>
      ) : viewMode === 'timeline' ? (
        <TimelineView data={filteredCalendarData} onOpenModal={onOpenModal} />
      ) : ( 
        <KanbanView 
            statuses={KANBAN_STATUSES} 
            data={filteredCalendarData} 
            onOpenModal={onOpenModal}
            onStatusUpdate={handleStatusUpdate}
        />
      )}
       <HelpPanel
        title="Using the Content Calendar"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Plan, Track, and Refine Your Ongoing Content</h4>
        <p>The Content Calendar is your central hub for managing all planned content pieces. Data is saved in your browser, so your work persists.</p>
        <ul>
          <li><strong>Dynamic Data:</strong> New topics can be added using the "✨ AI Topic Generator" tool in the main navigation.</li>
          <li><strong>Filtering:</strong> Use the dropdowns for Month, Theme, and Content Type to narrow down the displayed content. Filter options are based on your actual content data.</li>
          <li><strong>Views:</strong>
            <ul>
              <li><strong>Timeline View (Default):</strong> Organizes content chronologically by month, showing items sequentially.</li>
              <li><strong>Kanban View:</strong> Arranges content in columns by production status (Ideation, Drafting, Review, Scheduled, Published). Drag cards between columns to update their status.</li>
              <li><strong>Grid View:</strong> Displays content as cards, ideal for a quick overview.</li>
            </ul>
          </li>
          <li><strong>Content Details & AI Tools:</strong>
            <ul>
              <li>Click any content card/item in any view to open its detailed modal.</li>
              <li>The modal shows the full brief, keywords, audience, etc. You can edit the brief directly. Edits are saved.</li>
              <li>Use the "✨ AI Content Assistant" buttons in the modal for various tasks.</li>
            </ul>
          </li>
          <li><strong>Export:</strong>
            <ul>
                <li>Click "Export Filtered CSV" to download the currently filtered calendar data as a CSV file.</li>
                <li>Click "Export All to Sheet" to send your entire, unfiltered content calendar to a dedicated tab in your Google Sheet. (Requires Apps Script setup)</li>
            </ul>
          </li>
        </ul>
        <strong>Example:</strong>
        <p>Use the "AI Topic Generator" to get ideas. They appear in "Ideation." Filter by 'Theme'. Drag an idea to 'Drafting'. Click it to open the modal, then use AI to "✨ Expand Brief."</p>
      </HelpPanel>
    </div>
  );
};

export default CalendarPageReact;
