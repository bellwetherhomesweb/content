
import React, { useState, useEffect } from 'react';
import { Strategy, GeminiTextResult } from '../../types';
import { generateGeminiText } from '../../services/geminiService';
import Loader from '../shared/Loader';
import { BRAND_PRIMARY, BRAND_SECONDARY } from '../../constants';
import { PlusIcon, ImageIcon, SparklesIcon } from '../shared/Icons';
import AIContentDisplay from '../shared/AIContentDisplay';
import { logAppAction } from '../../services/loggingService';


interface AccordionItemProps {
  strategy: Strategy;
  isInitiallyExpanded?: boolean;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ strategy, isInitiallyExpanded = false }) => {
  const [isOpen, setIsOpen] = useState(isInitiallyExpanded);
  const [aiText, setAiText] = useState<string | null>(null);
  // const [aiImage, setAiImage] = useState<string | null>(null); // Removed
  const [aiError, setAiError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentAIOperation, setCurrentAIOperation] = useState<'text' | 'visual_concept' | null>(null);


  useEffect(() => {
    setIsOpen(isInitiallyExpanded);
  }, [isInitiallyExpanded]);

  useEffect(() => {
    if (isInitiallyExpanded && strategy.id) {
      const element = document.getElementById(`strategy-item-${strategy.id}`);
      if (element) {
        setTimeout(() => {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
      }
    }
  }, [isInitiallyExpanded, strategy.id]);


  const toggleAccordion = () => {
    setIsOpen(!isOpen);
    // Optionally auto-trigger expand if opening for the first time without prior AI content
    // if (!isOpen && !aiText && !aiImage && !aiError) { 
    //     handleExpandStrategy(); 
    // }
  };
  
  const handleExpandStrategy = async (e?: React.MouseEvent<HTMLButtonElement>) => {
    if (e) e.stopPropagation(); 
    setIsLoading(true);
    setCurrentAIOperation('text');
    setAiText(null);
    // setAiImage(null); // Removed
    setAiError(null);

    const prompt = `Strategy Title: "${strategy.title}"
    Core Idea: "${strategy.content}"
    Task: Provide a detailed action plan for Bellwether Homes. Include:
    1. **Specific, Actionable Tactics:** (e.g., "Develop WordPress template for city landing pages," "Quarterly review of top 5 competitors' YouTube content focused on Colorado climate adaptations.")
    2. **Potential Challenges & Mitigations:** (e.g., "Challenge: High video production cost. Mitigation: Start with expert interviews or screen recordings showing technical details relevant to CO.")
    3. **Key Performance Indicators (KPIs):** (e.g., "Organic ranking for '[city] siding company Denver'," "CTR from blog to embedded video on CO-specific topics.")
    Ensure recommendations are advanced and suitable for a premium Colorado remodeler.`;
    
    const result: GeminiTextResult = await generateGeminiText(prompt);
    const logDetails: Record<string, any> = { 
        strategyId: strategy.id, 
        strategyTitle: strategy.title, 
        aiActionType: 'expandStrategy',
        promptLength: prompt.length,
        originalPrompt: prompt
    };

    if (result.error) {
        setAiError(result.error);
        logDetails.error = result.error;
        logDetails.status = 'error';
    } else {
        setAiText(result.text);
        logDetails.generatedText = result.text;
        logDetails.status = 'success';
    }
    logAppAction({ actionType: 'AI Action Result', pageContext: 'strategy', itemId: strategy.id, details: logDetails });
    setIsLoading(false);
    setCurrentAIOperation(null);
    if (!isOpen) setIsOpen(true); 
  };

  const handleVisualizeStrategyConcept = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setIsLoading(true);
    setCurrentAIOperation('visual_concept');
    // setAiImage(null); // Removed
    setAiText(null); 
    setAiError(null);

    const prompt = `Describe a simple, iconic visual concept (e.g., a metaphor, a simple diagram, or a chart idea) to represent this business strategy for Bellwether Homes, a premium Colorado exterior remodeler.
    Strategy Title: "${strategy.title}"
    Core Idea: "${strategy.content}"
    Focus on the core message of the strategy. Provide a textual description of the visual and its intended meaning. If suggesting a chart or diagram, briefly outline its key data points or structure.`;

    const result: GeminiTextResult = await generateGeminiText(prompt);
    const logDetails: Record<string, any> = { 
        strategyId: strategy.id, 
        strategyTitle: strategy.title, 
        aiActionType: 'visualizeStrategyConcept', // Updated action type
        promptLength: prompt.length,
        originalPrompt: prompt
    };
    
    if (result.error) {
        setAiError(result.error);
        logDetails.error = result.error;
        logDetails.status = 'error';
    } else {
        setAiText(result.text); // Store description in aiText
        logDetails.generatedText = result.text;
        logDetails.status = 'success';
    }
    logAppAction({ actionType: 'AI Action Result', pageContext: 'strategy', itemId: strategy.id, details: logDetails });
    setIsLoading(false);
    setCurrentAIOperation(null);
    if (!isOpen) setIsOpen(true);
  };
  
  const geminiButtonClasses = `bg-[${BRAND_PRIMARY}] hover:bg-opacity-90 text-white px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-colors duration-200 disabled:bg-opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-[${BRAND_PRIMARY}]`;

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden" id={`strategy-item-${strategy.id}`}>
      <button
        onClick={toggleAccordion}
        className="w-full flex justify-between items-center text-left p-5 md:p-6 font-semibold text-slate-800 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#DD5B42] transition-colors duration-150"
        aria-expanded={isOpen}
        aria-controls={`strategy-content-${strategy.id}`}
      >
        <span className="text-md md:text-lg">{strategy.title}</span>
        <PlusIcon className={`text-xl text-slate-500 transform transition-transform duration-300 ${isOpen ? 'rotate-45 text-[#DD5B42]' : ''}`} />
      </button>
      <div
        id={`strategy-content-${strategy.id}`}
        role="region"
        aria-labelledby={`strategy-item-${strategy.id}`}
        className={`accordion-content overflow-hidden transition-all duration-500 ease-in-out ${isOpen ? 'max-h-[1500px] opacity-100' : 'max-h-0 opacity-0'}`}
      >
        <div className="p-5 md:p-6 pt-2 text-slate-700 border-t border-slate-200">
          <p className="mb-4 text-sm leading-relaxed">{strategy.content}</p>
          <div className="flex flex-wrap gap-3 mb-4">
            <button 
              onClick={handleExpandStrategy} 
              className={geminiButtonClasses}
              disabled={isLoading && currentAIOperation === 'text'}
            >
              {(isLoading && currentAIOperation === 'text') ? <Loader /> : <SparklesIcon className="w-4 h-4" />}
              Expand Strategy with AI
            </button>
            <button
              onClick={handleVisualizeStrategyConcept}
              className={geminiButtonClasses}
              disabled={isLoading && currentAIOperation === 'visual_concept'}
              title="Get AI suggestions for a visual concept (diagram, chart, etc.) for this strategy"
            >
              {(isLoading && currentAIOperation === 'visual_concept') ? <Loader /> : <ImageIcon className="w-4 h-4" />}
              Suggest Visual Concept
            </button>
          </div>

          <AIContentDisplay
            isLoading={isLoading}
            aiGeneratedContent={aiText}
            // aiGeneratedImage={null} // Prop removed
            error={aiError}
            title={currentAIOperation === 'visual_concept' ? "AI Visual Concept Suggestion" : "AI Strategy Details"}
             onCopyText={(textToCopy) => {
                logAppAction({
                    actionType: 'AI Content Copied',
                    pageContext: 'strategy',
                    itemId: strategy.id,
                    details: { strategyTitle: strategy.title, copiedActionType: currentAIOperation, copiedText: textToCopy }
                });
                navigator.clipboard.writeText(textToCopy);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default AccordionItem;