
import React, { useState } from 'react';
import { Strategy, StrategyPageProps } 
from '../../types';
import AccordionItem from './AccordionItem';
import { INITIAL_STRATEGY_DATA, BRAND_PRIMARY } from '../../constants';
import HelpButton from '../shared/HelpButton';
import HelpPanel from '../shared/HelpPanel';
import { DownloadIcon, CopyIcon } from '../shared/Icons';
import { logAppAction } from '../../services/loggingService';


const StrategyPage: React.FC<StrategyPageProps> = ({ expandedStrategyId }) => {
  const [isHelpPanelOpen, setIsHelpPanelOpen] = useState(false);
  const [copyStatus, setCopyStatus] = useState('');

  const showCopyStatus = (message: string) => {
    setCopyStatus(message);
    setTimeout(() => setCopyStatus(''), 2000);
  };

  const handleCopyAllStrategies = () => {
    let textToCopy = "Bellwether Homes - Strategic Blueprint\n\n";
    INITIAL_STRATEGY_DATA.forEach(strategy => {
      textToCopy += `## ${strategy.title}\n\n`;
      textToCopy += `${strategy.content}\n\n`;
      textToCopy += "---\n\n";
    });
    navigator.clipboard.writeText(textToCopy.trim())
      .then(() => showCopyStatus('All strategies copied!'))
      .catch(err => {
        console.error('Failed to copy strategies: ', err);
        showCopyStatus('Failed to copy');
      });
    logAppAction({ actionType: 'Export Data', pageContext: 'strategy', details: { exportType: 'Copy All Strategies TXT' } });
  };

  const handleDownloadAllStrategies = () => {
    let textContent = "Bellwether Homes - Strategic Blueprint\n\n";
    INITIAL_STRATEGY_DATA.forEach(strategy => {
      textContent += `## ${strategy.title}\n\n`;
      textContent += `${strategy.content}\n\n`;
      textContent += "---------------------------------------\n\n";
    });

    const blob = new Blob([textContent.trim()], { type: 'text/plain;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `bellwether_strategic_blueprint.txt`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    logAppAction({ actionType: 'Export Data', pageContext: 'strategy', details: { exportType: 'Download All Strategies TXT' } });
  };
  
  const exportButtonClasses = `bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-slate-500 flex items-center gap-1.5`;


  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-800">Strategic Blueprint for Content Excellence</h2>
          <p className="text-sm text-slate-500 mt-1">Core recommendations to elevate content and market position.</p>
        </div>
        <HelpButton onClick={() => setIsHelpPanelOpen(true)} isPanelOpen={isHelpPanelOpen} className="mt-3 sm:mt-0"/>
      </div>
      <p className="mb-4 text-sm text-slate-600 bg-slate-50 p-4 rounded-lg border border-slate-200 shadow-inner">
        These strategic pillars guide Bellwether Homes' content creation. Expand each to explore details and leverage AI for deeper insights and actionable plans.
      </p>
      <div className="mb-6 flex flex-wrap gap-3 items-center">
        <button onClick={handleDownloadAllStrategies} className={exportButtonClasses}>
            <DownloadIcon className="w-4 h-4"/> Download All (TXT)
        </button>
        <button onClick={handleCopyAllStrategies} className={exportButtonClasses}>
            <CopyIcon className="w-4 h-4"/> Copy All Strategies
        </button>
        {copyStatus && <span className="text-xs font-semibold text-green-600">{copyStatus}</span>}
      </div>
      <div className="space-y-4 md:space-y-5">
        {INITIAL_STRATEGY_DATA.map((strategy) => (
          <AccordionItem 
            key={strategy.id} 
            strategy={strategy} 
            isInitiallyExpanded={strategy.id === expandedStrategyId}
          />
        ))}
      </div>
      <HelpPanel
        title="Using the Strategic Blueprint"
        isOpen={isHelpPanelOpen}
        onClose={() => setIsHelpPanelOpen(false)}
      >
        <h4>Understand and Action Your Core Strategies</h4>
        <p>This section outlines the key strategic pillars for Bellwether Homes' content marketing.</p>
        <ul>
          <li><strong>Expandable Strategies:</strong> Each strategy is presented in an accordion format. Click on a strategy title to expand it and read the full recommendation.</li>
          <li><strong>AI-Powered Expansion:</strong>
            <ul>
              <li>Inside each expanded strategy, click the "✨ Expand Strategy with AI" button. The AI will provide a detailed action plan.</li>
              <li>Click "🎨 Suggest Visual Concept" to get AI suggestions for a visual concept (diagram, chart, etc.) for the strategy.</li>
            </ul>
          </li>
          <li><strong>Export & Copy:</strong> Use the "Download All (TXT)" or "Copy All Strategies" buttons at the top to get the full blueprint text.</li>
          <li><strong>Deep Linking:</strong> If navigated from search, the relevant strategy may be auto-expanded.</li>
        </ul>
      </HelpPanel>
    </div>
  );
};

export default StrategyPage;