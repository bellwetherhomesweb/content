
export interface AuditEntry {
  blogTitle: string;
  videoTitle: string;
  relevance: "High" | "Medium" | "Low" | "None";
  opportunity: string;
}

export type Intent = "Awareness/Informational" | "Consideration/Comparison" | "Decision/Transactional";
export type ContentType = "YouTube Video" | "Blog Post";

export type ContentStatus = "Ideation" | "Drafting" | "Review" | "Scheduled" | "Published";

export const KANBAN_STATUSES: ContentStatus[] = ["Ideation", "Drafting", "Review", "Scheduled", "Published"];


export interface CalendarContent {
  id: string;
  month: string; 
  theme: string;
  type: ContentType;
  title: string;
  intent: Intent;
  audience: string;
  keywords: string;
  brief: string;
  competitorRelevance: string; 
  status: ContentStatus;
}

export interface Strategy {
  id: string;
  title: string;
  content: string;
}

export type ActivePage = "overview" | "intent-planner" | "audit" | "calendar" | "strategy" | "search-results" | "competitor-analysis" | "topic-generator"; // Added topic-generator

export interface JourneyItem extends CalendarContent {} // Alias for clarity in IntentPlanner

export interface GroundingChunkWeb {
  uri?: string; 
  title?: string; // Made title optional to match @google/genai
}
export interface GroundingChunk {
  web?: GroundingChunkWeb;
  // Other types of grounding chunks can be added here
}

// For Global Search
export type SearchResultItemType = 'calendar' | 'audit' | 'strategy';

export interface SearchResult {
  id: string; // Original item's ID or a unique key for the result
  type: SearchResultItemType;
  title: string; // Primary display text for the result
  description: string; // A short snippet or description
  data: CalendarContent | AuditEntry | Strategy; // The original item data
  searchTermContext?: string; // The search term that led to this specific item being found (useful for audit pre-fill)
}

// Optional props for page components to handle deep linking from search or quick actions
export interface AuditPageProps {
    initialSearchTerm?: string;
    initialRelevanceFilter?: string;
    onCreateContentIdea: (baseTitle: string, opportunityText: string) => void; // Callback to create content idea
}

export interface StrategyPageProps {
    expandedStrategyId?: string | null;
}

export interface CalendarPageProps {
    initialFilters?: {
        month?: string;
        theme?: string;
        type?: string;
        status?: ContentStatus; // Added status for quick actions
    };
    calendarData: CalendarContent[];
    onOpenModal: (item: CalendarContent, actionType?: string) => void; // actionType is optional
    onCalendarDataUpdate: (updatedData: CalendarContent[]) => void;
}

export interface IntentPlannerPageProps {
    initialSelectedAudience?: string;
    initialCalendarData: CalendarContent[];
    onCalendarDataUpdate: (updatedData: CalendarContent[]) => void;
    onOpenModal: (item: CalendarContent, actionType?: string) => void;
}

// For Competitor Analysis Page
export interface Competitor {
  name: string;
  id: string;
}

export interface CompetitorContentAssessment {
  strength: "High" | "Medium" | "Low" | "None";
  notes: string;
}

export interface CompetitorContentMapEntry {
  contentType: string;
  subCategories?: {
    name: string;
    competitorAssessments: Record<string, CompetitorContentAssessment>; // Keyed by Competitor ID
    bellwetherAssessment: CompetitorContentAssessment;
    opportunityGap: string;
  }[];
  // For top-level content types without sub-categories
  competitorAssessments?: Record<string, CompetitorContentAssessment>;
  bellwetherAssessment?: CompetitorContentAssessment;
  opportunityGap?: string;
}

// For AI Analysis in Competitor Analysis
export interface AIAnalysisState {
  isLoading: boolean;
  resultText: string | null; 
  groundingChunks?: GroundingChunk[];
  error?: string;
  // image?: string | null; // Removed as per user request to replace image generation
}

export interface CompetitorAnalysisContext {
  competitor: Competitor;
  contentType: string; // Main content type
  subCategoryName?: string; // Optional: for sub-categories
  // Bellwether's related item for differentiation, identified by its ID for selection
  bellwetherItemId?: string; 
}

// For Overview Page Comprehensive Brief
export interface MonthlySummary {
  month: string;
  themes: string[];
  blogCount: number;
  videoCount: number;
  keyContentTitles: string[];
}
export interface OverviewBriefData {
  strategicPillars: { title: string; content: string; }[];
  monthlySummaries: MonthlySummary[];
  aiSummary?: string | null; // Optional AI generated summary of the brief, can be null
}

// For AI Topic Generator
export interface TopicGenerationParams {
  targetTimeframe: string; // e.g., "Next 3 months", "Q4 2024"
  keyThemes: string; // Comma-separated or free text
  numBlogPosts: number;
  numVideos: number;
  considerExisting: boolean;
}

export interface GeneratedTopicIdea {
  // Fields from CalendarContent that parseAIResponse guarantees to be non-optional
  title: string;
  brief: string;
  type: ContentType;
  intent: Intent;
  audience: string;
  keywords: string;
  theme: string;
  month: string;
  status: ContentStatus;
  competitorRelevance: string;

  // id from CalendarContent is optional here, as it will be generated when added to calendar
  id?: string; 

  // Fields specific to GeneratedTopicIdea
  isSelected?: boolean;
  tempId: string; // For UI key before permanent ID
}

// For Google Sheets Logging Blueprint
export interface AppActionLog {
  actionType: string; // e.g., "Page Navigation", "AI Action Triggered", "Status Update", "Data Export"
  pageContext?: ActivePage | 'Modal' | 'Global'; // Where the action originated
  itemId?: string; // ID of the content item, strategy, etc. if applicable
  details?: Record<string, any>; // Flexible field for specific details, e.g., { aiAction: "expandBrief", newStatus: "Drafting", navigatedTo: "calendar" }
}

// For geminiService.ts
export interface GeminiTextResult {
  text: string | null; // Null if error or image-only response
  error?: string; // Error message if any
  groundingChunks?: GroundingChunk[];
}