
import { AppActionLog, CalendarContent } from '../types';

// This is a placeholder for your actual Google Apps Script Web App URL
const GOOGLE_SHEET_WEB_APP_URL: string = 'https://script.google.com/macros/s/AKfycbwH0SkyI5I_WMmWftflKqkW21fGrIFzomjmRmUmKecNBvQJFaSAZyj8tQMZCeKIlKll/exec';

/**
 * Logs an application action to Google Sheets.
 * @param actionDetails - An object describing the action to log.
 */
export const logAppAction = async (actionDetails: AppActionLog): Promise<void> => {
  const timestamp = new Date().toISOString();
  const logEntryForConsole = { // For local console logging
    timestamp,
    ...actionDetails,
  };
  console.log('[App Action Logged (Console)]:', logEntryForConsole);

  if (!GOOGLE_SHEET_WEB_APP_URL || GOOGLE_SHEET_WEB_APP_URL === 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE') {
    console.warn('Google Sheets logging is not configured or URL is a placeholder. Please set a valid GOOGLE_SHEET_WEB_APP_URL in loggingService.ts.');
    return;
  }

  const requestBody = {
    action: 'logAppEvent',
    payload: actionDetails,
  };

  try {
    const response = await fetch(GOOGLE_SHEET_WEB_APP_URL, {
      method: 'POST',
      cache: 'no-cache',
      redirect: 'follow',
      body: JSON.stringify(requestBody),
      // No explicit Content-Type header needed if Apps Script parses e.postData.contents
    });

    const result = await response.json();

    if (result.status === "success") {
      // console.log('Successfully logged to Google Sheet:', result.message, result.loggedAction);
    } else {
      console.error('Error reported by Google Sheet logging script:', result.message, 'Received snippet:', result.receivedDataSnippet);
    }
  } catch (error) {
    console.error('Failed to send log to Google Sheet (network/fetch error):', error);
  }
};

/**
 * Exports the full calendar data to a specific sheet in Google Sheets.
 * @param calendarData - Array of CalendarContent objects.
 */
export const exportCalendarDataToSheet = async (calendarData: CalendarContent[]): Promise<void> => {
  if (!GOOGLE_SHEET_WEB_APP_URL || GOOGLE_SHEET_WEB_APP_URL === 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE') {
    console.warn('Google Sheets export is not configured or URL is a placeholder.');
    alert('Google Sheets export is not configured.');
    return;
  }

  const requestBody = {
    action: 'exportCalendarData',
    payload: calendarData,
  };

  console.log('[Calendar Export to Sheets]: Initiated with', calendarData.length, 'items.');

  try {
    const response = await fetch(GOOGLE_SHEET_WEB_APP_URL, {
      method: 'POST',
      cache: 'no-cache',
      redirect: 'follow',
      body: JSON.stringify(requestBody),
    });

    const result = await response.json();

    if (result.status === "success") {
      console.log('Successfully exported calendar data to Google Sheet:', result.message, 'Items exported:', result.itemsExported);
      alert(`Successfully exported ${result.itemsExported} calendar items to Google Sheet: "${result.message}"`);
    } else {
      console.error('Error reported by Google Sheet export script:', result.message, 'Received snippet:', result.receivedDataSnippet);
      alert(`Error exporting calendar data: ${result.message}`);
    }
  } catch (error) {
    console.error('Failed to send calendar data to Google Sheet (network/fetch error):', error);
    alert(`Failed to export calendar data due to a network or fetch error: ${(error as Error).message}`);
  }
};
