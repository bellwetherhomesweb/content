
import { GoogleGenAI, GenerateContentResponse, GroundingChunk } from "@google/genai";
import { GeminiTextResult } from '../types'; // Import the updated type

// Ensure API_KEY is available in the environment
if (!process.env.API_KEY) {
  console.error("API_KEY environment variable is not set. Please ensure it is configured.");
  // Potentially throw an error or have a fallback, but per guidelines, assume it's pre-configured.
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! }); // Add ! to assert API_KEY is present as per guidelines

const TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
// const IMAGE_MODEL = 'imagen-3.0-generate-002'; // Removed

const MAX_RETRIES = 3;
const INITIAL_BACKOFF_MS = 1000;

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const isRetryableError = (error: any): boolean => {
  if (error && error.message) {
    const message = error.message.toLowerCase();
    return message.includes("status: 429") || // Too Many Requests
           message.includes("status: 500") || // Internal Server Error
           message.includes("status: 502") || // Bad Gateway (NEW)
           message.includes("status: 503") || // Service Unavailable
           message.includes("network error") || // General network issues
           message.includes("fetch failed");    // General fetch issues
  }
  return false;
};

export const generateGeminiText = async (
  prompt: string,
  useSearch: boolean = false,
  systemInstruction?: string,
  disableThinking: boolean = false,
  requestJsonOutput: boolean = false
): Promise<GeminiTextResult> => {
  let lastError: any = null;

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      const config: any = {};
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }

      if (useSearch) {
        config.tools = [{ googleSearch: {} }];
      } else if (requestJsonOutput) {
        config.responseMimeType = "application/json";
      }

      if (disableThinking) {
        config.thinkingConfig = { thinkingBudget: 0 };
      }

      const response: GenerateContentResponse = await ai.models.generateContent({
        model: TEXT_MODEL,
        contents: prompt,
        ...(Object.keys(config).length > 0 && { config }),
      });

      const text = response.text;
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

      return { text, groundingChunks, error: undefined };

    } catch (error) {
      console.warn(`Gemini API Call (attempt ${attempt + 1}/${MAX_RETRIES}) failed:`, error);
      lastError = error;
      
      // Do not retry for non-retryable errors (e.g., API key issues, bad requests not covered by isRetryableError)
      if (error instanceof Error && error.message.includes("ReadableStream uploading is notsupported")) {
        // This is a specific configuration error, retrying won't help.
        break; 
      }
      if (error instanceof Error && (error.message.includes("status: 400") || error.message.includes("status: 401") || error.message.includes("status: 403"))) {
        // Bad request or auth errors are not typically retryable in this context.
        break;
      }


      if (isRetryableError(error) && attempt < MAX_RETRIES - 1) {
        const backoffTime = INITIAL_BACKOFF_MS * Math.pow(2, attempt);
        const jitter = Math.random() * 1000; // Add up to 1s jitter
        const delay = backoffTime + jitter;
        console.log(`Retrying in ${Math.round(delay / 1000)}s...`);
        await sleep(delay);
      } else {
        // Max retries reached or error is not retryable
        break;
      }
    }
  }

  // If loop finished due to retries or non-retryable error, return the last error encountered.
  let errorMessage = "Error generating content after multiple retries.";
  if (lastError instanceof Error) {
    errorMessage = `Gemini API Error: ${lastError.message}`;
    if (lastError.message.includes("ReadableStream uploading is notsupported")) {
      errorMessage += " (Detail: The proxy server does not support ReadableStream uploading. This might be an issue with the proxy configuration.)";
    }
    if (lastError.message.toLowerCase().includes("status: 502")) {
        errorMessage = `A temporary gateway error occurred while communicating with the AI service (502). Please try again in a few moments. Full error: ${lastError.message}`;
    }
  }
  return { text: null, error: errorMessage, groundingChunks: undefined };
};

// Removed generateGeminiImage function
